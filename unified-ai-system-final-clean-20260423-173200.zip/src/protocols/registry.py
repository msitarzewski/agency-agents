from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

from src.protocols.a2a_acp_adapter import (
    parse_protocol_message,
    task_to_protocol_response,
    to_normalized_task,
    verify_message_auth,
)
from src.protocols.models import NormalizedTask


@dataclass
class ProtocolRegistry:
    """Simple protocol registry that routes external protocol messages into normalized tasks."""

    def normalize(self, raw_message: Dict[str, Any], shared_token: Optional[str] = None) -> NormalizedTask:
        if shared_token and not verify_message_auth(raw_message, shared_token):
            raise ValueError("Protocol message authentication failed")
        envelope = parse_protocol_message(raw_message)
        return to_normalized_task(envelope)

    def build_response(self, task_id: str, status: str, result: Dict[str, Any], protocol: str) -> Dict[str, Any]:
        return task_to_protocol_response(task_id=task_id, status=status, result=result, protocol=protocol)
