from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class ProtocolMessageType(str, Enum):
    REQUEST = "request"
    RESPONSE = "response"
    EVENT = "event"
    ERROR = "error"


class AgentActionType(str, Enum):
    THINK = "think"
    TOOL = "tool"
    DELEGATE = "delegate"
    COMPLETE = "complete"


@dataclass(frozen=True)
class AgentIdentity:
    agent_id: str
    role: str
    tenant_id: Optional[str] = None


@dataclass(frozen=True)
class CapabilityScope:
    allowed_actions: List[AgentActionType] = field(default_factory=list)
    allowed_tools: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class ProtocolEnvelope:
    protocol: str
    version: str
    message_type: ProtocolMessageType
    correlation_id: str
    source: AgentIdentity
    target: Optional[AgentIdentity]
    action: AgentActionType
    payload: Dict[str, Any]
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class NormalizedTask:
    task_id: str
    title: str
    objective: str
    constraints: Dict[str, Any]
    context: Dict[str, Any]
    source_protocol: str
    source_message_id: str
