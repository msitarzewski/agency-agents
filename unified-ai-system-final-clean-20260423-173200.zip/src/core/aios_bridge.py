"""AIOS bridge client for cross-project integration.

This module provides a small, explicit HTTP bridge from unified-ai-system to
an AIOS service endpoint.
"""

from typing import Any, Dict, Optional

import httpx


class AIOSBridge:
    """HTTP client bridge for AIOS service endpoints."""

    def __init__(
        self,
        base_url: str,
        timeout_seconds: int = 10,
        health_path: str = "/health",
        task_path: str = "/v1/tasks",
        api_key: Optional[str] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.health_path = health_path
        self.task_path = task_path
        self.api_key = api_key

    def _headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _url(self, path: str) -> str:
        if path.startswith("/"):
            return f"{self.base_url}{path}"
        return f"{self.base_url}/{path}"

    async def _request(
        self,
        method: str,
        path: str,
        *,
        payload: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        try:
            timeout = httpx.Timeout(
                connect=min(5.0, float(self.timeout_seconds)),
                read=float(self.timeout_seconds),
                write=min(10.0, float(self.timeout_seconds)),
                pool=2.0,
            )
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.request(
                    method=method,
                    url=self._url(path),
                    json=payload,
                    params=params,
                    headers=self._headers(),
                )
                response.raise_for_status()
                if response.content:
                    parsed_response: Dict[str, Any] = dict(response.json())
                    return parsed_response
                return {"ok": True, "status_code": response.status_code}
        except httpx.HTTPStatusError as exc:
            status_code = exc.response.status_code if exc.response else "unknown"
            body = (exc.response.text or "")[:200] if exc.response else ""
            raise ValueError(f"AIOS bridge HTTP error {status_code}: {body}") from exc
        except httpx.RequestError as exc:
            raise ConnectionError(f"AIOS bridge request failed: {exc}") from exc

    async def health(self) -> Dict[str, Any]:
        """Check remote AIOS health endpoint."""
        return await self._request("GET", self.health_path)

    async def forward_task(self, task_payload: Dict[str, Any]) -> Dict[str, Any]:
        """Forward a task payload to remote AIOS task endpoint."""
        if not isinstance(task_payload, dict):
            raise ValueError("task_payload must be a dictionary")
        required_fields = ["task_type", "description"]
        missing_fields = [field for field in required_fields if not task_payload.get(field)]
        if missing_fields:
            raise ValueError(f"task_payload missing required fields: {missing_fields}")
        return await self._request("POST", self.task_path, payload=task_payload)
