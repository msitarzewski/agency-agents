"""
AI Operating System - Core Orchestrator
Production-Grade Multi-Agent Orchestration System
"""

import asyncio
import uuid
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Any, Optional, Set, Callable, TYPE_CHECKING
from dataclasses import dataclass, field
from enum import Enum, auto
from collections import defaultdict
import logging

from src.config.settings import config
from src.protocols.registry import ProtocolRegistry
from src.core.lineage import hash_lineage_payload, normalize_lineage
from src.core.lineage_repository import FileLineageRepository
from .reasoning_layer import ContradictionFlag, MythosReasoner, ReasoningAssessment, ReasoningMode

if TYPE_CHECKING:
    from src.tools.tool_registry import ToolRegistry

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """Task execution states"""
    PENDING = "pending"
    SCHEDULED = "scheduled"
    RUNNING = "running"
    BLOCKED = "blocked"
    WAITING_INPUT = "waiting_input"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    RETRY = "retry"


class TaskPriority(Enum):
    """Task priority levels"""
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    BACKGROUND = 4


class AgentRole(Enum):
    """Agent role definitions"""
    PLANNER = "planner"
    EXECUTOR = "executor"
    CRITIC = "critic"
    COORDINATOR = "coordinator"
    RESEARCHER = "researcher"
    GENERATOR = "generator"
    VALIDATOR = "validator"


class MessageType(Enum):
    """Agent communication message types"""
    TASK_DISPATCH = "task_dispatch"
    TASK_RESULT = "task_result"
    COORDINATION = "coordination"
    HEARTBEAT = "heartbeat"
    ESCALATION = "escalation"
    APPROVAL_REQUEST = "approval_request"
    APPROVAL_RESPONSE = "approval_response"
    CONTEXT_UPDATE = "context_update"


@dataclass
class Task:
    """Task representation with full lifecycle support"""
    task_id: str
    task_type: str
    description: str
    priority: TaskPriority
    status: TaskStatus = TaskStatus.PENDING
    assigned_agent: Optional[str] = None

    # Task graph relationships
    parent_task_id: Optional[str] = None
    subtask_ids: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)

    # Execution context
    inputs: Dict[str, Any] = field(default_factory=dict)
    outputs: Dict[str, Any] = field(default_factory=dict)
    constraints: Dict[str, Any] = field(default_factory=dict)

    # Metadata
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    deadline: Optional[datetime] = None
    retry_count: int = 0
    max_retries: int = 3

    # Tracing
    trace_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    span_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    # Error handling
    error: Optional[str] = None
    error_trace: Optional[str] = None

    # Mythos-style reasoning reliability metadata
    reasoning_assessment: Optional[ReasoningAssessment] = None

    # State machine
    state_machine: Dict[str, Any] = field(default_factory=dict)

    def __hash__(self):
        return hash(self.task_id)

    def can_retry(self) -> bool:
        return self.retry_count < self.max_retries and self.status == TaskStatus.FAILED

    def is_blocked(self) -> bool:
        """Check if task is blocked by dependencies"""
        return self.status == TaskStatus.BLOCKED

    def execution_time_ms(self) -> Optional[int]:
        if self.started_at and self.completed_at:
            return int((self.completed_at - self.started_at).total_seconds() * 1000)
        return None


@dataclass
class AgentMessage:
    """Structured agent communication message"""
    message_id: str
    message_type: MessageType
    sender: str
    recipients: List[str]

    # Task context
    task_id: Optional[str] = None
    intent: str = ""

    # Payload
    payload: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)

    # Memory references
    memory_refs: List[str] = field(default_factory=list)

    # Execution constraints
    tools_allowed: List[str] = field(default_factory=list)
    timeout_seconds: int = 300
    priority: TaskPriority = TaskPriority.NORMAL

    # Tracing
    correlation_id: Optional[str] = None
    trace_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    # Timing
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
    expires_at: Optional[datetime] = None

    # Communication mode
    synchronous: bool = True
    blocking: bool = True
    retry_on_failure: bool = True
    max_retries: int = 3

    # Escalation
    escalation_level: int = 0
    escalation_chain: List[str] = field(default_factory=list)


@dataclass
class ExecutionResult:
    """Structured execution result"""
    success: bool
    output: Any = None
    error: Optional[str] = None
    trace_id: Optional[str] = None
    execution_time_ms: int = 0
    tokens_used: int = 0
    cost_usd: float = 0.0
    confidence: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)


class TaskNode:
    """Task graph node representation"""
    task: Task
    node_type: str
    state: str
    inputs: List[Any]
    outputs: List[Any]
    dependencies: List[str]
    conditions: List[Callable[..., bool]]

    def __init__(self, task: Task, node_type: str):
        self.task = task
        self.node_type = node_type  # reasoning, tool, validation, memory
        self.state = "pending"
        self.inputs = []
        self.outputs = []
        self.dependencies = []
        self.conditions = []

    def __hash__(self):
        return hash(self.task.task_id)


class TaskGraph:
    """Directed Acyclic Graph for task execution"""
    def __init__(self, graph_id: str):
        self.graph_id = graph_id
        self.nodes: Dict[str, TaskNode] = {}
        self.edges: Dict[str, List[str]] = defaultdict(list)
        self.reverse_edges: Dict[str, List[str]] = defaultdict(list)
        self.execution_order: List[str] = []

    def add_node(self, task: Task, node_type: str = "reasoning") -> TaskNode:
        node = TaskNode(task, node_type)
        self.nodes[task.task_id] = node
        return node

    def add_edge(self, from_id: str, to_id: str, condition: Optional[Callable] = None):
        if from_id not in self.nodes:
            raise ValueError(f"Source node not found: {from_id}")
        if to_id not in self.nodes:
            raise ValueError(f"Target node not found: {to_id}")
        if from_id == to_id:
            raise ValueError("Self-loop edges are not allowed")

        if to_id in self.edges[from_id]:
            return

        self.edges[from_id].append(to_id)
        self.reverse_edges[to_id].append(from_id)

        # Reject edges that introduce a cycle to keep graph execution valid.
        if not self.is_dag():
            self.edges[from_id].remove(to_id)
            self.reverse_edges[to_id].remove(from_id)
            raise ValueError(f"Edge {from_id} -> {to_id} introduces a cycle")

        if condition:
            self.nodes[to_id].conditions.append(condition)

    def get_ready_nodes(self) -> List[str]:
        """Get nodes that are ready to execute (all dependencies completed)"""
        ready = []
        for node_id, node in self.nodes.items():
            if node.state in ["pending", "blocked"]:
                deps_met = all(
                    self.nodes[dep].state == "completed"
                    for dep in self.reverse_edges.get(node_id, [])
                )
                if deps_met:
                    ready.append(node_id)
        return ready

    def is_dag(self) -> bool:
        """Check if graph is a valid DAG (no cycles)"""
        visited = set()
        rec_stack = set()

        def has_cycle(node_id: str) -> bool:
            visited.add(node_id)
            rec_stack.add(node_id)

            for neighbor in self.edges.get(node_id, []):
                if neighbor not in visited:
                    if has_cycle(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True

            rec_stack.remove(node_id)
            return False

        for node_id in self.nodes:
            if node_id not in visited and has_cycle(node_id):
                return False
        return True

    def topological_sort(self) -> List[str]:
        """Get topological order for execution"""
        in_degree = {n: len(self.reverse_edges.get(n, [])) for n in self.nodes}
        queue = [n for n, d in in_degree.items() if d == 0]
        result = []

        while queue:
            node = queue.pop(0)
            result.append(node)

            for neighbor in self.edges.get(node, []):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        return result if len(result) == len(self.nodes) else []


class Agent:
    """Base agent class with full lifecycle support"""

    def __init__(
        self,
        agent_id: str,
        role: AgentRole,
        capabilities: List[str],
        max_concurrent_tasks: int = 5
    ):
        self.agent_id = agent_id
        self.role = role
        self.capabilities = capabilities
        self.max_concurrent_tasks = max_concurrent_tasks

        self.status = "idle"
        self.current_tasks: Set[str] = set()
        self.capacity = max_concurrent_tasks

        self.message_queue: asyncio.Queue = asyncio.Queue()
        self.inbox: List[AgentMessage] = []

        self.performance_metrics = {
            "tasks_completed": 0,
            "tasks_failed": 0,
            "avg_execution_time_ms": 0,
            "success_rate": 1.0
        }

        self._running = False

    async def start(self):
        await asyncio.sleep(0)
        self._running = True
        self._background_tasks = [
            asyncio.create_task(self._process_messages()),
            asyncio.create_task(self._heartbeat_loop()),
        ]

    async def stop(self):
        self._running = False
        await asyncio.sleep(0)

    async def _heartbeat_loop(self):
        """Send periodic heartbeat to coordinator"""
        while self._running:
            await asyncio.sleep(30)
            logger.debug(f"Heartbeat from {self.agent_id}: {self.status}")

    async def _process_messages(self):
        """Process incoming messages"""
        while self._running:
            try:
                message = await asyncio.wait_for(
                    self.message_queue.get(),
                    timeout=1.0
                )
                await self.handle_message(message)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error processing message: {e}")

    async def handle_message(self, message: AgentMessage):
        """Handle incoming agent message"""
        if message.message_type == MessageType.TASK_DISPATCH:
            await self.execute_task(message)
        elif message.message_type == MessageType.COORDINATION:
            await self.handle_coordination(message)
        elif message.message_type == MessageType.ESCALATION:
            await self.handle_escalation(message)

    async def execute_task(self, message: AgentMessage) -> ExecutionResult:
        """Execute assigned task - to be implemented by subclass"""
        raise NotImplementedError

    async def handle_coordination(self, message: AgentMessage):
        """Handle coordination message"""
        pass

    async def handle_escalation(self, message: AgentMessage):
        """Handle escalation from other agent"""
        pass

    def can_accept_task(self) -> bool:
        return len(self.current_tasks) < self.capacity

    def assign_task(self, task_id: Optional[str]):
        if not task_id:
            return
        self.current_tasks.add(task_id)

    def release_task(self, task_id: Optional[str]):
        if not task_id:
            return
        self.current_tasks.discard(task_id)

    async def send_message(
        self,
        orchestrator: 'Orchestrator',
        message: AgentMessage
    ):
        """Send message through orchestrator"""
        await orchestrator.route_message(message)


class PlannerAgent(Agent):
    """Task planning and decomposition agent"""

    def __init__(self, agent_id: str = "planner_01"):
        super().__init__(
            agent_id=agent_id,
            role=AgentRole.PLANNER,
            capabilities=[
                "task_decomposition",
                "goal_analysis",
                "resource_planning",
                "priority_estimation",
                "dependency_analysis"
            ],
            max_concurrent_tasks=10
        )
        self.planning_depth = 5

    async def execute_task(self, message: AgentMessage) -> ExecutionResult:
        """Execute planning task"""
        task = message.payload.get("task")
        if not task:
            return ExecutionResult(success=False, error="No task provided")

        self.assign_task(message.task_id)
        start_time = time.time()

        try:
            # Step 1: Parse and understand task
            task_understanding = await self._understand_task(task)

            # Step 2: Decompose into subtasks
            subtasks = await self._decompose_task(task, task_understanding)

            # Step 3: Analyze dependencies
            dependency_graph = await self._analyze_dependencies(subtasks)

            # Step 4: Estimate resources and priorities
            execution_plan = await self._create_execution_plan(subtasks, dependency_graph)

            result = ExecutionResult(
                success=True,
                output={
                    "task_id": task.task_id,
                    "subtasks": subtasks,
                    "dependency_graph": dependency_graph,
                    "execution_plan": execution_plan,
                    "estimated_duration_seconds": sum(s.get("estimated_duration", 10) for s in subtasks)
                },
                execution_time_ms=int((time.time() - start_time) * 1000),
                confidence=0.85
            )

            self.performance_metrics["tasks_completed"] += 1

        except Exception as e:
            result = ExecutionResult(success=False, error=str(e))
            self.performance_metrics["tasks_failed"] += 1
        finally:
            self.release_task(message.task_id)

        return result

    async def _understand_task(self, task: Task) -> Dict:
        """Understand task requirements"""
        await asyncio.sleep(0)
        complexity = "low"
        if len(task.description) > 500:
            complexity = "high"
        elif len(task.description) > 100:
            complexity = "medium"
        return {
            "task_type": task.task_type,
            "complexity": complexity,
            "required_capabilities": task.constraints.get("required_capabilities", []),
            "constraints": task.constraints,
            "success_criteria": task.constraints.get("success_criteria", [])
        }

    async def _decompose_task(self, task: Task, understanding: Dict) -> List[Dict]:
        """Decompose task into executable subtasks"""
        await asyncio.sleep(0)
        subtasks = []

        # Analysis phase
        if understanding["complexity"] in ["high", "medium"]:
            subtasks.append({
                "subtask_id": f"{task.task_id}_analysis",
                "action": "research_and_analysis",
                "agent_role": AgentRole.RESEARCHER,
                "priority": TaskPriority.HIGH,
                "estimated_duration": 60,
                "tools_needed": ["web_search", "document_analysis"],
                "output_format": "analysis_report"
            })

        # Generation phase
        subtasks.append({
            "subtask_id": f"{task.task_id}_generation",
            "action": "content_generation",
            "agent_role": AgentRole.GENERATOR,
            "priority": TaskPriority.NORMAL,
            "estimated_duration": 120,
            "tools_needed": ["text_generation"],
            "output_format": task.constraints.get("output_format", "text"),
            "depends_on": [s["subtask_id"] for s in subtasks[-1:] if understanding["complexity"] in ["high", "medium"]]
        })

        # Validation phase
        subtasks.append({
            "subtask_id": f"{task.task_id}_validation",
            "action": "quality_validation",
            "agent_role": AgentRole.CRITIC,
            "priority": TaskPriority.NORMAL,
            "estimated_duration": 30,
            "tools_needed": ["validator"],
            "output_format": "validation_report",
            "depends_on": [s["subtask_id"] for s in subtasks[:-1]]
        })

        # Final output phase
        subtasks.append({
            "subtask_id": f"{task.task_id}_finalize",
            "action": "finalize_output",
            "agent_role": AgentRole.EXECUTOR,
            "priority": TaskPriority.LOW,
            "estimated_duration": 20,
            "tools_needed": [],
            "output_format": task.constraints.get("output_format", "text"),
            "depends_on": [s["subtask_id"] for s in subtasks[:-1]]
        })

        return subtasks

    async def _analyze_dependencies(self, subtasks: List[Dict]) -> Dict:
        """Create dependency graph"""
        await asyncio.sleep(0)
        graph: Dict[str, List[Dict[str, Any]]] = {"nodes": [], "edges": []}

        for subtask in subtasks:
            node = {
                "id": subtask["subtask_id"],
                "action": subtask["action"],
                "depends_on": subtask.get("depends_on", [])
            }
            graph["nodes"].append(node)

            for dep in subtask.get("depends_on", []):
                graph["edges"].append({"from": dep, "to": subtask["subtask_id"]})

        return graph

    async def _create_execution_plan(
        self,
        subtasks: List[Dict],
        dependency_graph: Dict
    ) -> Dict:
        """Create optimized execution plan"""
        await asyncio.sleep(0)
        # Topological sort to determine order
        task_order = self._topological_sort(dependency_graph)

        return {
            "execution_order": task_order,
            "parallelizable_tasks": self._find_parallelizable(subtasks),
            "critical_path": self._find_critical_path(subtasks, dependency_graph),
            "estimated_total_duration": sum(s.get("estimated_duration", 10) for s in subtasks)
        }

    def _topological_sort(self, graph: Dict) -> List[str]:
        """Topological sort of task graph"""
        in_degree = {n["id"]: 0 for n in graph["nodes"]}
        for edge in graph["edges"]:
            in_degree[edge["to"]] += 1

        queue = [n for n, d in in_degree.items() if d == 0]
        result = []

        while queue:
            node = queue.pop(0)
            result.append(node)

            for edge in graph["edges"]:
                if edge["from"] == node:
                    in_degree[edge["to"]] -= 1
                    if in_degree[edge["to"]] == 0:
                        queue.append(edge["to"])

        return result

    def _find_parallelizable(self, subtasks: List[Dict]) -> List[str]:
        """Find tasks that can run in parallel"""
        parallel = []
        for subtask in subtasks:
            if not subtask.get("depends_on"):
                parallel.append(subtask["subtask_id"])
        return parallel

    def _find_critical_path(
        self,
        subtasks: List[Dict],
        dependency_graph: Dict
    ) -> List[str]:
        """Find critical path through task graph"""
        _ = dependency_graph
        # Simplified - would use actual critical path algorithm
        return [s["subtask_id"] for s in sorted(
            subtasks,
            key=lambda x: x.get("estimated_duration", 10),
            reverse=True
        )[:3]]


class ExecutorAgent(Agent):
    """Task execution agent with tool support"""

    def __init__(self, agent_id: str = "executor_01"):
        super().__init__(
            agent_id=agent_id,
            role=AgentRole.EXECUTOR,
            capabilities=[
                "code_execution",
                "api_calls",
                "file_operations",
                "web_scraping",
                "data_processing"
            ],
            max_concurrent_tasks=3
        )
        self.tool_registry = None

    def set_tool_registry(self, registry: Any):
        self.tool_registry = registry

    async def execute_task(self, message: AgentMessage) -> ExecutionResult:
        """Execute task using available tools"""
        self.assign_task(message.task_id)
        start_time = time.time()

        try:
            task = message.payload.get("task")
            tools = message.tools_allowed or []
            context = message.context

            if not task:
                return ExecutionResult(success=False, error="No task provided")

            # Execute based on task type
            if task.task_type == "code_generation":
                result = await self._execute_code_generation(task, context)
            elif task.task_type == "web_search":
                result = await self._execute_web_search(task, tools, context)
            elif task.task_type == "data_processing":
                result = await self._execute_data_processing(task, tools)
            else:
                result = await self._execute_generic(task, tools, context)

            result.execution_time_ms = int((time.time() - start_time) * 1000)
            self.performance_metrics["tasks_completed"] += 1

            return result

        except Exception as e:
            logger.error(f"Executor error: {e}")
            self.performance_metrics["tasks_failed"] += 1
            return ExecutionResult(success=False, error=str(e))
        finally:
            self.release_task(message.task_id)

    async def _execute_code_generation(
        self,
        task: Task,
        context: Dict
    ) -> ExecutionResult:
        """Execute code generation task"""
        await asyncio.sleep(0)
        # Simulate code generation
        code = f"# Generated code for {task.description[:50]}...\n# Implementation here"

        return ExecutionResult(
            success=True,
            output={"code": code, "language": "python"},
            confidence=0.9
        )

    async def _execute_web_search(
        self,
        task: Task,
        tools: List[str],
        context: Dict
    ) -> ExecutionResult:
        """Execute web search task"""
        await asyncio.sleep(0)
        _ = (tools, context)
        if self.tool_registry:
            tool = self.tool_registry.get_tool("web_search")
            if tool:
                result = await tool.execute(task.inputs.get("query", ""))
                return result

        return ExecutionResult(success=True, output={"results": [], "count": 0})

    async def _execute_data_processing(
        self,
        task: Task,
        tools: List[str]
    ) -> ExecutionResult:
        """Execute data processing task"""
        await asyncio.sleep(0)
        _ = tools
        data = task.inputs.get("data", [])
        operation = task.inputs.get("operation", "aggregate")

        if operation == "aggregate":
            result = sum(data) / len(data) if data else 0
        elif operation == "filter":
            result = [d for d in data if d]
        else:
            result = data

        return ExecutionResult(
            success=True,
            output={"result": result, "operation": operation},
            confidence=0.95
        )

    async def _execute_generic(
        self,
        task: Task,
        tools: List[str],
        context: Dict
    ) -> ExecutionResult:
        """Execute generic task"""
        await asyncio.sleep(0)
        _ = (tools, context)
        return ExecutionResult(
            success=True,
            output={"result": "Task completed", "description": task.description},
            confidence=0.8
        )


class CriticAgent(Agent):
    """Validation and critique agent"""

    def __init__(self, agent_id: str = "critic_01"):
        super().__init__(
            agent_id=agent_id,
            role=AgentRole.CRITIC,
            capabilities=[
                "quality_validation",
                "fact_checking",
                "contradiction_detection",
                "consistency_checking",
                "improvement_suggestions"
            ],
            max_concurrent_tasks=5
        )
        self.iteration_limit = 3
        self.confidence_threshold = 0.8

    async def execute_task(self, message: AgentMessage) -> ExecutionResult:
        """Execute validation task with self-critique loop"""
        self.assign_task(message.task_id)
        start_time = time.time()

        try:
            content_to_validate = message.payload.get("content")
            validation_type = message.payload.get("validation_type", "quality")

            if not content_to_validate:
                return ExecutionResult(success=False, error="No content to validate")

            # Self-critique loop
            iteration = 0
            current_content = content_to_validate
            confidence = 0.0

            while iteration < self.iteration_limit:
                # Critique step
                critique_result = await self._critique(current_content, validation_type)

                # Check if meets quality bar
                if critique_result["confidence"] >= self.confidence_threshold:
                    confidence = critique_result["confidence"]
                    break

                # Revise step
                current_content = await self._revise(
                    current_content,
                    critique_result["issues"]
                )
                iteration += 1

            return ExecutionResult(
                success=True,
                output={
                    "validated_content": current_content,
                    "confidence": confidence,
                    "iterations": iteration,
                    "issues_found": critique_result.get("issues", []),
                    "suggestions": critique_result.get("suggestions", [])
                },
                execution_time_ms=int((time.time() - start_time) * 1000),
                confidence=confidence
            )

        except Exception as e:
            return ExecutionResult(success=False, error=str(e))
        finally:
            self.release_task(message.task_id)

    async def _critique(
        self,
        content: str,
        validation_type: str
    ) -> Dict:
        """Critique content quality"""
        await asyncio.sleep(0)
        _ = validation_type
        issues = []
        suggestions = []
        confidence = 1.0

        # Check length
        if len(content) < 100:
            issues.append("Content too short")
            suggestions.append("Add more detail and context")
            confidence -= 0.2

        # Check structure
        if "\n\n" not in content:
            issues.append("Poor structure")
            suggestions.append("Add paragraph breaks and structure")
            confidence -= 0.1

        # Check for clarity
        complex_words = ["utilize", "implement", "facilitate"]
        for word in complex_words:
            if word.lower() in content.lower():
                issues.append(f"Complex language: {word}")
                suggestions.append("Replace with simpler alternative")
                confidence -= 0.05

        return {
            "confidence": max(confidence, 0.0),
            "issues": issues,
            "suggestions": suggestions,
            "quality_score": confidence
        }

    async def _revise(self, content: str, issues: List[str]) -> str:
        """Revise content based on critique"""
        await asyncio.sleep(0)
        revised = content

        for issue in issues:
            if "short" in issue.lower():
                revised += "\n\n[Additional context and detail to meet quality requirements]"
            elif "structure" in issue.lower():
                # Add structure
                sections = revised.split("\n\n")
                revised = "\n\n".join(f"## Section {i+1}\n{s}" for i, s in enumerate(sections))

        return revised


class Orchestrator:
    """
    Core AI-OS Orchestrator
    Central coordination engine for multi-agent task execution
    """

    def __init__(self, lineage_repository: Optional[FileLineageRepository] = None):
        # Core components
        self.agents: Dict[str, Agent] = {}
        self.task_graphs: Dict[str, TaskGraph] = {}
        self.task_queue: asyncio.PriorityQueue = asyncio.PriorityQueue()

        # Memory systems
        self.short_term_memory: Dict[str, List[Dict]] = defaultdict(list)
        self.vector_store = None

        # Execution state
        self.active_tasks: Dict[str, Task] = {}
        self.completed_tasks: Dict[str, Task] = {}
        self.failed_tasks: Dict[str, Task] = {}

        # Configuration
        self.max_concurrent_tasks = 50
        self.default_timeout_seconds = 300
        self.retry_delay_seconds = 5

        # State
        self._running = False
        self._task_counter = 0
        self._background_tasks: List[asyncio.Task[Any]] = []

        # Callbacks
        self.on_task_complete: Optional[Callable] = None
        self.on_task_fail: Optional[Callable] = None
        self.on_human_approval_needed: Optional[Callable] = None

        # Tracing
        self.trace_history: List[Dict] = []

        # Confidence-aware execution mode selection (feature-flagged)
        self.reasoner = MythosReasoner(
            enabled=config.mythos.enabled,
            cautious_threshold=config.mythos.cautious_threshold,
            defer_threshold=config.mythos.defer_threshold,
        )
        self.protocol_registry = ProtocolRegistry()
        self.lineage_repository = lineage_repository or FileLineageRepository(Path(config.storage_path) / "lineage")

    def _persist_task_snapshot(self, task: Task) -> None:
        try:
            self.lineage_repository.persist_task_snapshot(
                task_id=task.task_id,
                status=task.status.value,
                task_type=task.task_type,
                description=task.description,
                trace_id=task.trace_id,
                lineage=dict(task.inputs.get("_lineage") or {}),
                outputs=dict(task.outputs or {}),
                error=task.error,
            )
        except Exception as exc:
            logger.warning("Failed to persist task snapshot task_id=%s error=%s", task.task_id, exc)

    async def initialize(self):
        """Initialize orchestrator and all subsystems"""
        await asyncio.sleep(0)
        logger.info("Initializing AI-OS Orchestrator...")

        # Initialize agents
        await self._initialize_agents()

        # Initialize memory systems
        await self._initialize_memory()

        # Start orchestrator loop
        self._running = True
        self._background_tasks.extend([
            asyncio.create_task(self._orchestrator_loop()),
            asyncio.create_task(self._task_scheduler()),
        ])

        logger.info("AI-OS Orchestrator initialized successfully")

    async def _initialize_agents(self):
        """Initialize all agents"""
        # Create core agents
        planner = PlannerAgent("planner_01")
        executor = ExecutorAgent("executor_01")
        critic = CriticAgent("critic_01")

        self.agents["planner_01"] = planner
        self.agents["executor_01"] = executor
        self.agents["critic_01"] = critic

        # Start all agents
        for agent in self.agents.values():
            await agent.start()

        logger.info(f"Initialized {len(self.agents)} agents")

    async def _initialize_memory(self):
        """Initialize memory systems"""
        # Initialize vector store (would connect to actual vector DB)
        self.vector_store = VectorMemoryStore()
        await self.vector_store.initialize()

    async def shutdown(self):
        """Shutdown orchestrator gracefully"""
        logger.info("Shutting down AI-OS Orchestrator...")
        self._running = False

        for background_task in self._background_tasks:
            background_task.cancel()

        if self._background_tasks:
            await asyncio.gather(*self._background_tasks, return_exceptions=True)
            self._background_tasks.clear()

        for agent in self.agents.values():
            await agent.stop()

        logger.info("AI-OS Orchestrator shutdown complete")

    async def _orchestrator_loop(self):
        """Main orchestrator event loop"""
        while self._running:
            try:
                # Process task queue
                while not self.task_queue.empty():
                    _, task = await asyncio.wait_for(
                        self.task_queue.get(),
                        timeout=0.1
                    )
                    await self._process_task(task)

                await asyncio.sleep(0.1)

            except Exception as e:
                logger.error(f"Orchestrator loop error: {e}")

    async def _task_scheduler(self):
        """Schedule and dispatch tasks to agents"""
        while self._running:
            try:
                # Check for tasks that can be scheduled
                for task in self.active_tasks.values():
                    if task.status == TaskStatus.PENDING:
                        await self._schedule_task(task)

                await asyncio.sleep(1)
            except Exception as e:
                logger.error(f"Task scheduler error: {e}")

    async def _process_task(self, task: Task):
        """Process a new task"""
        self._task_counter += 1

        task.task_id = f"task_{self._task_counter:06d}"
        task.status = TaskStatus.PENDING
        task.trace_id = task.trace_id or str(uuid.uuid4())
        task.inputs["_lineage"] = normalize_lineage(
            raw_lineage=task.inputs.get("_lineage"),
            trace_id=task.trace_id,
            session_id=task.inputs.get("session_id"),
            parent_task_id=task.parent_task_id,
            source=task.inputs.get("_lineage", {}).get("source", "orchestrator"),
            source_message_id=task.inputs.get("source_message_id"),
            input_payload=task.inputs,
        )

        self.active_tasks[task.task_id] = task
        self._persist_task_snapshot(task)

        # Store in short-term memory
        self._update_memory(task, "task_created")

        # Log trace
        self._log_trace("task_created", {
            "task_id": task.task_id,
            "task_type": task.task_type,
            "trace_id": task.trace_id
        })

        # Schedule for execution
        await self._schedule_task(task)

    async def _schedule_task(self, task: Task):
        """Schedule task for execution"""
        # Check dependencies
        deps_ready = all(
            self.active_tasks.get(dep_id) is not None
            and self.active_tasks[dep_id].status == TaskStatus.COMPLETED
            for dep_id in task.dependencies
        )

        if not deps_ready:
            task.status = TaskStatus.BLOCKED
            return

        assessment = task.reasoning_assessment
        if assessment and assessment.execution_mode.value == "defer":
            task.status = TaskStatus.WAITING_INPUT
            self._log_trace(
                "task_deferred_by_reasoning",
                {
                    "task_id": task.task_id,
                    "trace_id": task.trace_id,
                    "confidence_score": assessment.confidence_score,
                    "defer_reason": assessment.defer_reason,
                },
            )
            if self.on_human_approval_needed:
                await self.on_human_approval_needed(task, assessment)
            return

        # Find available agent
        agent = self._select_agent(task)

        if not agent:
            # Queue for later
            task.status = TaskStatus.WAITING_INPUT
            return

        # Dispatch to agent
        await self._dispatch_to_agent(agent, task)

    def _select_agent(self, task: Task) -> Optional[Agent]:
        """Select optimal agent for task"""
        for agent in self.agents.values():
            if agent.can_accept_task():
                # Check capability match
                if any(cap in agent.capabilities for cap in task.constraints.get("required_capabilities", [])):
                    return agent

        # Fallback to any available agent
        for agent in self.agents.values():
            if agent.can_accept_task():
                return agent

        return None

    async def _dispatch_to_agent(self, agent: Agent, task: Task):
        """Dispatch task to agent for execution"""
        task.status = TaskStatus.RUNNING
        task.assigned_agent = agent.agent_id
        task.started_at = datetime.now(timezone.utc).replace(tzinfo=None)

        # Create agent message
        message = AgentMessage(
            message_id=str(uuid.uuid4()),
            message_type=MessageType.TASK_DISPATCH,
            sender="orchestrator",
            recipients=[agent.agent_id],
            task_id=task.task_id,
            intent=task.task_type,
            payload={
                "task": task,
                "context": self._get_task_context(task)
            },
            tools_allowed=task.constraints.get("tools_allowed", []),
            timeout_seconds=task.deadline and (task.deadline - datetime.now(timezone.utc).replace(tzinfo=None)).seconds or 300,
            trace_id=task.trace_id
        )

        # Add to agent queue
        await agent.message_queue.put(message)

        self._log_trace("task_dispatched", {
            "task_id": task.task_id,
            "agent": agent.agent_id,
            "trace_id": task.trace_id
        })

    def _get_task_context(self, task: Task) -> Dict:
        """Get context for task from memory"""
        # Retrieve relevant context
        context = {
            "session_id": task.inputs.get("session_id"),
            "user_id": task.inputs.get("user_id"),
            "recent_tasks": self.short_term_memory.get(task.inputs.get("session_id", ""), [])[-5:],
            "constraints": task.constraints,
            "lineage": task.inputs.get("_lineage", {}),
        }

        # Add memory references if available
        if self.vector_store:
            relevant = self.vector_store.retrieve(task.description, top_k=3)
            context["memory_refs"] = [r["id"] for r in relevant]
            lineage = dict(task.inputs.get("_lineage", {}))
            lineage["memory_refs"] = context["memory_refs"]
            task.inputs["_lineage"] = lineage

        return context

    async def handle_task_result(
        self,
        task_id: str,
        result: ExecutionResult
    ):
        """Handle task completion"""
        task = self.active_tasks.get(task_id)
        if not task:
            return

        task.completed_at = datetime.now(timezone.utc).replace(tzinfo=None)

        if result.success:
            task.status = TaskStatus.COMPLETED
            task.outputs = result.output
            lineage = dict(task.inputs.get("_lineage", {}))
            lineage["output_ref"] = hash_lineage_payload(result.output)
            task.inputs["_lineage"] = lineage
            self.completed_tasks[task_id] = task

            if self.on_task_complete:
                await self.on_task_complete(task, result)
        else:
            task.status = TaskStatus.FAILED
            if task.can_retry():
                task.status = TaskStatus.RETRY
                task.retry_count += 1
                lineage = dict(task.inputs.get("_lineage", {}))
                lineage["retry_count"] = task.retry_count
                task.inputs["_lineage"] = lineage
                await asyncio.sleep(self.retry_delay_seconds)
                await self._schedule_task(task)
            else:
                task.error = result.error
                self.failed_tasks[task_id] = task

                if self.on_task_fail:
                    await self.on_task_fail(task, result)

        # Update memory
        self._update_memory(task, "task_completed" if result.success else "task_failed")
        self._persist_task_snapshot(task)

        # Log trace
        self._log_trace(
            "task_completed" if result.success else "task_failed",
            {
                "task_id": task_id,
                "success": result.success,
                "execution_time_ms": result.execution_time_ms,
                "error": result.error,
                "trace_id": task.trace_id
            }
        )

    def _update_memory(self, task: Task, event_type: str):
        """Update short-term memory"""
        session_id = task.inputs.get("session_id", "default")

        memory_entry = {
            "task_id": task.task_id,
            "event_type": event_type,
            "task_type": task.task_type,
            "timestamp": datetime.now(timezone.utc).replace(tzinfo=None).isoformat(),
            "trace_id": task.trace_id
        }

        self.short_term_memory[session_id].append(memory_entry)

        # Limit memory size
        if len(self.short_term_memory[session_id]) > 100:
            self.short_term_memory[session_id] = self.short_term_memory[session_id][-100:]

    def _log_trace(self, event_type: str, data: Dict):
        """Log execution trace"""
        trace = {
            "event_type": event_type,
            "timestamp": datetime.now(timezone.utc).replace(tzinfo=None).isoformat(),
            "data": data
        }
        self.trace_history.append(trace)

        # Limit trace history
        if len(self.trace_history) > 10000:
            self.trace_history = self.trace_history[-5000:]

    async def route_message(self, message: AgentMessage):
        """Route message between agents"""
        for recipient in message.recipients:
            agent = self.agents.get(recipient)
            if agent:
                await agent.message_queue.put(message)

    async def submit_task(
        self,
        task_type: str,
        description: str,
        inputs: Dict[str, Any],
        constraints: Optional[Dict] = None,
        priority: TaskPriority = TaskPriority.NORMAL
    ) -> str:
        """Submit a new task for execution."""
        task_constraints = constraints or {}
        task_inputs = dict(inputs)

        contradiction_flags: List[ContradictionFlag] = []
        for contradiction in task_constraints.get("contradictions", []):
            contradiction_flags.append(
                ContradictionFlag(
                    field_a=contradiction.get("field_a", "unknown_a"),
                    field_b=contradiction.get("field_b", "unknown_b"),
                    description=contradiction.get("description", "constraint contradiction"),
                    severity=float(contradiction.get("severity", 0.25)),
                )
            )

        risk_levels = task_constraints.get("action_risk_levels", ["low"])
        assessment = self.reasoner.assess(
            task_description=description,
            action_risk_levels=risk_levels,
            contradictions=contradiction_flags,
        )

        override_mode = str(task_constraints.get("reasoning_override", "")).lower().strip()
        if override_mode in {"normal", "cautious", "defer"}:
            assessment.execution_mode = ReasoningMode(override_mode)
            if override_mode == "defer" and not assessment.defer_reason:
                assessment.defer_reason = "Deferred by explicit reasoning override"

        task = Task(
            task_id=f"task_{self._task_counter + 1:06d}",
            task_type=task_type,
            description=description,
            priority=priority,
            inputs=task_inputs,
            constraints=task_constraints,
            deadline=datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(seconds=self.default_timeout_seconds),
            reasoning_assessment=assessment,
        )
        existing_lineage = task.inputs.get("_lineage")
        if existing_lineage and existing_lineage.get("request_id"):
            task.inputs["_lineage"] = normalize_lineage(
                raw_lineage=existing_lineage,
                trace_id=task.trace_id,
                session_id=task.inputs.get("session_id"),
                parent_task_id=task.parent_task_id,
                source=existing_lineage.get("source", "submit_task"),
                source_message_id=task.inputs.get("source_message_id"),
                input_payload=task.inputs,
            )
        else:
            task.inputs["_lineage"] = normalize_lineage(
                raw_lineage=existing_lineage,
                trace_id=task.trace_id,
                session_id=task.inputs.get("session_id"),
                parent_task_id=task.parent_task_id,
                source="submit_task",
                source_message_id=task.inputs.get("source_message_id"),
                input_payload=task.inputs,
            )

        await self.task_queue.put((priority.value, task))

        return task.task_id

    async def submit_protocol_task(
        self,
        raw_message: Dict[str, Any],
        *,
        shared_token: Optional[str] = None,
        priority: TaskPriority = TaskPriority.NORMAL,
    ) -> str:
        """Submit an external protocol message as a native orchestrator task."""
        normalized = self.protocol_registry.normalize(raw_message, shared_token=shared_token)

        constraints = dict(normalized.constraints)
        context = dict(normalized.context)
        context["source_protocol"] = normalized.source_protocol
        context["source_message_id"] = normalized.source_message_id
        context["_lineage"] = normalize_lineage(
            raw_lineage=context.get("_lineage"),
            session_id=context.get("session_id"),
            source="protocol_ingress",
            source_message_id=normalized.source_message_id,
            input_payload=context,
        )

        return await self.submit_task(
            task_type="protocol_delegated",
            description=f"{normalized.title}: {normalized.objective}",
            inputs=context,
            constraints=constraints,
            priority=priority,
        )

    async def get_task_status(self, task_id: str) -> Optional[Dict]:
        """Get task execution status"""
        await asyncio.sleep(0)
        task = self.active_tasks.get(task_id)
        if not task:
            task = self.completed_tasks.get(task_id) or self.failed_tasks.get(task_id)

        if task:
            assessment = task.reasoning_assessment
            return {
                "task_id": task.task_id,
                "status": task.status.value,
                "priority": task.priority.value,
                "assigned_agent": task.assigned_agent,
                "created_at": task.created_at.isoformat(),
                "started_at": task.started_at.isoformat() if task.started_at else None,
                "completed_at": task.completed_at.isoformat() if task.completed_at else None,
                "error": task.error,
                "outputs": task.outputs,
                "trace_id": task.trace_id,
                "lineage": task.inputs.get("_lineage"),
                "reasoning_confidence": assessment.confidence_score if assessment else None,
                "reasoning_mode": assessment.execution_mode.value if assessment else None,
                "reasoning_deferred": bool(assessment and assessment.execution_mode.value == "defer"),
            }

        snapshot = self.lineage_repository.get_latest_task_snapshot(task_id)
        if snapshot:
            return {
                "task_id": snapshot.get("task_id"),
                "status": snapshot.get("status"),
                "priority": None,
                "assigned_agent": None,
                "created_at": None,
                "started_at": None,
                "completed_at": snapshot.get("persisted_at"),
                "error": snapshot.get("error"),
                "outputs": snapshot.get("outputs") or {},
                "trace_id": snapshot.get("trace_id"),
                "lineage": snapshot.get("lineage") or {},
                "reasoning_confidence": None,
                "reasoning_mode": None,
                "reasoning_deferred": False,
            }

        return None

    @staticmethod
    def _task_matches_lineage_filters(
        lineage: Dict[str, Any],
        *,
        trace_id: Optional[str],
        request_id: Optional[str],
        source_message_id: Optional[str],
    ) -> bool:
        if trace_id and lineage.get("trace_id") != trace_id:
            return False
        if request_id and lineage.get("request_id") != request_id:
            return False
        if source_message_id and lineage.get("source_message_id") != source_message_id:
            return False
        return True

    @staticmethod
    def _task_search_result(task: Task, lineage: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "task_id": task.task_id,
            "status": task.status.value,
            "task_type": task.task_type,
            "description": task.description,
            "trace_id": lineage.get("trace_id") or task.trace_id,
            "lineage": lineage,
        }

    @staticmethod
    def _snapshot_search_result(snapshot: Dict[str, Any]) -> Dict[str, Any]:
        lineage = dict(snapshot.get("lineage") or {})
        return {
            "task_id": snapshot.get("task_id"),
            "status": snapshot.get("status"),
            "task_type": snapshot.get("task_type"),
            "description": snapshot.get("description"),
            "trace_id": lineage.get("trace_id") or snapshot.get("trace_id"),
            "lineage": lineage,
        }

    def _collect_live_task_search_results(
        self,
        seen_task_ids: Set[str],
        *,
        trace_id: Optional[str],
        request_id: Optional[str],
        source_message_id: Optional[str],
    ) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []
        for task_map in (self.active_tasks, self.completed_tasks, self.failed_tasks):
            for task in task_map.values():
                if task.task_id in seen_task_ids:
                    continue

                lineage = dict(task.inputs.get("_lineage") or {})
                if not self._task_matches_lineage_filters(
                    lineage,
                    trace_id=trace_id,
                    request_id=request_id,
                    source_message_id=source_message_id,
                ):
                    continue

                seen_task_ids.add(task.task_id)
                results.append(self._task_search_result(task, lineage))

        return results

    def _collect_persisted_task_search_results(
        self,
        seen_task_ids: Set[str],
        *,
        trace_id: Optional[str],
        request_id: Optional[str],
        source_message_id: Optional[str],
    ) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []
        for snapshot in self.lineage_repository.search_latest_task_snapshots(
            trace_id=trace_id,
            request_id=request_id,
            source_message_id=source_message_id,
        ):
            task_id = snapshot.get("task_id")
            if not task_id or task_id in seen_task_ids:
                continue

            seen_task_ids.add(task_id)
            results.append(self._snapshot_search_result(snapshot))

        return results

    async def search_tasks(
        self,
        *,
        trace_id: Optional[str] = None,
        request_id: Optional[str] = None,
        source_message_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Search tasks by lineage identifiers across active and historical task state."""
        await asyncio.sleep(0)

        seen_task_ids: Set[str] = set()
        live_results = self._collect_live_task_search_results(
            seen_task_ids,
            trace_id=trace_id,
            request_id=request_id,
            source_message_id=source_message_id,
        )
        persisted_results = self._collect_persisted_task_search_results(
            seen_task_ids,
            trace_id=trace_id,
            request_id=request_id,
            source_message_id=source_message_id,
        )

        return [*live_results, *persisted_results]

    async def create_task_graph(self, root_task: Task) -> str:
        """Create and execute task graph"""
        await asyncio.sleep(0)
        graph_id = f"graph_{len(self.task_graphs) + 1:06d}"
        graph = TaskGraph(graph_id)

        # Add root node
        _ = graph.add_node(root_task, "reasoning")
        graph.execution_order.append(root_task.task_id)

        # Plan execution using planner agent
        _ = AgentMessage(
            message_id=str(uuid.uuid4()),
            message_type=MessageType.TASK_DISPATCH,
            sender="orchestrator",
            recipients=["planner_01"],
            task_id=root_task.task_id,
            payload={"task": root_task}
        )

        # Execute graph
        for node_id in graph.execution_order:
            node = graph.nodes.get(node_id)
            if node:
                node.state = "running"
                # Execute node
                node.state = "completed"

        self.task_graphs[graph_id] = graph
        return graph_id

    def get_system_status(self) -> Dict:
        """Get current system status"""
        return {
            "status": "running" if self._running else "stopped",
            "active_agents": len(self.agents),
            "active_tasks": len(self.active_tasks),
            "completed_tasks": len(self.completed_tasks),
            "failed_tasks": len(self.failed_tasks),
            "queue_size": self.task_queue.qsize(),
            "agents": {
                agent_id: {
                    "status": agent.status,
                    "current_tasks": len(agent.current_tasks),
                    "capabilities": agent.capabilities
                }
                for agent_id, agent in self.agents.items()
            },
            "memory_entries": sum(len(v) for v in self.short_term_memory.values())
        }


class VectorMemoryStore:
    """Vector-based memory store for semantic retrieval"""

    def __init__(self):
        self.embeddings = []
        self.metadata = []
        self._initialized = False

    async def initialize(self):
        """Initialize vector store"""
        await asyncio.sleep(0)
        self._initialized = True
        logger.info("Vector memory store initialized")

    async def add(self, content: str, metadata: Dict) -> str:
        """Add content to vector store"""
        await asyncio.sleep(0)
        memory_id = f"mem_{len(self.embeddings):08d}"

        # In production, would generate actual embeddings
        embedding = [0.0] * 1536  # Placeholder

        self.embeddings.append(embedding)
        self.metadata.append({
            "id": memory_id,
            "content": content,
            "metadata": metadata,
            "created_at": datetime.now(timezone.utc).replace(tzinfo=None).isoformat()
        })

        return memory_id

    async def retrieve(self, query: str, top_k: int = 5) -> List[Dict]:
        """Retrieve relevant memories"""
        await asyncio.sleep(0)
        if not self._initialized:
            return []

        # In production, would generate query embedding and perform ANN search
        # Return simulated results
        results = []
        for i, meta in enumerate(self.metadata[-top_k:]):
            results.append({
                "id": meta["id"],
                "content": meta["content"],
                "score": 0.8 - (i * 0.1),
                "metadata": meta["metadata"]
            })

        return results

    async def delete(self, memory_id: str):
        """Delete memory by ID"""
        await asyncio.sleep(0)
        for i, meta in enumerate(self.metadata):
            if meta["id"] == memory_id:
                del self.embeddings[i]
                del self.metadata[i]
                break


# =============================================================================
# MAIN ENTRY POINT
# =============================================================================

async def main():
    """Main entry point for AI-OS Orchestrator"""
    orchestrator = Orchestrator()

    try:
        # Initialize
        await orchestrator.initialize()

        # Submit sample tasks
        task_id_1 = await orchestrator.submit_task(
            task_type="analysis",
            description="Analyze market trends for Q4 2024",
            inputs={"query": "market trends Q4 2024"},
            constraints={
                "required_capabilities": ["research"],
                "tools_allowed": ["web_search"]
            },
            priority=TaskPriority.NORMAL
        )

        task_id_2 = await orchestrator.submit_task(
            task_type="code_generation",
            description="Generate Python function for data processing",
            inputs={"function_name": "process_data", "input_type": "list"},
            constraints={
                "required_capabilities": ["code_execution"],
                "output_format": "json"
            },
            priority=TaskPriority.HIGH
        )

        # Wait for tasks to complete
        await asyncio.sleep(5)

        # Check status
        status = orchestrator.get_system_status()
        print(f"System Status: {status}")

        # Get task results
        result_1 = await orchestrator.get_task_status(task_id_1)
        result_2 = await orchestrator.get_task_status(task_id_2)

        print(f"Task 1: {result_1}")
        print(f"Task 2: {result_2}")

    finally:
        await orchestrator.shutdown()


if __name__ == "__main__":
    asyncio.run(main())