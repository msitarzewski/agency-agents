"""Helpers for linking inputs, tasks, tools, and outputs through one lineage chain."""

from __future__ import annotations

import hashlib
import json
import uuid
from typing import Any, Dict, Mapping, Optional


def _stable_hash(value: Any) -> str:
    try:
        payload = json.dumps(value, sort_keys=True, default=str)
    except TypeError:
        payload = repr(value)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def hash_lineage_payload(value: Any) -> str:
    return _stable_hash(value)


def _normalize_sequence_field(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return list(value)
    if isinstance(value, tuple):
        return list(value)
    return [value]


def normalize_lineage(
    raw_lineage: Optional[Mapping[str, Any]],
    *,
    trace_id: Optional[str] = None,
    session_id: Optional[str] = None,
    parent_task_id: Optional[str] = None,
    source: str = "api",
    source_message_id: Optional[str] = None,
    input_payload: Optional[Any] = None,
) -> Dict[str, Any]:
    lineage = dict(raw_lineage or {})
    lineage.setdefault("request_id", str(uuid.uuid4()))
    lineage.setdefault("trace_id", trace_id or str(uuid.uuid4()))
    lineage.setdefault("source", source)
    lineage["tool_invocation_ids"] = _normalize_sequence_field(lineage.get("tool_invocation_ids"))
    lineage["memory_refs"] = _normalize_sequence_field(lineage.get("memory_refs"))

    if session_id is not None:
        lineage["session_id"] = session_id
    else:
        lineage.setdefault("session_id", None)

    if parent_task_id is not None:
        lineage["parent_task_id"] = parent_task_id
    else:
        lineage.setdefault("parent_task_id", None)

    if source_message_id is not None:
        lineage["source_message_id"] = source_message_id
    else:
        lineage.setdefault("source_message_id", None)

    if input_payload is not None:
        lineage["input_hash"] = _stable_hash(input_payload)
    else:
        lineage.setdefault("input_hash", None)

    lineage.setdefault("output_ref", None)
    return lineage


def append_tool_invocation(lineage: Mapping[str, Any], invocation_id: str) -> Dict[str, Any]:
    normalized = dict(lineage)
    invocation_ids = _normalize_sequence_field(normalized.get("tool_invocation_ids"))
    invocation_ids.append(invocation_id)
    normalized["tool_invocation_ids"] = invocation_ids
    return normalized
