"""Mythos-inspired reasoning reliability utilities.

This module provides confidence and contradiction assessment that can be wired
into orchestration and execution safety controls.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class ReasoningMode(Enum):
    """Execution mode determined by confidence and risk checks."""

    NORMAL = "normal"
    CAUTIOUS = "cautious"
    DEFER = "defer"


@dataclass(frozen=True)
class ContradictionFlag:
    """Structured contradiction marker produced by pre-execution analysis."""

    field_a: str
    field_b: str
    description: str
    severity: float


@dataclass
class ReasoningAssessment:
    """Assessment output used for downstream policy gating and telemetry."""

    confidence_score: float
    execution_mode: ReasoningMode
    contradiction_flags: List[ContradictionFlag] = field(default_factory=list)
    defer_reason: Optional[str] = None
    bypassed_by_flag: bool = False


class MythosReasoner:
    """Confidence-aware reasoner with conservative fallbacks."""

    _RISK_PENALTIES = {
        "low": 0.05,
        "medium": 0.2,
        "high": 0.45,
        "critical": 0.7,
    }

    def __init__(
        self,
        enabled: bool = False,
        cautious_threshold: float = 0.8,
        defer_threshold: float = 0.4,
    ):
        self.enabled = enabled
        self.cautious_threshold = cautious_threshold
        self.defer_threshold = defer_threshold

    def assess(
        self,
        task_description: str,
        action_risk_levels: List[str],
        contradictions: List[ContradictionFlag],
    ) -> ReasoningAssessment:
        """Assess execution confidence and compute execution mode."""
        _ = task_description
        if not self.enabled:
            return ReasoningAssessment(
                confidence_score=1.0,
                execution_mode=ReasoningMode.NORMAL,
                contradiction_flags=list(contradictions),
                bypassed_by_flag=True,
            )

        normalized_levels = [level.lower() for level in action_risk_levels]
        highest_risk_penalty = max(
            [self._RISK_PENALTIES.get(level, 0.2) for level in normalized_levels] or [0.05]
        )

        contradiction_penalty = min(sum(flag.severity for flag in contradictions) * 0.5, 0.5)
        confidence_score = max(0.0, 1.0 - highest_risk_penalty - contradiction_penalty)

        has_critical = "critical" in normalized_levels
        has_high = "high" in normalized_levels
        too_many_contradictions = len(contradictions) >= 2

        if has_critical or confidence_score <= self.defer_threshold or too_many_contradictions:
            return ReasoningAssessment(
                confidence_score=confidence_score,
                execution_mode=ReasoningMode.DEFER,
                contradiction_flags=list(contradictions),
                defer_reason="High-risk or low-confidence plan requires human approval.",
            )

        if has_high or confidence_score < self.cautious_threshold or contradictions:
            return ReasoningAssessment(
                confidence_score=confidence_score,
                execution_mode=ReasoningMode.CAUTIOUS,
                contradiction_flags=list(contradictions),
            )

        return ReasoningAssessment(
            confidence_score=confidence_score,
            execution_mode=ReasoningMode.NORMAL,
            contradiction_flags=list(contradictions),
        )

    @staticmethod
    def to_metadata(assessment: ReasoningAssessment) -> Dict[str, Any]:
        """Serialize assessment for logs and API payloads."""
        return {
            "confidence_score": float(assessment.confidence_score),
            "execution_mode": assessment.execution_mode.value,
            "defer_reason": assessment.defer_reason,
            "bypassed_by_flag": assessment.bypassed_by_flag,
            "contradiction_flags": [
                {
                    "field_a": flag.field_a,
                    "field_b": flag.field_b,
                    "description": flag.description,
                    "severity": flag.severity,
                }
                for flag in assessment.contradiction_flags
            ],
        }


# Backward compatibility alias for existing imports.
ExecutionMode = ReasoningMode


def assess_risk_and_reasoning(
    task_description: str,
    action_risk_levels: List[str],
    contradictions: List[ContradictionFlag],
    enabled: bool,
) -> ReasoningAssessment:
    """Convenience helper for one-shot assessment."""
    reasoner = MythosReasoner(enabled=enabled)
    return reasoner.assess(
        task_description=task_description,
        action_risk_levels=action_risk_levels,
        contradictions=contradictions,
    )
