"""
AI-OS Model Routing Engine
Production-Grade Dynamic Model Selection and Cost Control
"""

import asyncio
import uuid
import time
from datetime import datetime, timedelta, UTC
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TaskComplexity(Enum):
    """Task complexity classification"""
    TRIVIAL = 0
    SIMPLE = 1
    MODERATE = 2
    COMPLEX = 3
    HIGHLY_COMPLEX = 4


class ModelTier(Enum):
    """Model capability tiers"""
    FAST = "fast"          # Low latency, lower cost
    STANDARD = "standard" # Balanced
    ADVANCED = "advanced"  # High capability
    PREMIUM = "premium"    # Best quality


@dataclass
class Model:
    """Model configuration"""
    model_id: str
    provider: str
    tier: ModelTier
    max_tokens: int
    latency_ms_estimate: int
    cost_per_1k_input: float
    cost_per_1k_output: float

    # Capabilities
    supports_multimodal: bool = False
    supports_code: bool = False
    supports_reasoning: bool = False
    supports_long_context: bool = False

    # Limits
    requests_per_minute: int = 100
    tokens_per_minute: int = 100000

    # Fallback
    fallback_model_id: Optional[str] = None


@dataclass
class RouteDecision:
    """Model routing decision"""
    selected_model: Model
    confidence: float
    reasoning: str
    estimated_cost: float
    estimated_latency_ms: int
    alternative_models: List[Model] = field(default_factory=list)


@dataclass
class TokenBudget:
    """Token budget for cost control"""
    max_tokens: int
    current_usage: int = 0
    budget_type: str = "per_request"  # per_request, hourly, daily

    def can_spend(self, tokens: int) -> bool:
        return (self.max_tokens - self.current_usage) >= tokens

    def spend(self, tokens: int) -> bool:
        if self.can_spend(tokens):
            self.current_usage += tokens
            return True
        return False


class ComplexityClassifier:
    """Classify task complexity for routing"""

    # Keywords indicating high complexity
    HIGH_COMPLEXITY_KEYWORDS = [
        "analyze", "research", "complex", "detailed", "comprehensive",
        "reasoning", "logic", "compare", "evaluate", "design",
        "architect", "strategy", "optimize", "synthesize"
    ]

    # Keywords indicating multimodal
    MULTIMODAL_KEYWORDS = [
        "image", "video", "audio", "picture", "photo", "diagram",
        "chart", "graph", "visual", "sound", "speech"
    ]

    # Keywords indicating code
    CODE_KEYWORDS = [
        "code", "programming", "function", "algorithm", "debug",
        "implement", "script", "api", "database", "software"
    ]

    def classify(
        self,
        query: str,
        history: Optional[List[Dict]] = None,
        context: Optional[Dict] = None
    ) -> TaskComplexity:
        """Classify task complexity"""
        query_lower = query.lower()

        # Count complexity indicators
        complexity_score = 0

        # Length-based scoring
        word_count = len(query.split())
        if word_count > 500:
            complexity_score += 2
        elif word_count > 200:
            complexity_score += 1

        # Keyword-based scoring
        for keyword in self.HIGH_COMPLEXITY_KEYWORDS:
            if keyword in query_lower:
                complexity_score += 1

        # Dependency chain (from history)
        if history:
            complexity_score += min(len(history) // 5, 2)

        # Context-based complexity
        if context:
            if context.get("requires_reasoning"):
                complexity_score += 1
            if context.get("requires_creativity"):
                complexity_score += 1

        # Map to complexity level
        if complexity_score >= 6:
            return TaskComplexity.HIGHLY_COMPLEX
        elif complexity_score >= 4:
            return TaskComplexity.COMPLEX
        elif complexity_score >= 2:
            return TaskComplexity.MODERATE
        elif complexity_score >= 1:
            return TaskComplexity.SIMPLE
        else:
            return TaskComplexity.TRIVIAL

    def requires_multimodal(self, query: str) -> bool:
        """Check if query requires multimodal model"""
        query_lower = query.lower()
        return any(kw in query_lower for kw in self.MULTIMODAL_KEYWORDS)

    def requires_code(self, query: str) -> bool:
        """Check if query requires code-capable model"""
        query_lower = query.lower()
        return any(kw in query_lower for kw in self.CODE_KEYWORDS)

    def estimate_tokens(self, query: str) -> int:
        """Estimate token count for query"""
        # Rough estimation: ~1.3 tokens per word
        return int(len(query.split()) * 1.3)


class ModelRouter:
    """Dynamic model selection engine"""

    def __init__(self):
        self.models: Dict[str, Model] = {}
        self.complexity_classifier = ComplexityClassifier()

        # Budgets
        self.hourly_budget = TokenBudget(max_tokens=500000, budget_type="hourly")
        self.daily_budget = TokenBudget(max_tokens=5000000, budget_type="daily")
        self.request_budget = TokenBudget(max_tokens=128000, budget_type="per_request")

        # Caching
        self.response_cache: Dict[str, Dict] = {}
        self.cache_ttl_seconds = 300

        # Circuit breaker
        self.model_health: Dict[str, Dict] = {}
        self.circuit_breaker_threshold = 5
        self.circuit_breaker_timeout = 60

        self._initialize_models()

    def _initialize_models(self):
        """Initialize available models"""
        # OpenAI models
        self.models["gpt-4-turbo"] = Model(
            model_id="gpt-4-turbo",
            provider="openai",
            tier=ModelTier.ADVANCED,
            max_tokens=128000,
            latency_ms_estimate=2000,
            cost_per_1k_input=0.01,
            cost_per_1k_output=0.03,
            supports_reasoning=True,
            supports_code=True,
            supports_long_context=True,
            fallback_model_id="gpt-4"
        )

        self.models["gpt-3.5-turbo"] = Model(
            model_id="gpt-3.5-turbo",
            provider="openai",
            tier=ModelTier.FAST,
            max_tokens=16385,
            latency_ms_estimate=500,
            cost_per_1k_input=0.0005,
            cost_per_1k_output=0.0015,
            supports_code=True,
            fallback_model_id=None
        )

        # Anthropic models
        self.models["claude-3-opus"] = Model(
            model_id="claude-3-opus",
            provider="anthropic",
            tier=ModelTier.PREMIUM,
            max_tokens=200000,
            latency_ms_estimate=3000,
            cost_per_1k_input=0.015,
            cost_per_1k_output=0.075,
            supports_reasoning=True,
            supports_multimodal=True,
            supports_long_context=True,
            fallback_model_id="claude-3-sonnet"
        )

        self.models["claude-3-sonnet"] = Model(
            model_id="claude-3-sonnet",
            provider="anthropic",
            tier=ModelTier.ADVANCED,
            max_tokens=200000,
            latency_ms_estimate=1500,
            cost_per_1k_input=0.003,
            cost_per_1k_output=0.015,
            supports_reasoning=True,
            supports_multimodal=True,
            fallback_model_id="claude-3-haiku"
        )

        # Google models
        self.models["gemini-pro"] = Model(
            model_id="gemini-pro",
            provider="google",
            tier=ModelTier.STANDARD,
            max_tokens=32000,
            latency_ms_estimate=1000,
            cost_per_1k_input=0.001,
            cost_per_1k_output=0.002,
            supports_multimodal=True,
            fallback_model_id="gemini-flash"
        )

        # Initialize health tracking
        for model_id in self.models:
            self.model_health[model_id] = {
                "success_count": 0,
                "failure_count": 0,
                "last_failure_time": None,
                "circuit_open": False
            }

    def route(
        self,
        query: str,
        context: Optional[Dict] = None,
        constraints: Optional[Dict] = None
    ) -> RouteDecision:
        """
        Route query to optimal model
        Combines complexity analysis, cost control, and capability matching
        """
        # Step 1: Classify complexity
        complexity = self.complexity_classifier.classify(
            query=query,
            context=context
        )

        # Step 2: Check cache
        cache_key = self._generate_cache_key(query, complexity)
        if cache_key in self.response_cache:
            cached = self.response_cache[cache_key]
            if (datetime.now(UTC) - cached["timestamp"]).total_seconds() < self.cache_ttl_seconds:
                return cached["decision"]

        # Step 3: Determine required capabilities
        requires_multimodal = self.complexity_classifier.requires_multimodal(query)
        requires_code = self.complexity_classifier.requires_code(query)

        # Step 4: Budget check
        estimated_tokens = self.complexity_classifier.estimate_tokens(query)
        if not self.request_budget.can_spend(estimated_tokens):
            logger.warning("Request budget exceeded, using lower tier model")

        # Step 5: Find available models
        candidates = self._find_candidates(
            complexity=complexity,
            requires_multimodal=requires_multimodal,
            requires_code=requires_code,
            constraints=constraints
        )

        if not candidates:
            # Fallback to default
            candidates = [self.models["gpt-3.5-turbo"]]

        # Step 6: Select optimal model
        selected = self._select_model(candidates, complexity, constraints)

        # Step 7: Calculate estimates
        estimated_cost = self._estimate_cost(selected, estimated_tokens)
        estimated_latency = selected.latency_ms_estimate

        decision = RouteDecision(
            selected_model=selected,
            confidence=self._calculate_confidence(selected, complexity),
            reasoning=self._generate_routing_reasoning(
                query, complexity, selected, requires_multimodal, requires_code
            ),
            estimated_cost=estimated_cost,
            estimated_latency_ms=estimated_latency,
            alternative_models=candidates[1:4] if len(candidates) > 1 else []
        )

        # Step 8: Update budgets
        self.request_budget.spend(estimated_tokens)

        # Step 9: Cache decision
        self.response_cache[cache_key] = {
            "decision": decision,
            "timestamp": datetime.now(UTC)
        }

        return decision

    def _find_candidates(
        self,
        complexity: TaskComplexity,
        requires_multimodal: bool,
        requires_code: bool,
        constraints: Optional[Dict]
    ) -> List[Model]:
        """Find candidate models matching requirements"""
        candidates = []

        # Get models by tier based on complexity
        tier_map = {
            TaskComplexity.TRIVIAL: [ModelTier.FAST],
            TaskComplexity.SIMPLE: [ModelTier.FAST, ModelTier.STANDARD],
            TaskComplexity.MODERATE: [ModelTier.STANDARD, ModelTier.ADVANCED],
            TaskComplexity.COMPLEX: [ModelTier.ADVANCED, ModelTier.PREMIUM],
            TaskComplexity.HIGHLY_COMPLEX: [ModelTier.PREMIUM]
        }

        preferred_tiers = tier_map.get(complexity, [ModelTier.STANDARD])

        for model_id, model in self.models.items():
            # Check health
            if not self._is_model_healthy(model_id):
                continue

            # Check tier
            if model.tier not in preferred_tiers:
                continue

            # Check capabilities
            if requires_multimodal and not model.supports_multimodal:
                continue

            if requires_code and not model.supports_code:
                continue

            # Check context length
            estimated_tokens = constraints.get("estimated_tokens", 8000) if constraints else 8000
            if estimated_tokens > model.max_tokens:
                continue

            candidates.append(model)

        # Sort by cost-efficiency
        candidates.sort(key=lambda m: (m.cost_per_1k_input + m.cost_per_1k_output) * 0.5)

        return candidates

    def _select_model(
        self,
        candidates: List[Model],
        complexity: TaskComplexity,
        constraints: Optional[Dict]
    ) -> Model:
        """Select best model from candidates"""
        if not candidates:
            return self.models["gpt-3.5-turbo"]

        # In budget-constrained mode, select cheapest
        if constraints and constraints.get("budget_constrained"):
            return candidates[-1]  # Last after cost sort is cheapest

        # Otherwise select based on complexity
        if complexity in [TaskComplexity.TRIVIAL, TaskComplexity.SIMPLE]:
            return candidates[0]
        else:
            return candidates[min(1, len(candidates) - 1)]

    def _is_model_healthy(self, model_id: str) -> bool:
        """Check if model is healthy (circuit breaker)"""
        health = self.model_health.get(model_id, {})

        # Check if circuit is open
        if health.get("circuit_open"):
            last_failure = health.get("last_failure_time")
            if last_failure:
                timeout = timedelta(seconds=self.circuit_breaker_timeout)
                if datetime.now(UTC) - last_failure < timeout:
                    return False
                else:
                    # Reset circuit
                    self.model_health[model_id]["circuit_open"] = False
                    self.model_health[model_id]["failure_count"] = 0

        return True

    def record_success(self, model_id: str):
        """Record successful model invocation"""
        if model_id in self.model_health:
            self.model_health[model_id]["success_count"] += 1

    def record_failure(self, model_id: str):
        """Record failed model invocation"""
        if model_id in self.model_health:
            health = self.model_health[model_id]
            health["failure_count"] += 1
            health["last_failure_time"] = datetime.now(UTC)

            # Open circuit if threshold exceeded
            if health["failure_count"] >= self.circuit_breaker_threshold:
                health["circuit_open"] = True
                logger.warning(f"Circuit breaker opened for {model_id}")

    def _estimate_cost(self, model: Model, token_count: int) -> float:
        """Estimate cost for model usage"""
        input_cost = (token_count / 1000) * model.cost_per_1k_input
        output_cost = (token_count * 1.5 / 1000) * model.cost_per_1k_output  # Assume 1.5x output
        return input_cost + output_cost

    def _calculate_confidence(self, model: Model, complexity: TaskComplexity) -> float:
        """Calculate confidence in model selection"""
        confidence = 0.7  # Base confidence

        # Higher tier for complex tasks
        if complexity in [TaskComplexity.COMPLEX, TaskComplexity.HIGHLY_COMPLEX]:
            if model.tier in [ModelTier.ADVANCED, ModelTier.PREMIUM]:
                confidence += 0.2

        # Supports required features
        if model.supports_reasoning:
            confidence += 0.1

        return min(confidence, 1.0)

    def _generate_routing_reasoning(
        self,
        query: str,
        complexity: TaskComplexity,
        model: Model,
        requires_multimodal: bool,
        requires_code: bool
    ) -> str:
        """Generate human-readable routing explanation"""
        reasons = [
            f"Task complexity: {complexity.name}",
            f"Selected model: {model.model_id} ({model.tier.value})",
            f"Provider: {model.provider}"
        ]

        if requires_multimodal:
            reasons.append("Requires multimodal capability")
        if requires_code:
            reasons.append("Requires code generation capability")

        return "; ".join(reasons)

    def _generate_cache_key(self, query: str, complexity: TaskComplexity) -> str:
        """Generate cache key for response"""
        import hashlib
        content = f"{query[:100]}:{complexity.value}"
        return hashlib.md5(content.encode()).hexdigest()

    def get_metrics(self) -> Dict[str, Any]:
        """Get router metrics"""
        total_requests = sum(
            h["success_count"] + h["failure_count"]
            for h in self.model_health.values()
        )

        return {
            "total_models": len(self.models),
            "total_requests": total_requests,
            "cache_size": len(self.response_cache),
            "budget": {
                "hourly_remaining": self.hourly_budget.max_tokens - self.hourly_budget.current_usage,
                "daily_remaining": self.daily_budget.max_tokens - self.daily_budget.current_usage
            },
            "model_health": {
                model_id: {
                    "success": h["success_count"],
                    "failures": h["failure_count"],
                    "circuit_open": h["circuit_open"]
                }
                for model_id, h in self.model_health.items()
            }
        }


class CostControlEngine:
    """Cost control and optimization engine"""

    def __init__(self, model_router: ModelRouter):
        self.router = model_router
        self.total_spent = 0.0
        self.daily_limit = 100.0  # $100 per day
        self.monthly_limit = 1000.0  # $1000 per month

    def check_budget(self, estimated_cost: float) -> bool:
        """Check if estimated cost is within budget"""
        if self.total_spent + estimated_cost > self.daily_limit:
            logger.warning(f"Daily budget exceeded: ${self.total_spent:.2f} / ${self.daily_limit}")
            return False
        return True

    def record_cost(self, cost: float):
        """Record actual cost"""
        self.total_spent += cost

    def reset_daily(self):
        """Reset daily budget tracking"""
        self.total_spent = 0.0

    def get_spending_report(self) -> Dict[str, Any]:
        """Get spending report"""
        return {
            "total_spent": self.total_spent,
            "daily_limit": self.daily_limit,
            "monthly_limit": self.monthly_limit,
            "daily_utilization": self.total_spent / self.daily_limit,
            "monthly_projection": self.total_spent * 30
        }


# =============================================================================
# SELF-CRITIQUE LOOP
# =============================================================================

class SelfCritiqueLoop:
    """
    Self-critique loop for iterative improvement
    Implements generation → critique → revision cycle
    """

    def __init__(self, max_iterations: int = 3, confidence_threshold: float = 0.8):
        self.max_iterations = max_iterations
        self.confidence_threshold = confidence_threshold

    async def critique(
        self,
        content: str,
        criteria: List[str],
        context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Critique content against criteria"""
        issues = []
        suggestions = []
        score = 1.0

        for criterion in criteria:
            result = await self._evaluate_criterion(content, criterion, context)
            issues.extend(result["issues"])
            suggestions.extend(result["suggestions"])
            score *= result["score"]

        return {
            "confidence": max(score, 0.0),
            "issues": issues,
            "suggestions": suggestions,
            "quality_score": score,
            "needs_revision": score < self.confidence_threshold
        }

    async def _evaluate_criterion(
        self,
        content: str,
        criterion: str,
        context: Optional[Dict]
    ) -> Dict[str, Any]:
        """Evaluate content against single criterion"""
        issues = []
        suggestions = []
        score = 1.0

        # Length check
        if criterion == "completeness":
            if len(content.split()) < 50:
                issues.append("Content too brief")
                suggestions.append("Add more detailed explanation")
                score *= 0.8

        # Coherence check
        elif criterion == "coherence":
            # Check for abrupt transitions
            if "..." in content and content.count("\n") < 3:
                issues.append("Abrupt transitions detected")
                suggestions.append("Add smooth transitions between topics")
                score *= 0.9

        # Accuracy check
        elif criterion == "accuracy":
            # Check for potentially incorrect claims
            uncertain_phrases = ["might", "could be", "probably", "possibly"]
            if any(p in content.lower() for p in uncertain_phrases):
                issues.append("Contains uncertain claims")
                suggestions.append("Verify factual accuracy")
                score *= 0.85

        # Relevance check
        elif criterion == "relevance":
            if context and "query" in context:
                query_terms = set(context["query"].lower().split())
                content_terms = set(content.lower().split())
                overlap = len(query_terms & content_terms) / max(len(query_terms), 1)
                if overlap < 0.3:
                    issues.append("Low relevance to query")
                    suggestions.append("Focus more on query topics")
                    score *= 0.7

        return {
            "score": score,
            "issues": issues,
            "suggestions": suggestions
        }

    async def revise(
        self,
        content: str,
        issues: List[str],
        suggestions: List[str]
    ) -> str:
        """Revise content based on critique"""
        revised = content

        # Apply each suggestion
        for suggestion in suggestions:
            if "more detail" in suggestion.lower():
                revised += "\n\n[Additional context to address completeness]"
            elif "smooth transition" in suggestion.lower():
                # Add transition
                revised = revised.replace("...", ", Additionally, ")
            elif "verify" in suggestion.lower():
                revised += "\n[Note: Claims should be verified for accuracy]"

        return revised

    async def execute_loop(
        self,
        initial_content: str,
        criteria: List[str],
        context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Execute full critique-revision loop"""
        current_content = initial_content
        iterations = 0

        while iterations < self.max_iterations:
            # Critique
            critique = await self.critique(current_content, criteria, context)

            # Check if meets threshold
            if not critique["needs_revision"]:
                return {
                    "content": current_content,
                    "iterations": iterations,
                    "confidence": critique["confidence"],
                    "issues_resolved": len(critique["issues"]) == 0
                }

            # Revise
            current_content = await self.revise(
                current_content,
                critique["issues"],
                critique["suggestions"]
            )
            iterations += 1

        return {
            "content": current_content,
            "iterations": iterations,
            "confidence": critique["confidence"],
            "issues_resolved": False,
            "warning": "Max iterations reached"
        }


# =============================================================================
# MAIN TEST
# =============================================================================

async def main():
    """Test model routing and self-critique"""
    # Initialize router
    router = ModelRouter()

    # Test routing
    queries = [
        "What is Python?",
        "Analyze the implications of AI on healthcare systems, considering regulatory frameworks, ethical considerations, and technological readiness across different regions.",
        "Write a function to sort a list",
        "Explain this image"
    ]

    for query in queries:
        decision = router.route(query)
        print(f"\nQuery: {query[:50]}...")
        print(f"  Selected: {decision.selected_model.model_id}")
        print(f"  Confidence: {decision.confidence:.2f}")
        print(f"  Cost: ${decision.estimated_cost:.4f}")
        print(f"  Reasoning: {decision.reasoning}")

    # Test self-critique
    critique_loop = SelfCritiqueLoop()

    content = "Python is a programming language. It is used for many things."
    result = await critique_loop.execute_loop(
        content,
        criteria=["completeness", "coherence", "accuracy"]
    )

    print(f"\nSelf-critique result:")
    print(f"  Iterations: {result['iterations']}")
    print(f"  Confidence: {result['confidence']:.2f}")
    print(f"  Content: {result['content'][:100]}...")


if __name__ == "__main__":
    asyncio.run(main())