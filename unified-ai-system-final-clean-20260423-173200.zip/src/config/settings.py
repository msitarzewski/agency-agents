"""
AI-OS Configuration
Production-Grade System Configuration
"""

import os
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from enum import Enum


class Environment(Enum):
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


@dataclass
class ModelConfig:
    """AI Model configuration"""
    model_id: str
    provider: str
    max_tokens: int = 128000
    temperature_default: float = 0.7
    timeout_seconds: int = 120
    cost_per_1k_input: float = 0.0
    cost_per_1k_output: float = 0.0
    capabilities: List[str] = field(default_factory=list)
    fallback_models: List[str] = field(default_factory=list)


@dataclass
class AgentConfig:
    """Agent configuration"""
    agent_id: str
    role: str
    max_concurrent_tasks: int = 5
    timeout_seconds: int = 300
    retry_limit: int = 3
    allowed_tools: List[str] = field(default_factory=list)


@dataclass
class MythosConfig:
    """Mythos-inspired reasoning reliability configuration."""

    enabled: bool = False
    cautious_threshold: float = 0.8
    defer_threshold: float = 0.4


@dataclass
class AIOSBridgeConfig:
    """Cross-project AIOS bridge configuration."""

    enabled: bool = False
    base_url: str = "http://localhost:8001"
    timeout_seconds: int = 10
    health_path: str = "/health"
    task_path: str = "/v1/tasks"
    api_key: Optional[str] = None


@dataclass
class SystemConfig:
    """Main system configuration"""
    # Environment
    environment: Environment = Environment.DEVELOPMENT
    debug_mode: bool = True

    # System
    system_name: str = "AI-OS"
    version: str = "1.0.0"

    # API
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    cors_origins: List[str] = field(default_factory=lambda: ["*"])

    # Orchestrator
    max_concurrent_tasks: int = 50
    default_timeout_seconds: int = 300
    retry_delay_seconds: int = 5

    # Memory
    max_context_tokens: int = 128000
    memory_retention_hours: int = 24
    vector_dimension: int = 1536

    # Models
    models: List[ModelConfig] = field(default_factory=list)

    # Agents
    agents: List[AgentConfig] = field(default_factory=list)

    # Security
    jwt_secret: Optional[str] = None
    jwt_expiry_hours: int = 24
    rate_limit_per_minute: int = 100

    # Database
    database_url: Optional[str] = None

    # Cache
    redis_url: Optional[str] = None
    cache_ttl_seconds: int = 3600

    # Observability
    log_level: str = "INFO"
    metrics_enabled: bool = True
    tracing_enabled: bool = True

    # Reasoning reliability
    mythos: MythosConfig = field(default_factory=MythosConfig)

    # Cross-project bridge
    aios_bridge: AIOSBridgeConfig = field(default_factory=AIOSBridgeConfig)

    # Storage
    storage_path: str = "./data"


# Default production configuration
DEFAULT_CONFIG = SystemConfig(
    environment=Environment.PRODUCTION,
    debug_mode=False,

    api_host="0.0.0.0",
    api_port=8000,

    max_concurrent_tasks=100,
    default_timeout_seconds=300,

    max_context_tokens=128000,
    memory_retention_hours=24,
    vector_dimension=1536,

    models=[
        ModelConfig(
            model_id="gpt-4-turbo",
            provider="openai",
            max_tokens=128000,
            temperature_default=0.7,
            timeout_seconds=120,
            cost_per_1k_input=0.01,
            cost_per_1k_output=0.03,
            capabilities=["reasoning", "generation", "code", "analysis"],
            fallback_models=["gpt-4", "gpt-3.5-turbo"]
        ),
        ModelConfig(
            model_id="claude-3-opus",
            provider="anthropic",
            max_tokens=200000,
            temperature_default=0.7,
            timeout_seconds=120,
            cost_per_1k_input=0.015,
            cost_per_1k_output=0.075,
            capabilities=["reasoning", "generation", "analysis", "creative"],
            fallback_models=["claude-3-sonnet", "claude-2"]
        ),
        ModelConfig(
            model_id="gemini-pro",
            provider="google",
            max_tokens=32000,
            temperature_default=0.7,
            timeout_seconds=60,
            cost_per_1k_input=0.001,
            cost_per_1k_output=0.002,
            capabilities=["reasoning", "generation", "multimodal"],
            fallback_models=["gemini-flash"]
        )
    ],

    agents=[
        AgentConfig(agent_id="planner_01", role="planner", max_concurrent_tasks=10),
        AgentConfig(agent_id="executor_01", role="executor", max_concurrent_tasks=5),
        AgentConfig(agent_id="critic_01", role="critic", max_concurrent_tasks=8),
        AgentConfig(agent_id="researcher_01", role="researcher", max_concurrent_tasks=6),
        AgentConfig(agent_id="generator_01", role="generator", max_concurrent_tasks=5)
    ],

    log_level="INFO",
    metrics_enabled=True,
    tracing_enabled=True
)


# Configuration loader
class ConfigLoader:
    """Load and manage configuration"""

    @staticmethod
    def load_from_env() -> SystemConfig:
        """Load configuration from environment variables"""
        config = SystemConfig()

        # Override from environment
        config.environment = Environment(os.getenv("ENVIRONMENT", "development"))
        config.debug_mode = os.getenv("DEBUG", "false").lower() == "true"
        config.api_host = os.getenv("API_HOST", "0.0.0.0")
        config.api_port = int(os.getenv("API_PORT", "8000"))

        config.jwt_secret = os.getenv("JWT_SECRET")
        config.database_url = os.getenv("DATABASE_URL")
        config.redis_url = os.getenv("REDIS_URL")

        config.mythos.enabled = os.getenv("MYTHOS_ENABLED", "false").lower() == "true"
        config.mythos.cautious_threshold = float(
            os.getenv("MYTHOS_CAUTIOUS_THRESHOLD", str(config.mythos.cautious_threshold))
        )
        config.mythos.defer_threshold = float(
            os.getenv("MYTHOS_DEFER_THRESHOLD", str(config.mythos.defer_threshold))
        )

        config.aios_bridge.enabled = os.getenv("AIOS_BRIDGE_ENABLED", "false").lower() == "true"
        config.aios_bridge.base_url = os.getenv("AIOS_BRIDGE_BASE_URL", config.aios_bridge.base_url)
        config.aios_bridge.timeout_seconds = int(
            os.getenv("AIOS_BRIDGE_TIMEOUT_SECONDS", str(config.aios_bridge.timeout_seconds))
        )
        config.aios_bridge.health_path = os.getenv("AIOS_BRIDGE_HEALTH_PATH", config.aios_bridge.health_path)
        config.aios_bridge.task_path = os.getenv("AIOS_BRIDGE_TASK_PATH", config.aios_bridge.task_path)
        config.aios_bridge.api_key = os.getenv("AIOS_BRIDGE_API_KEY")
        if config.aios_bridge.enabled and not config.aios_bridge.api_key:
            raise ValueError("AIOS bridge is enabled but AIOS_BRIDGE_API_KEY is not set")

        return config

    @staticmethod
    def load_yaml(yaml_path: str) -> SystemConfig:
        """Load configuration from YAML file"""
        import yaml  # type: ignore
        with open(yaml_path, 'r') as f:
            data = yaml.safe_load(f)

        # Convert to config object
        config = SystemConfig(**data)
        return config


# Export configuration
config = DEFAULT_CONFIG