"""
AI-OS - Unified AI Operating System
Enterprise-grade AI orchestration platform
"""

__version__ = "1.0.0"
__author__ = "AI-OS Team"

from .config.settings import config, DEFAULT_CONFIG, SystemConfig, ConfigLoader
from .core.orchestrator import Orchestrator, Agent, TaskGraph
from .core.model_router import ModelRouter, ComplexityClassifier
from .core.execution_engine import ExecutionEngine, SandboxExecutor
from .core.aios_bridge import AIOSBridge

__all__ = [
    "config",
    "DEFAULT_CONFIG",
    "SystemConfig",
    "ConfigLoader",
    "Orchestrator",
    "Agent",
    "TaskGraph",
    "ModelRouter",
    "ComplexityClassifier",
    "ExecutionEngine",
    "SandboxExecutor",
    "AIOSBridge",
]
