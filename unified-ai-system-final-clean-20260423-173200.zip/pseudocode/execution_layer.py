"""
Unified AI System - Execution Layer Implementation
Secure sandboxed code execution, external API integration, and workflow automation
"""

from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import asyncio
import uuid
import subprocess
import tempfile
import os


# =============================================================================
# EXECUTION MODELS
# =============================================================================

class ExecutionEnvironment(Enum):
    """Execution environment types"""
    SANDBOXED = "sandboxed"
    CONTAINER = "container"
    NATIVE = "native"
    WEBASSEMBLY = "webassembly"


class ExecutionStatus(Enum):
    """Execution status"""
    PENDING = "pending"
    INITIALIZING = "initializing"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


@dataclass
class ExecutionContext:
    """Context for code execution"""
    execution_id: str
    code: str
    language: str
    environment: ExecutionEnvironment
    timeout: int
    memory_limit: int = 512 * 1024 * 1024  # 512MB default
    cpu_limit: float = 2.0  # 2 cores
    allowed_modules: List[str] = field(default_factory=list)
    blocked_modules: List[str] = field(default_factory=list)
    allowed_endpoints: List[str] = field(default_factory=list)
    environment_variables: Dict[str, str] = field(default_factory=dict)
    working_directory: Optional[str] = None
    mounts: Dict[str, str] = field(default_factory=dict)  # host_path -> container_path


@dataclass
class ExecutionResult:
    """Result of code execution"""
    execution_id: str
    status: ExecutionStatus
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0
    execution_time: float = 0.0
    memory_usage: int = 0
    cpu_usage: float = 0.0
    output_files: List[Dict] = field(default_factory=list)
    logs: List[Dict] = field(default_factory=list)
    error: Optional[str] = None
    artifacts: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# SANDBOX EXECUTION ENGINE
# =============================================================================

class SandboxExecutor:
    """
    Secure sandboxed code execution engine.
    Provides isolation, resource limits, and timeout handling.
    """

    def __init__(self):
        self.runtimes = self._initialize_runtimes()
        self.active_executions: Dict[str, asyncio.subprocess.Process] = {}
        self.execution_limits = {
            "python": {"timeout": 300, "memory": 1024 * 1024 * 1024},
            "javascript": {"timeout": 120, "memory": 512 * 1024 * 1024},
            "java": {"timeout": 300, "memory": 2048 * 1024 * 1024},
            "go": {"timeout": 120, "memory": 512 * 1024 * 1024},
            "rust": {"timeout": 300, "memory": 512 * 1024 * 1024}
        }

    def _initialize_runtimes(self) -> Dict[str, str]:
        """Initialize runtime paths"""
        return {
            "python": "python3",
            "javascript": "node",
            "typescript": "npx ts-node",
            "java": "java",
            "go": "go run",
            "rust": "cargo run",
            "c": "gcc",
            "cpp": "g++"
        }

    async def execute(self, context: ExecutionContext) -> ExecutionResult:
        """Execute code in sandbox"""
        start_time = datetime.utcnow()

        try:
            # Create temporary file for code
            with tempfile.NamedTemporaryFile(
                mode='w',
                suffix=self._get_extension(context.language),
                delete=False
            ) as f:
                f.write(context.code)
                code_file = f.name

            try:
                # Build command
                cmd = self._build_command(context.language, code_file)

                # Execute with timeout and resource limits
                result = await self._run_with_limits(cmd, context)

            finally:
                # Cleanup temporary file
                if os.path.exists(code_file):
                    os.unlink(code_file)

            return result

        except asyncio.TimeoutError:
            return ExecutionResult(
                execution_id=context.execution_id,
                status=ExecutionStatus.TIMEOUT,
                error="Execution exceeded timeout",
                execution_time=(datetime.utcnow() - start_time).total_seconds()
            )
        except Exception as e:
            return ExecutionResult(
                execution_id=context.execution_id,
                status=ExecutionStatus.FAILED,
                error=str(e),
                execution_time=(datetime.utcnow() - start_time).total_seconds()
            )

    def _build_command(self, language: str, code_file: str) -> List[str]:
        """Build execution command for language"""
        runtime = self.runtimes.get(language, language)
        if " " in runtime:
            return runtime.split() + [code_file]
        return [runtime, code_file]

    def _get_extension(self, language: str) -> str:
        """Get file extension for language"""
        extensions = {
            "python": ".py",
            "javascript": ".js",
            "typescript": ".ts",
            "java": ".java",
            "go": ".go",
            "rust": ".rs",
            "c": ".c",
            "cpp": ".cpp"
        }
        return extensions.get(language, ".txt")

    async def _run_with_limits(self, cmd: List[str],
                               context: ExecutionContext) -> ExecutionResult:
        """Run process with resource limits"""
        # Create restricted environment
        env = os.environ.copy()
        env.update(context.environment_variables)

        # Prepare process creation
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
                cwd=context.working_directory or tempfile.gettempdir()
            )

            self.active_executions[context.execution_id] = process

            # Wait with timeout
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=context.timeout
                )

                return ExecutionResult(
                    execution_id=context.execution_id,
                    status=ExecutionStatus.COMPLETED,
                    stdout=stdout.decode('utf-8', errors='replace'),
                    stderr=stderr.decode('utf-8', errors='replace'),
                    exit_code=process.returncode
                )

            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                return ExecutionResult(
                    execution_id=context.execution_id,
                    status=ExecutionStatus.TIMEOUT,
                    error=f"Execution timed out after {context.timeout}s"
                )

        finally:
            self.active_executions.pop(context.execution_id, None)

    async def cancel(self, execution_id: str) -> bool:
        """Cancel running execution"""
        if execution_id in self.active_executions:
            process = self.active_executions[execution_id]
            process.kill()
            await process.wait()
            return True
        return False


class ContainerExecutor:
    """
    Container-based execution using Docker/Kubernetes.
    Provides stronger isolation for untrusted code.
    """

    def __init__(self):
        self.docker_available = self._check_docker()
        self.container_pool = ContainerPool(max_size=10)

    def _check_docker(self) -> bool:
        """Check if Docker is available"""
        try:
            result = subprocess.run(
                ["docker", "info"],
                capture_output=True,
                timeout=5
            )
            return result.returncode == 0
        except Exception:
            return False

    async def execute(self, context: ExecutionContext) -> ExecutionResult:
        """Execute code in isolated container"""
        if not self.docker_available:
            raise RuntimeError("Docker not available for container execution")

        container_id = None
        start_time = datetime.utcnow()

        try:
            # Get container from pool
            container = await self.container_pool.acquire()

            try:
                container_id = container.id

                # Prepare code
                code_b64 = self._encode_code(context.code)

                # Build docker command
                cmd = [
                    "docker", "run",
                    "--rm",
                    "--network=none",
                    "--memory=" + str(context.memory_limit),
                    "--cpus=" + str(context.cpu_limit),
                    f"--memory-swap={context.memory_limit}",
                    "-i",
                    self._get_image(context.language),
                    "python3", "-c", context.code
                ]

                # Execute
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )

                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=context.timeout
                )

                return ExecutionResult(
                    execution_id=context.execution_id,
                    status=ExecutionStatus.COMPLETED,
                    stdout=stdout.decode('utf-8', errors='replace'),
                    stderr=stderr.decode('utf-8', errors='replace'),
                    exit_code=process.returncode,
                    execution_time=(datetime.utcnow() - start_time).total_seconds()
                )

            finally:
                await self.container_pool.release(container)

        except asyncio.TimeoutError:
            return ExecutionResult(
                execution_id=context.execution_id,
                status=ExecutionStatus.TIMEOUT
            )
        except Exception as e:
            return ExecutionResult(
                execution_id=context.execution_id,
                status=ExecutionStatus.FAILED,
                error=str(e)
            )

    def _encode_code(self, code: str) -> str:
        """Encode code for transfer"""
        import base64
        return base64.b64encode(code.encode()).decode()

    def _get_image(self, language: str) -> str:
        """Get Docker image for language"""
        images = {
            "python": "python:3.11-slim",
            "javascript": "node:20-slim",
            "java": "openjdk:17-slim",
            "go": "golang:1.21"
        }
        return images.get(language, "python:3.11-slim")


class ContainerPool:
    """Pool of pre-warmed containers"""

    def __init__(self, max_size: int = 10):
        self.max_size = max_size
        self.available: asyncio.Queue = asyncio.Queue()
        self.in_use: int = 0
        self._initialized = False

    async def initialize(self):
        """Pre-warm containers"""
        if self._initialized:
            return

        for _ in range(self.max_size):
            container = await self._create_container()
            await self.available.put(container)

        self._initialized = True

    async def _create_container(self):
        """Create a new container"""
        # Simplified - in production would create real containers
        return Container(id=str(uuid.uuid4()), status="ready")

    async def acquire(self) -> 'Container':
        """Acquire container from pool"""
        try:
            container = await asyncio.wait_for(
                self.available.get(),
                timeout=30
            )
            self.in_use += 1
            return container
        except asyncio.TimeoutError:
            raise RuntimeError("No containers available")

    async def release(self, container: 'Container'):
        """Return container to pool"""
        self.in_use -= 1
        await self.available.put(container)


@dataclass
class Container:
    """Container instance"""
    id: str
    status: str


# =============================================================================
# EXTERNAL API GATEWAY
# =============================================================================

class APIGateway:
    """
    Gateway for external API interactions.
    Handles authentication, rate limiting, and response transformation.
    """

    def __init__(self):
        self.endpoints: Dict[str, EndpointConfig] = {}
        self.rate_limiters: Dict[str, 'RateLimiter'] = {}
        self.response_cache: Dict[str, 'Cache'] = {}
        self.transformers: Dict[str, 'ResponseTransformer'] = {}

    def register_endpoint(self, name: str, config: EndpointConfig):
        """Register an API endpoint"""
        self.endpoints[name] = config
        self.rate_limiters[name] = RateLimiter(
            requests=config.rate_limit,
            window=config.rate_window
        )

    async def call(self, endpoint_name: str, params: Dict[str, Any],
                   context: Dict) -> Dict:
        """Call external API endpoint"""
        if endpoint_name not in self.endpoints:
            raise ValueError(f"Unknown endpoint: {endpoint_name}")

        config = self.endpoints[endpoint_name]
        limiter = self.rate_limiters[endpoint_name]

        # Check rate limit
        rate_result = await limiter.check(context.get("user_id", "anonymous"))
        if not rate_result.allowed:
            raise APIRateLimitError(
                f"Rate limit exceeded for {endpoint_name}",
                retry_after=rate_result.retry_after
            )

        # Build request
        url = self._build_url(config, params)
        headers = self._build_headers(config, context)
        body = self._build_body(config, params)

        # Make request
        response = await self._make_request(
            config.method,
            url,
            headers,
            body
        )

        # Transform response
        if endpoint_name in self.transformers:
            response = await self.transformers[endpoint_name].transform(response)

        return response

    def _build_url(self, config: EndpointConfig, params: Dict) -> str:
        """Build URL with parameters"""
        url = config.base_url + config.path

        # Path parameters
        for key, value in params.items():
            if "{" + key + "}" in url:
                url = url.replace("{" + key + "}", str(value))

        # Query parameters
        query_params = {k: v for k, v in params.items()
                       if "{" + k + "}" not in config.path}

        if query_params:
            url += "?" + "&".join(f"{k}={v}" for k, v in query_params.items())

        return url

    def _build_headers(self, config: EndpointConfig, context: Dict) -> Dict:
        """Build request headers"""
        headers = config.headers.copy()

        # Add auth
        if config.auth_type == "bearer":
            headers["Authorization"] = f"Bearer {context.get('token')}"
        elif config.auth_type == "api_key":
            headers["X-API-Key"] = context.get("api_key", "")

        return headers

    def _build_body(self, config: EndpointConfig, params: Dict) -> Optional[str]:
        """Build request body"""
        if config.method in ["POST", "PUT", "PATCH"]:
            body_params = {k: v for k, v in params.items()
                         if "{" + k + "}" not in config.path}
            return json.dumps(body_params)
        return None

    async def _make_request(self, method: str, url: str,
                            headers: Dict, body: Optional[str]) -> Dict:
        """Make HTTP request"""
        # In production, use aiohttp or httpx
        # This is a simplified implementation
        return {"status": 200, "data": {}}


@dataclass
class EndpointConfig:
    """API endpoint configuration"""
    name: str
    base_url: str
    path: str
    method: str
    auth_type: str = "none"  # none, bearer, api_key, oauth2
    headers: Dict[str, str] = field(default_factory=dict)
    rate_limit: int = 100
    rate_window: int = 60  # seconds
    timeout: int = 30


# =============================================================================
# WORKFLOW ENGINE
# =============================================================================

class WorkflowEngine:
    """
    Workflow orchestration engine.
    Manages multi-step automation with error handling and compensation.
    """

    def __init__(self, execution_layer, api_gateway):
        self.execution_layer = execution_layer
        self.api_gateway = api_gateway
        self.active_workflows: Dict[str, 'WorkflowState'] = {}
        self.workflow_templates: Dict[str, 'WorkflowTemplate'] = {}

    def register_template(self, template: 'WorkflowTemplate'):
        """Register workflow template"""
        self.workflow_templates[template.name] = template

    async def execute(self, workflow_id: str, template_name: str,
                     params: Dict, context: Dict) -> 'WorkflowResult':
        """Execute workflow"""
        if template_name not in self.workflow_templates:
            raise ValueError(f"Unknown workflow: {template_name}")

        template = self.workflow_templates[template_name]
        state = WorkflowState(
            workflow_id=workflow_id,
            template=template,
            params=params,
            context=context,
            status="running",
            current_step=0,
            step_results=[]
        )

        self.active_workflows[workflow_id] = state

        try:
            # Execute each step
            for i, step in enumerate(template.steps):
                state.current_step = i

                # Check for cancellation
                if state.status == "cancelled":
                    break

                # Check dependencies
                if not self._check_dependencies(step, state.step_results):
                    state.status = "failed"
                    state.error = f"Dependencies not met for step: {step.name}"
                    break

                # Execute step
                result = await self._execute_step(step, state)

                state.step_results.append(result)

                # Handle step failure
                if step.on_failure == "abort" and result.status == "failed":
                    state.status = "failed"
                    state.error = f"Step {step.name} failed: {result.error}"
                    break
                elif step.on_failure == "compensate":
                    await self._compensate_steps(state, i)
                    state.status = "failed"
                    break

            if state.status == "running":
                state.status = "completed"

        except Exception as e:
            state.status = "failed"
            state.error = str(e)

        return WorkflowResult(
            workflow_id=workflow_id,
            status=state.status,
            step_results=state.step_results,
            error=state.error,
            total_time=state.total_time
        )

    def _check_dependencies(self, step: 'WorkflowStep',
                            results: List['StepResult']) -> bool:
        """Check if step dependencies are satisfied"""
        for dep in step.depends_on:
            dep_result = next(
                (r for r in results if r.step_name == dep),
                None
            )
            if dep_result is None or dep_result.status == "failed":
                return False
        return True

    async def _execute_step(self, step: 'WorkflowStep',
                           state: 'WorkflowState') -> 'StepResult':
        """Execute a single workflow step"""
        start_time = datetime.utcnow()

        try:
            # Resolve step parameters
            params = self._resolve_params(step.params, state)

            # Execute based on type
            if step.type == "code_execution":
                result = await self._execute_code_step(step, params)
            elif step.type == "api_call":
                result = await self._execute_api_step(step, params)
            elif step.type == "agent_task":
                result = await self._execute_agent_step(step, params)
            elif step.type == "condition":
                result = await self._execute_condition_step(step, params)
            elif step.type == "delay":
                result = await self._execute_delay_step(step, params)

            return StepResult(
                step_name=step.name,
                status="success",
                output=result,
                duration=(datetime.utcnow() - start_time).total_seconds()
            )

        except Exception as e:
            return StepResult(
                step_name=step.name,
                status="failed",
                error=str(e),
                duration=(datetime.utcnow() - start_time).total_seconds()
            )

    async def _execute_code_step(self, step: 'WorkflowStep',
                                 params: Dict) -> Dict:
        """Execute code step"""
        context = ExecutionContext(
            execution_id=str(uuid.uuid4()),
            code=params.get("code", ""),
            language=params.get("language", "python"),
            environment=ExecutionEnvironment.SANDBOXED,
            timeout=params.get("timeout", 60)
        )
        return await self.execution_layer.execute_code(context)

    async def _execute_api_step(self, step: 'WorkflowStep',
                                params: Dict) -> Dict:
        """Execute API call step"""
        return await self.api_gateway.call(
            params.get("endpoint"),
            params.get("params", {}),
            step.context
        )

    async def _execute_agent_step(self, step: 'WorkflowStep',
                                   params: Dict) -> Dict:
        """Execute agent task step"""
        # Would submit to agent framework
        return {"status": "submitted", "task_id": str(uuid.uuid4())}

    async def _execute_condition_step(self, step: 'WorkflowStep',
                                      params: Dict) -> Dict:
        """Evaluate condition step"""
        condition = params.get("condition")
        return {"condition": condition, "result": True}

    async def _execute_delay_step(self, step: 'WorkflowStep',
                                  params: Dict) -> Dict:
        """Execute delay step"""
        delay_seconds = params.get("seconds", 0)
        await asyncio.sleep(delay_seconds)
        return {"delayed": delay_seconds}

    def _resolve_params(self, params_template: Dict,
                        state: 'WorkflowState') -> Dict:
        """Resolve parameters with context"""
        params = {}

        for key, value in params_template.items():
            if isinstance(value, str) and value.startswith("$"):
                # Reference to previous step result
                ref = value[1:]
                if "." in ref:
                    step_name, field_path = ref.split(".", 1)
                    step_result = next(
                        (r for r in state.step_results
                         if r.step_name == step_name),
                        None
                    )
                    if step_result:
                        params[key] = self._get_nested(
                            step_result.output,
                            field_path
                        )
                else:
                    params[key] = state.params.get(value)
            else:
                params[key] = value

        return params

    def _get_nested(self, obj: Dict, path: str) -> Any:
        """Get nested value from object"""
        keys = path.split(".")
        result = obj
        for key in keys:
            if isinstance(result, dict):
                result = result.get(key)
            else:
                return None
        return result

    async def _compensate_steps(self, state: 'WorkflowState',
                                up_to: int):
        """Run compensation logic for completed steps"""
        for i in range(up_to - 1, -1, -1):
            step = state.template.steps[i]
            if step.compensate:
                try:
                    await self._execute_step(step, state)
                except Exception:
                    pass  # Log but continue compensation

    async def cancel(self, workflow_id: str) -> bool:
        """Cancel running workflow"""
        if workflow_id in self.active_workflows:
            state = self.active_workflows[workflow_id]
            state.status = "cancelled"
            return True
        return False

    def get_status(self, workflow_id: str) -> Dict:
        """Get workflow status"""
        if workflow_id not in self.active_workflows:
            return {"status": "not_found"}

        state = self.active_workflows[workflow_id]
        return {
            "workflow_id": workflow_id,
            "template": state.template.name,
            "status": state.status,
            "current_step": state.current_step,
            "total_steps": len(state.template.steps),
            "error": state.error
        }


@dataclass
class WorkflowTemplate:
    """Workflow template definition"""
    name: str
    description: str
    steps: List['WorkflowStep'] = field(default_factory=list)
    timeout: int = 3600
    retry_policy: Dict = field(default_factory=dict)


@dataclass
class WorkflowStep:
    """Workflow step definition"""
    name: str
    type: str  # code_execution, api_call, agent_task, condition, delay
    params: Dict = field(default_factory=dict)
    depends_on: List[str] = field(default_factory=list)
    on_failure: str = "abort"  # abort, skip, compensate
    compensate: Optional[Dict] = None
    context: Dict = field(default_factory=dict)


@dataclass
class WorkflowState:
    """Runtime state for workflow execution"""
    workflow_id: str
    template: WorkflowTemplate
    params: Dict
    context: Dict
    status: str
    current_step: int
    step_results: List['StepResult']
    error: Optional[str] = None
    started_at: datetime = field(default_factory=datetime.utcnow)
    total_time: float = 0.0


@dataclass
class StepResult:
    """Result of workflow step execution"""
    step_name: str
    status: str
    output: Optional[Dict] = None
    error: Optional[str] = None
    duration: float = 0.0


@dataclass
class WorkflowResult:
    """Final workflow result"""
    workflow_id: str
    status: str
    step_results: List[StepResult]
    error: Optional[str] = None
    total_time: float = 0.0


# =============================================================================
# EXTERNAL API INTEGRATION FRAMEWORK
# =============================================================================

class ExternalAPIClient:
    """
    Client for integrating with external APIs.
    Handles OAuth2, API keys, and webhook callbacks.
    """

    def __init__(self, api_gateway: APIGateway):
        self.api_gateway = api_gateway
        self.oauth_state: Dict[str, OAuthState] = {}
        self.webhook_handlers: Dict[str, Callable] = {}

    def register_oauth(self, service: str, config: OAuthConfig):
        """Register OAuth configuration for service"""
        self.oauth_state[service] = OAuthState(
            service=service,
            client_id=config.client_id,
            client_secret=config.client_secret,
            auth_url=config.auth_url,
            token_url=config.token_url,
            scopes=config.scopes
        )

    async def get_authorization_url(self, service: str,
                                   redirect_uri: str) -> str:
        """Get OAuth authorization URL"""
        state = self.oauth_state.get(service)
        if not state:
            raise ValueError(f"Unknown OAuth service: {service}")

        state.redirect_uri = redirect_uri
        state.auth_code = str(uuid.uuid4())

        params = {
            "client_id": state.client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": " ".join(state.scopes),
            "state": state.auth_code
        }

        return f"{state.auth_url}?{self._encode_params(params)}"

    async def exchange_code(self, service: str, code: str) -> OAuthToken:
        """Exchange authorization code for token"""
        state = self.oauth_state.get(service)
        if not state:
            raise ValueError(f"Unknown OAuth service: {service}")

        # Would make request to token endpoint
        token = OAuthToken(
            access_token="",
            refresh_token="",
            expires_in=3600
        )

        state.token = token
        return token

    def register_webhook(self, event_type: str, handler: Callable):
        """Register webhook handler"""
        self.webhook_handlers[event_type] = handler

    async def handle_webhook(self, event_type: str, payload: Dict):
        """Handle incoming webhook"""
        if event_type in self.webhook_handlers:
            handler = self.webhook_handlers[event_type]
            await handler(payload)

    def _encode_params(self, params: Dict) -> str:
        """Encode URL parameters"""
        return "&".join(f"{k}={v}" for k, v in params.items())


@dataclass
class OAuthConfig:
    """OAuth configuration"""
    service: str
    client_id: str
    client_secret: str
    auth_url: str
    token_url: str
    scopes: List[str]


@dataclass
class OAuthState:
    """OAuth runtime state"""
    service: str
    client_id: str
    client_secret: str
    auth_url: str
    token_url: str
    scopes: List[str]
    redirect_uri: Optional[str] = None
    auth_code: Optional[str] = None
    token: Optional['OAuthToken'] = None


@dataclass
class OAuthToken:
    """OAuth access token"""
    access_token: str
    refresh_token: str
    expires_in: int
    token_type: str = "Bearer"


# =============================================================================
# EXECUTION LAYER FACADE
# =============================================================================

class ExecutionLayer:
    """
    Unified execution layer facade.
    Coordinates all execution capabilities.
    """

    def __init__(self):
        self.sandbox_executor = SandboxExecutor()
        self.container_executor = ContainerExecutor()
        self.api_gateway = APIGateway()
        self.workflow_engine = WorkflowEngine(self, self.api_gateway)
        self.external_api_client = ExternalAPIClient(self.api_gateway)

    async def execute_code(self, request: Dict) -> Dict:
        """Execute code in appropriate environment"""
        context = ExecutionContext(
            execution_id=str(uuid.uuid4()),
            code=request.get("code", ""),
            language=request.get("language", "python"),
            environment=ExecutionEnvironment(request.get("environment", "sandboxed")),
            timeout=request.get("timeout", 60),
            memory_limit=request.get("memory_limit", 512 * 1024 * 1024)
        )

        # Choose executor based on environment
        if context.environment == ExecutionEnvironment.SANDBOXED:
            result = await self.sandbox_executor.execute(context)
        else:
            result = await self.container_executor.execute(context)

        return {
            "execution_id": result.execution_id,
            "status": result.status.value,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "exit_code": result.exit_code,
            "execution_time": result.execution_time,
            "memory_usage": result.memory_usage,
            "error": result.error
        }

    async def execute_workflow(self, workflow_name: str,
                              params: Dict,
                              context: Dict) -> Dict:
        """Execute predefined workflow"""
        result = await self.workflow_engine.execute(
            workflow_id=str(uuid.uuid4()),
            template_name=workflow_name,
            params=params,
            context=context
        )

        return {
            "workflow_id": result.workflow_id,
            "status": result.status,
            "steps": [
                {
                    "name": r.step_name,
                    "status": r.status,
                    "output": r.output,
                    "error": r.error,
                    "duration": r.duration
                }
                for r in result.step_results
            ],
            "error": result.error,
            "total_time": result.total_time
        }

    async def call_api(self, endpoint: str, params: Dict,
                       context: Dict) -> Dict:
        """Call external API"""
        return await self.api_gateway.call(endpoint, params, context)

    def get_workflow_status(self, workflow_id: str) -> Dict:
        """Get workflow execution status"""
        return self.workflow_engine.get_status(workflow_id)

    async def cancel_workflow(self, workflow_id: str) -> bool:
        """Cancel workflow execution"""
        return await self.workflow_engine.cancel(workflow_id)


# =============================================================================
# RATE LIMITER IMPLEMENTATION
# =============================================================================

class RateLimiter:
    """Token bucket rate limiter"""

    def __init__(self, requests: int = 100, window: int = 60):
        self.max_tokens = requests
        self.tokens = requests
        self.window = window
        self.last_refill = datetime.utcnow()
        self.refill_rate = requests / window

    async def check(self, key: str) -> RateLimitResult:
        """Check if request is within rate limit"""
        self._refill()

        if self.tokens >= 1:
            self.tokens -= 1
            return RateLimitResult(
                allowed=True,
                remaining=int(self.tokens)
            )
        else:
            retry_after = int((1 - self.tokens) / self.refill_rate)
            return RateLimitResult(
                allowed=False,
                remaining=0,
                retry_after=retry_after
            )

    def _refill(self):
        """Refill tokens based on elapsed time"""
        now = datetime.utcnow()
        elapsed = (now - self.last_refill).total_seconds()
        refill = elapsed * self.refill_rate

        self.tokens = min(self.max_tokens, self.tokens + refill)
        self.last_refill = now


@dataclass
class RateLimitResult:
    """Rate limit check result"""
    allowed: bool
    remaining: int = 0
    retry_after: Optional[int] = None


class APIRateLimitError(Exception):
    """API rate limit exceeded error"""

    def __init__(self, message: str, retry_after: Optional[int] = None):
        self.message = message
        self.retry_after = retry_after
        super().__init__(message)


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

async def run_in_sandbox(code: str, language: str = "python",
                         timeout: int = 60) -> Dict:
    """Convenience function for sandboxed execution"""
    executor = SandboxExecutor()
    context = ExecutionContext(
        execution_id=str(uuid.uuid4()),
        code=code,
        language=language,
        environment=ExecutionEnvironment.SANDBOXED,
        timeout=timeout
    )

    result = await executor.execute(context)

    return {
        "success": result.status == ExecutionStatus.COMPLETED,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "error": result.error,
        "execution_time": result.execution_time
    }
