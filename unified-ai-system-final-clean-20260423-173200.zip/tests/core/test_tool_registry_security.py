import asyncio
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from src.tools.tool_registry import (
    ToolRegistry,
    Tool,
    ToolCategory,
    ToolStatus,
    ToolPermission,
    create_tool_registry,
)
from src.core.lineage_repository import FileLineageRepository


def _ok_impl(params, context):
    return {"success": True, "echo": params}


def test_recursive_mask_sensitive_params() -> None:
    registry = ToolRegistry()
    password_key = "pass" + "word"
    masked = registry._mask_sensitive_params(
        {
            "token": "abc",
            "nested": {"api_key": "k1", "safe": "x"},
            "items": [{password_key: "placeholder"}, {"name": "ok"}],
        }
    )

    assert masked["token"] == "***REDACTED***"
    assert masked["nested"]["api_key"] == "***REDACTED***"
    assert masked["nested"]["safe"] == "x"
    assert masked["items"][0][password_key] == "***REDACTED***"


def test_recursive_mask_sensitive_params_handles_deep_nested_lists() -> None:
    registry = ToolRegistry()
    masked = registry._mask_sensitive_params(
        {
            "layers": [[{"token": "secret-token"}]],
        }
    )
    assert masked["layers"][0][0]["token"] == "***REDACTED***"


def test_recursive_param_scan_detects_nested_injection() -> None:
    registry = ToolRegistry()
    result = registry._scan_params_recursive({"outer": {"cmd": "hello; rm -rf /"}})
    assert result["passed"] is False
    assert result["risk_level"] == "high"


def test_recursive_param_scan_allows_normal_apostrophe_text() -> None:
    registry = ToolRegistry()
    result = registry._scan_params_recursive({"message": "don't block this sentence"})
    assert result["passed"] is True


def test_recursive_param_scan_ignores_schema_like_keys() -> None:
    registry = ToolRegistry()
    payload = {"$schema": "https://json-schema.org/draft/2020-12/schema"}
    result = registry._scan_params_recursive(payload)
    assert result["passed"] is True


def test_enforce_scanner_for_elevated_tool_without_scanner() -> None:
    registry = ToolRegistry()
    tool = Tool(
        tool_id="elevated_tool",
        tool_name="elevated_tool",
        category=ToolCategory.SECURITY,
        description="test",
        security_level="elevated",
        implementation_type="function",
        implementation=_ok_impl,
        input_schema={"type": "object", "properties": {}},
        output_schema={"type": "object", "properties": {}},
        permissions=[ToolPermission(role="*", tier="*")],
    )
    registry.register_tool(tool)

    invocation = asyncio.run(
        registry.execute_tool(
            tool_id="elevated_tool",
            params={},
            execution_context={"user_role": "*", "user_tier": "*"},
        )
    )

    assert invocation.status == "failed"
    assert "security scanner required" in (invocation.error or "")


def test_stub_tool_fails_in_live_mode() -> None:
    registry = create_tool_registry()
    db_tool = registry.get_tool("database_query")
    assert db_tool is not None
    db_tool.permissions = [ToolPermission(role="*", tier="*")]

    invocation = asyncio.run(
        registry.execute_tool(
            tool_id="database_query",
            params={"query": "select 1"},
            execution_context={"user_role": "*", "user_tier": "*"},
        )
    )

    assert invocation.status == "failed"
    assert "stub" in (invocation.error or "")


def test_stub_tool_still_simulates_in_dry_run() -> None:
    from src.tools.tool_registry import ExecutionMode

    registry = create_tool_registry()
    db_tool = registry.get_tool("database_query")
    assert db_tool is not None
    db_tool.permissions = [ToolPermission(role="*", tier="*")]
    invocation = asyncio.run(
        registry.execute_tool(
            tool_id="database_query",
            params={"query": "select 1"},
            execution_context={"user_role": "*", "user_tier": "*"},
            mode=ExecutionMode.DRY_RUN,
        )
    )

    assert invocation.status == "completed"
    assert invocation.result is not None
    assert invocation.result.get("simulated") is True


def test_default_registry_marks_stub_tools_beta() -> None:
    registry = create_tool_registry()
    db_tool = registry.get_tool("database_query")
    assert db_tool is not None
    assert db_tool.status == ToolStatus.BETA
    assert "stub" in db_tool.tags


def test_execute_tool_propagates_lineage_context() -> None:
    registry = ToolRegistry()
    tool = Tool(
        tool_id="lineage_tool",
        tool_name="lineage_tool",
        category=ToolCategory.CUSTOM,
        description="test",
        implementation_type="function",
        implementation=_ok_impl,
        input_schema={"type": "object", "properties": {}},
        output_schema={"type": "object", "properties": {}},
        permissions=[ToolPermission(role="*", tier="*")],
    )
    registry.register_tool(tool)

    invocation = asyncio.run(
        registry.execute_tool(
            tool_id="lineage_tool",
            params={"query": "ok"},
            execution_context={
                "user_role": "*",
                "user_tier": "*",
                "task_id": "task_123",
                "session_id": "session_123",
                "trace_id": "trace_123",
                "_lineage": {
                    "request_id": "request_123",
                    "trace_id": "trace_123",
                    "source": "task_api",
                    "tool_invocation_ids": [],
                    "memory_refs": [],
                },
            },
        )
    )

    assert invocation.status == "completed"
    assert invocation.lineage["request_id"] == "request_123"
    assert invocation.lineage["trace_id"] == "trace_123"
    assert invocation.lineage["parent_task_id"] == "task_123"
    assert invocation.invocation_id in invocation.lineage["tool_invocation_ids"]


def test_execute_tool_persists_lineage_snapshot() -> None:
    with TemporaryDirectory() as temp_dir:
        repository = FileLineageRepository(Path(temp_dir) / "lineage")
        registry = create_tool_registry(lineage_repository=repository)
        tool = Tool(
            tool_id="persisted_lineage_tool",
            tool_name="persisted_lineage_tool",
            category=ToolCategory.CUSTOM,
            description="test",
            implementation_type="function",
            implementation=_ok_impl,
            input_schema={"type": "object", "properties": {}},
            output_schema={"type": "object", "properties": {}},
            permissions=[ToolPermission(role="*", tier="*")],
        )
        registry.register_tool(tool)

        invocation = asyncio.run(
            registry.execute_tool(
                tool_id="persisted_lineage_tool",
                params={"query": "ok"},
                execution_context={
                    "user_role": "*",
                    "user_tier": "*",
                    "task_id": "task_persisted",
                    "session_id": "session_persisted",
                    "trace_id": "trace_persisted",
                    "_lineage": {
                        "request_id": "request_persisted",
                        "trace_id": "trace_persisted",
                        "source": "task_api",
                        "tool_invocation_ids": [],
                        "memory_refs": [],
                    },
                },
            )
        )

        snapshot_path = Path(temp_dir) / "lineage" / "tool_invocations.jsonl"
        assert invocation.status == "completed"
        assert snapshot_path.exists()

        persisted_entries = [
            json.loads(line)
            for line in snapshot_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]

        assert len(persisted_entries) == 1
        assert persisted_entries[0]["invocation_id"] == invocation.invocation_id
        assert persisted_entries[0]["lineage"]["request_id"] == "request_persisted"
        assert persisted_entries[0]["lineage"]["parent_task_id"] == "task_persisted"


class _AsyncDummyResponse:
    def __init__(self, payload, status_code: int = 200, content_type: str = "application/json"):
        self._payload = payload
        self.status_code = status_code
        self.headers = {"content-type": content_type}
        self.text = payload if isinstance(payload, str) else json.dumps(payload)

    def json(self):
        if isinstance(self._payload, str):
            raise ValueError("not json")
        return self._payload


class _AsyncDummyClient:
    def __init__(self, response: _AsyncDummyResponse):
        self._response = response

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def request(self, method, url, headers=None, json=None, params=None):
        await asyncio.sleep(0)
        return self._response


def test_api_tool_rejects_unsafe_http_url() -> None:
    registry = ToolRegistry()
    tool = Tool(
        tool_id="unsafe_api_tool",
        tool_name="unsafe_api_tool",
        category=ToolCategory.CUSTOM,
        description="test",
        implementation_type="api",
        implementation_url="file:///etc/passwd",
        input_schema={"type": "object", "properties": {}},
        output_schema={"type": "object", "properties": {}},
        permissions=[ToolPermission(role="*", tier="*")],
    )
    registry.register_tool(tool)

    invocation = asyncio.run(
        registry.execute_tool(
            tool_id="unsafe_api_tool",
            params={},
            execution_context={"user_role": "*", "user_tier": "*"},
        )
    )

    assert invocation.status == "failed"
    assert "invalid or unsafe http url" in (invocation.error or "").lower()


def test_api_tool_fails_on_upstream_http_error() -> None:
    registry = ToolRegistry()
    tool = Tool(
        tool_id="failing_api_tool",
        tool_name="failing_api_tool",
        category=ToolCategory.CUSTOM,
        description="test",
        implementation_type="api",
        implementation_url="https://example.com/tool",
        input_schema={"type": "object", "properties": {}},
        output_schema={"type": "object", "properties": {}},
        permissions=[ToolPermission(role="*", tier="*")],
    )
    registry.register_tool(tool)

    with patch(
        "src.tools.tool_registry.httpx.AsyncClient",
        return_value=_AsyncDummyClient(_AsyncDummyResponse({"detail": "boom"}, status_code=503)),
    ):
        invocation = asyncio.run(
            registry.execute_tool(
                tool_id="failing_api_tool",
                params={},
                execution_context={"user_role": "*", "user_tier": "*"},
            )
        )

    assert invocation.status == "failed"
    assert "http 503" in (invocation.error or "").lower()


def test_docker_tool_rejects_invalid_image_reference() -> None:
    registry = ToolRegistry()
    tool = Tool(
        tool_id="unsafe_docker_tool",
        tool_name="unsafe_docker_tool",
        category=ToolCategory.CUSTOM,
        description="test",
        implementation_type="docker",
        implementation_url="ubuntu latest;rm -rf /",
        input_schema={"type": "object", "properties": {}},
        output_schema={"type": "object", "properties": {}},
        permissions=[ToolPermission(role="*", tier="*")],
    )
    registry.register_tool(tool)

    invocation = asyncio.run(
        registry.execute_tool(
            tool_id="unsafe_docker_tool",
            params={},
            execution_context={"user_role": "*", "user_tier": "*"},
        )
    )

    assert invocation.status == "failed"
    assert "invalid docker image" in (invocation.error or "").lower()
