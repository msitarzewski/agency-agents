from src.core.lineage import append_tool_invocation
from src.core.lineage import normalize_lineage


def test_normalize_lineage_coerces_collection_fields_to_lists() -> None:
    lineage = normalize_lineage(
        {
            "request_id": "request_123",
            "trace_id": "trace_123",
            "tool_invocation_ids": "tool_1",
            "memory_refs": "memory_1",
        },
        source="chat_completion",
    )

    assert lineage["request_id"] == "request_123"
    assert lineage["trace_id"] == "trace_123"
    assert lineage["tool_invocation_ids"] == ["tool_1"]
    assert lineage["memory_refs"] == ["memory_1"]


def test_append_tool_invocation_handles_missing_collection_shape() -> None:
    lineage = append_tool_invocation(
        {
            "request_id": "request_123",
            "trace_id": "trace_123",
            "tool_invocation_ids": "tool_1",
        },
        "tool_2",
    )

    assert lineage["tool_invocation_ids"] == ["tool_1", "tool_2"]