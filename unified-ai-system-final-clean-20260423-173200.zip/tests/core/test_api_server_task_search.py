import asyncio
from pathlib import Path
from tempfile import TemporaryDirectory

import pytest
from fastapi import HTTPException

from src.api.server import APIServer
from src.core.lineage_repository import FileLineageRepository
from src.core.orchestrator import Orchestrator
from src.core.orchestrator import Task
from src.core.orchestrator import TaskPriority
from src.core.orchestrator import TaskStatus


def test_api_server_search_tasks_returns_filtered_results():
    orchestrator = Orchestrator()
    task = Task(
        task_id="task_api_1",
        task_type="analysis",
        description="API lookup",
        priority=TaskPriority.NORMAL,
        status=TaskStatus.COMPLETED,
        inputs={
            "_lineage": {
                "request_id": "req-api",
                "trace_id": "trace-api",
                "source": "chat_completion",
                "tool_invocation_ids": [],
                "memory_refs": [],
            }
        },
    )
    orchestrator.completed_tasks[task.task_id] = task
    server = APIServer(orchestrator=orchestrator)

    result = asyncio.run(server._search_tasks(trace_id="trace-api", request_id=None))

    assert result.count == 1
    assert result.results[0]["task_id"] == "task_api_1"
    assert result.results[0]["lineage"]["request_id"] == "req-api"


def test_api_server_get_task_status_uses_persisted_snapshot_when_memory_empty() -> None:
    with TemporaryDirectory() as temp_dir:
        repository = FileLineageRepository(Path(temp_dir) / "lineage")
        repository.persist_task_snapshot(
            task_id="task_api_persisted_1",
            status="completed",
            task_type="analysis",
            description="Persisted API task",
            trace_id="trace-api-persisted",
            lineage={
                "request_id": "req-api-persisted",
                "trace_id": "trace-api-persisted",
                "source": "task_api",
                "tool_invocation_ids": ["tool-api-1"],
                "memory_refs": ["memory-api-1"],
                "output_ref": "output-api-1",
            },
            outputs={"response": "persisted-response"},
            error=None,
        )
        orchestrator = Orchestrator(lineage_repository=repository)
        server = APIServer(orchestrator=orchestrator)

        result = asyncio.run(server._get_task_status("task_api_persisted_1"))

        assert result["task_id"] == "task_api_persisted_1"
        assert result["status"] == "completed"
        assert result["outputs"]["response"] == "persisted-response"
        assert result["lineage"]["request_id"] == "req-api-persisted"


def test_api_server_get_task_status_returns_404_when_task_missing() -> None:
    orchestrator = Orchestrator()
    server = APIServer(orchestrator=orchestrator)

    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(server._get_task_status("task_missing_404"))

    assert exc_info.value.status_code == 404
    assert exc_info.value.detail == "Task not found"


def test_api_server_get_task_status_returns_503_when_orchestrator_unavailable() -> None:
    server = APIServer(orchestrator=None)

    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(server._get_task_status("task_any"))

    assert exc_info.value.status_code == 503
    assert exc_info.value.detail == "Orchestrator not available"


def test_api_server_list_agents_returns_503_when_orchestrator_unavailable() -> None:
    server = APIServer(orchestrator=None)

    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(server._list_agents())

    assert exc_info.value.status_code == 503
    assert exc_info.value.detail == "Orchestrator not available"


def test_api_server_list_tools_returns_503_when_tool_registry_unavailable() -> None:
    orchestrator = Orchestrator()
    server = APIServer(orchestrator=orchestrator, tool_registry=None)

    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(server._list_tools())

    assert exc_info.value.status_code == 503
    assert exc_info.value.detail == "Tool registry not available"


def test_api_server_cancel_task_returns_503_when_orchestrator_unavailable() -> None:
    server = APIServer(orchestrator=None)

    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(server._cancel_task("task_any"))

    assert exc_info.value.status_code == 503
    assert exc_info.value.detail == "Orchestrator not available"


def test_api_server_cancel_task_returns_404_when_task_missing() -> None:
    orchestrator = Orchestrator()
    server = APIServer(orchestrator=orchestrator)

    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(server._cancel_task("task_missing_cancel"))

    assert exc_info.value.status_code == 404
    assert exc_info.value.detail == "Task not found"


def test_api_server_cancel_task_sets_active_task_to_cancelled() -> None:
    orchestrator = Orchestrator()
    task = Task(
        task_id="task_cancel_1",
        task_type="analysis",
        description="Cancelable task",
        priority=TaskPriority.NORMAL,
        status=TaskStatus.RUNNING,
        inputs={"_lineage": {"request_id": "req-cancel", "trace_id": "trace-cancel"}},
    )
    orchestrator.active_tasks[task.task_id] = task
    server = APIServer(orchestrator=orchestrator)

    result = asyncio.run(server._cancel_task("task_cancel_1"))

    assert result["task_id"] == "task_cancel_1"
    assert result["status"] == "cancelled"