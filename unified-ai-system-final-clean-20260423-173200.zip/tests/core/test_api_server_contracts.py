"""RED tests for 5 contract gaps in server.py.

Gap 1: _get_session returns 200 + error dict instead of 404
Gap 2: _execute_tool returns 200 even when tool not found instead of 404
Gap 3: _search_tasks returns 200 empty list when no orchestrator instead of 503
Gap 4: _handle_chat returns 200 when no orchestrator instead of 503
Gap 5: _agent_communicate accepts empty content instead of 400
"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from fastapi.testclient import TestClient


def _make_client(*, with_orchestrator: bool = False, with_tool_registry: bool = False):
    """Build a TestClient with controlled dependency state."""
    from src.api.server import APIServer

    server = APIServer()
    if not with_orchestrator:
        server.orchestrator = None
    if not with_tool_registry:
        server.tool_registry = None

    return TestClient(server.app, raise_server_exceptions=False)


# ---------------------------------------------------------------------------
# Gap 1 – _get_session: missing session must be 404, not 200
# ---------------------------------------------------------------------------
class TestGetSessionContract:
    def test_missing_session_returns_404(self):
        client = _make_client(with_orchestrator=True)
        resp = client.get("/v1/sessions/nonexistent-session-id-xyz")
        assert resp.status_code == 404, (
            f"Expected 404 for missing session, got {resp.status_code}: {resp.text}"
        )

    def test_missing_session_not_200_with_error_key(self):
        client = _make_client(with_orchestrator=True)
        resp = client.get("/v1/sessions/nonexistent-session-id-xyz")
        # Old (broken) behaviour: HTTP 200 with {"error": "Session not found"}
        assert not (resp.status_code == 200 and "error" in resp.json()), (
            "Returning 200 with error body is the bug – endpoint must raise 404"
        )


# ---------------------------------------------------------------------------
# Gap 2 – _execute_tool: unknown tool must be 404
# ---------------------------------------------------------------------------
class TestExecuteToolContract:
    def test_unknown_tool_returns_404(self):
        # Re-build with a registry whose execute_tool returns falsy
        from src.api.server import APIServer

        server = APIServer()
        server.orchestrator = None
        mock_registry = MagicMock()
        mock_registry.execute_tool = AsyncMock(return_value=None)
        server.tool_registry = mock_registry

        tc = TestClient(server.app, raise_server_exceptions=False)
        resp = tc.post(
            "/v1/tools/totally-unknown-tool/execute",
            json={"parameters": {}},
        )
        assert resp.status_code == 404, (
            f"Expected 404 for unknown tool, got {resp.status_code}: {resp.text}"
        )


# ---------------------------------------------------------------------------
# Gap 3 – _search_tasks: no orchestrator must be 503
# ---------------------------------------------------------------------------
class TestSearchTasksContract:
    def test_no_orchestrator_returns_503(self):
        client = _make_client(with_orchestrator=False)
        resp = client.get("/v1/tasks/search", params={"q": "anything"})
        assert resp.status_code == 503, (
            f"Expected 503 when orchestrator unavailable, got {resp.status_code}: {resp.text}"
        )

    def test_no_orchestrator_not_200_empty_list(self):
        client = _make_client(with_orchestrator=False)
        resp = client.get("/v1/tasks/search", params={"q": "anything"})
        assert not (resp.status_code == 200 and resp.json().get("count") == 0), (
            "Returning 200 empty list when orchestrator absent is the bug – must be 503"
        )


# ---------------------------------------------------------------------------
# Gap 4 – _handle_chat: no orchestrator must be 503
# ---------------------------------------------------------------------------
class TestHandleChatContract:
    def test_no_orchestrator_returns_503(self):
        client = _make_client(with_orchestrator=False)
        resp = client.post(
            "/v1/chat",
            json={"messages": [{"role": "user", "content": "hello"}]},
        )
        assert resp.status_code == 503, (
            f"Expected 503 when orchestrator unavailable, got {resp.status_code}: {resp.text}"
        )


# ---------------------------------------------------------------------------
# Gap 5 – _agent_communicate: empty content must be 400
# ---------------------------------------------------------------------------
class TestAgentCommunicateContract:
    def test_empty_content_returns_400(self):
        client = _make_client()
        resp = client.post(
            "/v1/agents/communicate",
            json={"agent_id": "agent-1", "content": ""},
        )
        assert resp.status_code == 400, (
            f"Expected 400 for empty content, got {resp.status_code}: {resp.text}"
        )

    def test_none_content_returns_400(self):
        client = _make_client()
        resp = client.post(
            "/v1/agents/communicate",
            json={"agent_id": "agent-1", "content": None},
        )
        assert resp.status_code == 400, (
            f"Expected 400 for null content, got {resp.status_code}: {resp.text}"
        )

    def test_whitespace_only_content_returns_400(self):
        client = _make_client()
        resp = client.post(
            "/v1/agents/communicate",
            json={"agent_id": "agent-1", "content": "   "},
        )
        assert resp.status_code == 400, (
            f"Expected 400 for whitespace-only content, got {resp.status_code}: {resp.text}"
        )
