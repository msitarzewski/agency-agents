param(
    [string]$UnifiedRepo = "",
    [string]$AiosRepo = ""
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

function Resolve-Python {
    param([string]$RepoPath)

    $venvPython = Join-Path $RepoPath ".venv\Scripts\python.exe"
    if (Test-Path $venvPython) {
        return $venvPython
    }

    $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
    if ($null -eq $pythonCmd) {
        throw "Python executable not found for $RepoPath"
    }

    return $pythonCmd.Source
}

function Run-Step {
    param(
        [string]$Name,
        [scriptblock]$Action
    )

    $start = Get-Date
    try {
        $null = & $Action
        $duration = (Get-Date) - $start
        return [pscustomobject]@{
            Step = $Name
            Status = "PASS"
            Seconds = [Math]::Round($duration.TotalSeconds, 2)
            Details = ""
        }
    }
    catch {
        $duration = (Get-Date) - $start
        return [pscustomobject]@{
            Step = $Name
            Status = "FAIL"
            Seconds = [Math]::Round($duration.TotalSeconds, 2)
            Details = $_.Exception.Message
        }
    }
}

if ([string]::IsNullOrWhiteSpace($UnifiedRepo)) {
    $UnifiedRepo = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
}
if ([string]::IsNullOrWhiteSpace($AiosRepo)) {
    $AiosRepo = (Resolve-Path (Join-Path $UnifiedRepo "..\aios")).Path
}

if (-not (Test-Path $UnifiedRepo)) { throw "Unified repo not found: $UnifiedRepo" }
if (-not (Test-Path $AiosRepo)) { throw "AIOS repo not found: $AiosRepo" }

$unifiedPython = Resolve-Python -RepoPath $UnifiedRepo
$aiosPython = Resolve-Python -RepoPath $AiosRepo

Write-Host ""
Write-Host "Cross-Repo Full Project Check" -ForegroundColor Cyan
Write-Host "Unified repo: $UnifiedRepo"
Write-Host "AIOS repo:    $AiosRepo"
Write-Host ""

$results = @()

$results += Run-Step -Name "Unified tests" -Action {
    Push-Location $UnifiedRepo
    try {
        & $unifiedPython -m pytest -q --disable-warnings
        if ($LASTEXITCODE -ne 0) { throw "Unified pytest failed with code $LASTEXITCODE" }
    }
    finally {
        Pop-Location
    }
}

$results += Run-Step -Name "AIOS tests" -Action {
    Push-Location $AiosRepo
    try {
        $previousPyPath = $env:PYTHONPATH
        $env:PYTHONPATH = $AiosRepo
        & $aiosPython -m pytest -q --disable-warnings tests
        if ($LASTEXITCODE -ne 0) { throw "AIOS pytest failed with code $LASTEXITCODE" }
    }
    finally {
        $env:PYTHONPATH = $previousPyPath
        Pop-Location
    }
}

$results += Run-Step -Name "Unified import smoke" -Action {
    Push-Location $UnifiedRepo
    try {
        & $unifiedPython -c "import src.api.server, src.core.orchestrator, src.tools.tool_registry"
        if ($LASTEXITCODE -ne 0) { throw "Unified import smoke failed with code $LASTEXITCODE" }
    }
    finally {
        Pop-Location
    }
}

$results += Run-Step -Name "AIOS import smoke" -Action {
    Push-Location $AiosRepo
    try {
        $previousPyPath = $env:PYTHONPATH
        $env:PYTHONPATH = $AiosRepo
        & $aiosPython -c "import apps.api.app.main, services.orchestrator.app.orchestrator"
        if ($LASTEXITCODE -ne 0) { throw "AIOS import smoke failed with code $LASTEXITCODE" }
    }
    finally {
        $env:PYTHONPATH = $previousPyPath
        Pop-Location
    }
}

Write-Host ""
$results | Format-Table -AutoSize

$failed = @($results | Where-Object { $_.Status -eq "FAIL" })
if ($failed.Count -gt 0) {
    Write-Host ""
    Write-Host "Full project check completed with failures." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Full project check passed for both repositories." -ForegroundColor Green
exit 0
