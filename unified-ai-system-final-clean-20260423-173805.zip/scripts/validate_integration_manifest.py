#!/usr/bin/env python
from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml  # type: ignore
from jsonschema import ValidationError, validate


def main() -> int:
    package_root = Path(__file__).resolve().parents[2]
    schema_path = package_root / "aios" / "docs" / "integration" / "repo_capability_manifest.schema.json"
    manifest_path = package_root / "aios" / "docs" / "integration" / "repo_capability_manifest.yaml"

    if not schema_path.exists():
        print(f"[ERROR] Schema not found: {schema_path}")
        return 1
    if not manifest_path.exists():
        print(f"[ERROR] Manifest not found: {manifest_path}")
        return 1

    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))

    try:
        validate(instance=manifest, schema=schema)
    except ValidationError as exc:
        print("[ERROR] Manifest validation failed")
        print(f"Path: {'/'.join(str(x) for x in exc.absolute_path)}")
        print(f"Reason: {exc.message}")
        return 2

    entries = manifest.get("entries", [])
    print(f"[OK] Manifest valid. entries={len(entries)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
