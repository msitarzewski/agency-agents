#!/bin/bash
# AI-OS Health Check Script

set -e

API_URL="${API_URL:-http://localhost:8000}"
TIMEOUT=5

check_health() {
    local url="$1"
    local name="$2"

    if curl -sf --max-time "$TIMEOUT" "$url" > /dev/null 2>&1; then
        echo "✓ $name is healthy"
        return 0
    else
        echo "✗ $name is not responding"
        return 1
    fi
}

echo "AI-OS Health Check"
echo "=================="
echo ""

failed=0

# Check API health
if ! check_health "$API_URL/health" "API Server"; then
    failed=1
fi

# Check metrics endpoint
if ! check_health "$API_URL/metrics" "Metrics"; then
    failed=1
fi

# Check docs endpoint
if ! check_health "$API_URL/docs" "API Documentation"; then
    failed=1
fi

echo ""
if [ $failed -eq 0 ]; then
    echo "All health checks passed!"
    exit 0
else
    echo "Some health checks failed!"
    exit 1
fi
