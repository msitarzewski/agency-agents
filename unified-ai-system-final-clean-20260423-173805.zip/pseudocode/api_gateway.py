"""
Unified AI System - API Gateway Implementation
REST API, WebSocket, and gRPC Service Definitions
"""

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

# =============================================================================
# API MODELS
# =============================================================================

@dataclass
class ChatMessage:
    """Chat message model"""
    role: str  # "user", "assistant", "system"
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)
    attachments: list[dict] = field(default_factory=list)


@dataclass
class ChatRequest:
    """Chat completion request"""
    model: str = "unified-ai-1"
    messages: list[ChatMessage] = field(default_factory=list)
    temperature: float = 0.7
    max_tokens: int = 4096
    stream: bool = False
    stop: list[str] | None = None
    seed: int | None = None
    modalities: list[str] = field(default_factory=lambda: ["text"])
    context_id: str | None = None


@dataclass
class ChatResponse:
    """Chat completion response"""
    id: str
    object: str = "chat.completion"
    created: int = field(default_factory=lambda: int(datetime.now(UTC).timestamp()))
    model: str
    choices: list[dict] = field(default_factory=list)
    usage: dict[str, int] = field(default_factory=lambda: {
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "total_tokens": 0
    })
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentTaskRequest:
    """Agent task creation request"""
    task_type: str
    description: str
    input_data: dict[str, Any] = field(default_factory=dict)
    constraints: dict[str, Any] = field(default_factory=dict)
    priority: str = "normal"
    workflow: str | None = None
    callback_url: str | None = None


@dataclass
class TaskStatus:
    """Task status response"""
    task_id: str
    status: str
    progress: float = 0.0
    result: dict | None = None
    error: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    agent_id: str | None = None
    subtasks: list[dict] = field(default_factory=list)


@dataclass
class KnowledgeQueryRequest:
    """Knowledge query request"""
    query: str
    top_k: int = 10
    filters: dict[str, Any] = field(default_factory=dict)
    sources: list[str] = field(default_factory=lambda: ["vector", "graph"])
    include_metadata: bool = True


@dataclass
class CodeExecutionRequest:
    """Code execution request"""
    code: str
    language: str = "python"
    timeout: int = 60
    environment: str = "sandboxed"
    dependencies: list[str] = field(default_factory=list)
    mounts: dict[str, str] = field(default_factory=dict)
    allowed_endpoints: list[str] = field(default_factory=list)


@dataclass
class ExecutionResult:
    """Code execution result"""
    execution_id: str
    status: str
    stdout: str = ""
    stderr: str = ""
    execution_time: float = 0.0
    memory_usage: int = 0
    output_files: list[dict] = field(default_factory=list)
    logs: list[dict] = field(default_factory=list)


# =============================================================================
# REST API IMPLEMENTATION
# =============================================================================

class APIRouter:
    """
    REST API Router with endpoint handlers.
    Production-grade implementation using FastAPI patterns.
    """

    def __init__(self, orchestrator):
        self.orchestrator = orchestrator
        self.rate_limiter = RateLimiter()
        self.auth_handler = AuthHandler()
        self.request_validator = RequestValidator()

    async def handle_chat_completions(self, request: ChatRequest,
                                     headers: dict) -> ChatResponse:
        """Handle chat completion requests"""
        # Authentication
        auth_result = await self.auth_handler.verify(headers)
        if not auth_result.authorized:
            raise APIError(401, "Unauthorized", "Invalid or expired token")

        # Rate limiting
        rate_result = await self.rate_limiter.check(
            auth_result.user_id,
            "chat",
            100  # requests per minute
        )
        if not rate_result.allowed:
            raise APIError(429, "Rate limit exceeded",
                          f"Limit: {rate_result.limit} per minute")

        # Validation
        validation_errors = await self.request_validator.validate(request)
        if validation_errors:
            raise APIError(400, "Validation error", validation_errors)

        # Create session
        session_id = request.context_id or str(uuid.uuid4())

        # Build internal request
        internal_request = {
            "type": "chat",
            "content": request.messages[-1].content if request.messages else "",
            "history": [{"role": m.role, "content": m.content}
                       for m in request.messages[:-1]],
            "temperature": request.temperature,
            "max_tokens": request.max_tokens,
            "modality": request.modalities,
            "priority": "normal"
        }

        # Process request
        result = await self.orchestrator.process_request(
            internal_request,
            session_id
        )

        # Build response
        response = ChatResponse(
            id=f"chat-{uuid.uuid4().hex[:8]}",
            model=request.model,
            choices=[{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": result.get("result", {}).get("content", "")
                },
                "finish_reason": "stop"
            }],
            usage={
                "prompt_tokens": result.get("metadata", {})
                                 .get("usage", {})
                                 .get("prompt_tokens", 0),
                "completion_tokens": result.get("metadata", {})
                                    .get("usage", {})
                                    .get("completion_tokens", 0),
                "total_tokens": result.get("metadata", {})
                               .get("usage", {})
                               .get("total_tokens", 0)
            },
            metadata=result.get("metadata", {})
        )

        return response

    async def handle_multimodal_process(self, request_data: dict,
                                       files: dict,
                                       headers: dict) -> dict:
        """Handle multimodal processing requests"""
        auth_result = await self.auth_handler.verify(headers)
        if not auth_result.authorized:
            raise APIError(401, "Unauthorized")

        modality = request_data.get("modality", "image")
        result = {"modality": modality, "status": "processed"}

        if modality == "image":
            # Process image
            result["analysis"] = await self._process_image(files.get("image"))
        elif modality == "audio":
            # Process audio
            result["transcription"] = await self._process_audio(files.get("audio"))
        elif modality == "video":
            # Process video
            result["analysis"] = await self._process_video(files.get("video"))
        elif modality == "multimodal":
            # Process multiple modalities
            result["analysis"] = await self._process_multimodal(files)

        return result

    async def handle_agent_task_create(self, request: AgentTaskRequest,
                                       headers: dict) -> TaskStatus:
        """Handle agent task creation"""
        auth_result = await self.auth_handler.verify(headers)
        if not auth_result.authorized:
            raise APIError(401, "Unauthorized")

        # Build task
        task_id = str(uuid.uuid4())
        task = {
            "task_type": request.task_type,
            "description": request.description,
            "input_data": request.input_data,
            "constraints": request.constraints,
            "callback_url": request.callback_url
        }

        # Submit to orchestrator
        internal_request = {
            "type": "agent_task",
            "task": task,
            "priority": request.priority
        }

        await self.orchestrator.process_request(internal_request, task_id)

        return TaskStatus(
            task_id=task_id,
            status="pending",
            created_at=datetime.now(UTC)
        )

    async def handle_agent_task_status(self, task_id: str,
                                       headers: dict) -> TaskStatus:
        """Get task status"""
        auth_result = await self.auth_handler.verify(headers)
        if not auth_result.authorized:
            raise APIError(401, "Unauthorized")

        # Get status from orchestrator
        status = await self.orchestrator.get_task_status(task_id)

        return TaskStatus(
            task_id=task_id,
            status=status.get("status", "unknown"),
            progress=status.get("progress", 0.0),
            result=status.get("result"),
            error=status.get("error"),
            agent_id=status.get("agent_id")
        )

    async def handle_knowledge_query(self, request: KnowledgeQueryRequest,
                                      headers: dict) -> dict:
        """Query knowledge system"""
        auth_result = await self.auth_handler.verify(headers)
        if not auth_result.authorized:
            raise APIError(401, "Unauthorized")

        result = await self.orchestrator.knowledge_system.query(
            request.query,
            context={"top_k": request.top_k, "filters": request.filters}
        )

        return {
            "query": request.query,
            "results": result.get("results", []),
            "confidence": result.get("confidence", 0.0),
            "sources": request.sources
        }

    async def handle_code_execution(self, request: CodeExecutionRequest,
                                     headers: dict) -> ExecutionResult:
        """Execute code in sandbox"""
        auth_result = await self.auth_handler.verify(headers)
        if not auth_result.authorized:
            raise APIError(401, "Unauthorized")

        execution_id = str(uuid.uuid4())

        # Submit to execution layer
        result = await self.orchestrator.execution_layer.execute_code({
            "code": request.code,
            "language": request.language,
            "timeout": request.timeout,
            "environment": request.environment,
            "dependencies": request.dependencies,
            "allowed_endpoints": request.allowed_endpoints
        })

        return ExecutionResult(
            execution_id=execution_id,
            status=result.get("status", "completed"),
            stdout=result.get("stdout", ""),
            stderr=result.get("stderr", ""),
            execution_time=result.get("execution_time", 0.0),
            memory_usage=result.get("memory_usage", 0)
        )

    async def handle_workflow_trigger(self, workflow_name: str,
                                      params: dict,
                                      headers: dict) -> dict:
        """Trigger workflow execution"""
        auth_result = await self.auth_handler.verify(headers)
        if not auth_result.authorized:
            raise APIError(401, "Unauthorized")

        workflow_id = str(uuid.uuid4())

        # Initialize workflow
        await self.orchestrator.workflow_engine.initialize(
            workflow_id,
            workflow_name,
            params
        )

        return {
            "workflow_id": workflow_id,
            "name": workflow_name,
            "status": "initialized"
        }

    async def _process_image(self, image_data: bytes) -> dict:
        """Process image input"""
        return {"detected_objects": [], "text_content": ""}

    async def _process_audio(self, audio_data: bytes) -> dict:
        """Process audio input"""
        return {"transcription": "", "language": ""}

    async def _process_video(self, video_data: bytes) -> dict:
        """Process video input"""
        return {"frames_analyzed": 0, "events": []}

    async def _process_multimodal(self, files: dict) -> dict:
        """Process multiple modalities"""
        results = {}
        for modality, data in files.items():
            if modality == "image":
                results["image"] = await self._process_image(data)
            elif modality == "audio":
                results["audio"] = await self._process_audio(data)
        return results


# =============================================================================
# WEBSOCKET HANDLER
# =============================================================================

class WebSocketHandler:
    """
    WebSocket handler for real-time communication.
    Supports streaming responses and agent updates.
    """

    def __init__(self, orchestrator):
        self.orchestrator = orchestrator
        self.active_connections: dict[str, WebSocketConnection] = {}
        self.message_handlers = {
            "user_message": self._handle_user_message,
            "ping": self._handle_ping,
            "subscribe": self._handle_subscribe,
            "unsubscribe": self._handle_unsubscribe
        }

    async def connect(self, websocket, session_id: str, token: str) -> bool:
        """Establish WebSocket connection"""
        # Verify token
        auth = await self._verify_token(token)
        if not auth.authorized:
            await websocket.close(1008, "Unauthorized")
            return False

        # Create connection
        connection = WebSocketConnection(
            websocket=websocket,
            session_id=session_id,
            user_id=auth.user_id
        )
        self.active_connections[session_id] = connection

        # Send welcome message
        await websocket.send_json({
            "type": "connected",
            "session_id": session_id,
            "capabilities": ["streaming", "agent_updates", "file_upload"]
        })

        return True

    async def disconnect(self, session_id: str):
        """Close WebSocket connection"""
        if session_id in self.active_connections:
            connection = self.active_connections.pop(session_id)
            await connection.cleanup()

    async def handle_message(self, session_id: str, message: dict):
        """Handle incoming WebSocket message"""
        if session_id not in self.active_connections:
            raise ValueError("Invalid session")

        connection = self.active_connections[session_id]
        message_type = message.get("type")

        if message_type in self.message_handlers:
            await self.message_handlers[message_type](connection, message)
        else:
            await connection.send_error(f"Unknown message type: {message_type}")

    async def _handle_user_message(self, connection: 'WebSocketConnection',
                                   message: dict):
        """Handle user message"""
        content = message.get("content", "")
        modality = message.get("modality", "text")

        # Send acknowledgment
        await connection.send({
            "type": "message_received",
            "message_id": message.get("message_id")
        })

        # Process streaming response
        if message.get("stream", True):
            await self._stream_response(connection, content, modality)
        else:
            result = await self._process_full_response(connection, content)
            await connection.send({
                "type": "assistant_message",
                "content": result.get("content", ""),
                "metadata": result.get("metadata", {})
            })

    async def _stream_response(self, connection: 'WebSocketConnection',
                                content: str, modality: str):
        """Stream response to client"""
        internal_request = {
            "type": "chat",
            "content": content,
            "modality": modality
        }

        # Start processing
        result = await self.orchestrator.process_request(
            internal_request,
            connection.session_id
        )

        # Stream tokens
        response_text = result.get("result", {}).get("content", "")
        for i in range(0, len(response_text), 10):
            chunk = response_text[i:i + 10]
            await connection.send({
                "type": "stream_chunk",
                "delta": chunk,
                "partial": i + 10 < len(response_text)
            })

        # Send completion
        await connection.send({
            "type": "stream_complete",
            "usage": result.get("metadata", {}).get("usage", {})
        })

    async def _process_full_response(self, connection: 'WebSocketConnection',
                                      content: str) -> dict:
        """Process full response"""
        internal_request = {
            "type": "chat",
            "content": content
        }

        return await self.orchestrator.process_request(
            internal_request,
            connection.session_id
        )

    async def _handle_ping(self, connection: 'WebSocketConnection',
                          message: dict):
        """Handle ping"""
        await connection.send({"type": "pong", "timestamp": datetime.now(UTC).isoformat()})

    async def _handle_subscribe(self, connection: 'WebSocketConnection',
                               message: dict):
        """Subscribe to events"""
        topics = message.get("topics", [])
        connection.subscriptions.update(topics)
        await connection.send({
            "type": "subscribed",
            "topics": topics
        })

    async def _handle_unsubscribe(self, connection: 'WebSocketConnection',
                                  message: dict):
        """Unsubscribe from events"""
        topics = message.get("topics", [])
        for topic in topics:
            connection.subscriptions.discard(topic)
        await connection.send({
            "type": "unsubscribed",
            "topics": topics
        })

    async def broadcast_agent_update(self, session_id: str, update: dict):
        """Broadcast agent update to subscribed connections"""
        if session_id in self.active_connections:
            connection = self.active_connections[session_id]
            if "agent_updates" in connection.subscriptions:
                await connection.send({
                    "type": "agent_update",
                    **update
                })

    async def _verify_token(self, token: str) -> 'AuthResult':
        """Verify authentication token"""
        # Implementation would verify JWT
        return AuthResult(authorized=True, user_id="user_123")


@dataclass
class WebSocketConnection:
    """WebSocket connection state"""
    websocket: Any
    session_id: str
    user_id: str
    subscriptions: set = field(default_factory=set)
    context: dict = field(default_factory=dict)

    async def send(self, message: dict):
        """Send message to client"""
        await self.websocket.send_json(message)

    async def send_error(self, error: str):
        """Send error to client"""
        await self.websocket.send_json({
            "type": "error",
            "error": error
        })

    async def cleanup(self):
        """Cleanup connection resources"""
        self.subscriptions.clear()
        self.context.clear()


# =============================================================================
# gRPC SERVICE DEFINITIONS
# =============================================================================

class UnifiedAIServiceServicer:
    """
    gRPC service implementation for high-performance communication.
    Uses Protocol Buffers for efficient serialization.
    """

    def __init__(self, orchestrator):
        self.orchestrator = orchestrator

    async def ChatCompletions(self, request, context) -> dict:
        """Handle gRPC chat completion request"""
        internal_request = {
            "type": "chat",
            "content": request.messages[-1].content,
            "history": [{"role": m.role, "content": m.content}
                       for m in request.messages[:-1]],
            "temperature": request.temperature,
            "max_tokens": request.max_tokens
        }

        result = await self.orchestrator.process_request(
            internal_request,
            request.session_id or ""
        )

        return {
            "id": f"chat-{uuid.uuid4().hex[:8]}",
            "model": request.model,
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": result.get("result", {}).get("content", "")
                }
            }]
        }

    async def StreamChatCompletions(self, request_iterator, context):
        """Handle streaming gRPC chat completion"""
        messages = []
        async for request in request_iterator:
            messages.append({
                "role": request.role,
                "content": request.content
            })

        if messages:
            internal_request = {
                "type": "chat",
                "content": messages[-1]["content"],
                "history": messages[:-1]
            }

            result = await self.orchestrator.process_request(
                internal_request,
                ""
            )

            response_text = result.get("result", {}).get("content", "")
            for i in range(0, len(response_text), 10):
                yield {
                    "type": "stream_chunk",
                    "delta": response_text[i:i + 10]
                }

    async def SubmitAgentTask(self, request, context) -> dict:
        """Handle gRPC agent task submission"""
        task = {
            "task_type": request.task_type,
            "description": request.description,
            "input_data": dict(request.input_data)
        }

        internal_request = {
            "type": "agent_task",
            "task": task
        }

        task_id = str(uuid.uuid4())
        await self.orchestrator.process_request(internal_request, task_id)

        return {
            "task_id": task_id,
            "status": "submitted"
        }

    async def GetTaskStatus(self, request, context) -> dict:
        """Get task status via gRPC"""
        return await self.orchestrator.get_task_status(request.task_id)

    async def ExecuteCode(self, request, context) -> dict:
        """Execute code via gRPC"""
        return await self.orchestrator.execution_layer.execute_code({
            "code": request.code,
            "language": request.language,
            "timeout": request.timeout
        })

    async def QueryKnowledge(self, request, context) -> dict:
        """Query knowledge system via gRPC"""
        result = await self.orchestrator.knowledge_system.query(request.query)
        return {
            "results": result.get("results", []),
            "confidence": result.get("confidence", 0.0)
        }


# =============================================================================
# AUTHENTICATION & SECURITY
# =============================================================================

@dataclass
class AuthResult:
    """Authentication result"""
    authorized: bool
    user_id: str
    tier: str = "default"
    scopes: list[str] = field(default_factory=list)
    expires_at: datetime | None = None


class AuthHandler:
    """Handle authentication and authorization"""

    def __init__(self):
        self.token_store = {}
        self.api_keys = {}

    async def verify(self, headers: dict) -> AuthResult:
        """Verify request authentication"""
        # Check Bearer token
        auth_header = headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
            return await self._verify_token(token)

        # Check API key
        api_key = headers.get("X-API-Key", "")
        if api_key:
            return await self._verify_api_key(api_key)

        return AuthResult(authorized=False, user_id="")

    async def _verify_token(self, token: str) -> AuthResult:
        """Verify JWT token"""
        # In production, verify signature and claims
        if token in self.token_store:
            return self.token_store[token]
        return AuthResult(authorized=False, user_id="")

    async def _verify_api_key(self, api_key: str) -> AuthResult:
        """Verify API key"""
        if api_key in self.api_keys:
            key_data = self.api_keys[api_key]
            return AuthResult(
                authorized=True,
                user_id=key_data.get("user_id", ""),
                tier=key_data.get("tier", "default"),
                scopes=key_data.get("scopes", [])
            )
        return AuthResult(authorized=False, user_id="")


class RateLimiter:
    """Rate limiting for API requests"""

    def __init__(self):
        self.limits = {
            "default": {"requests": 100, "window": 60},
            "premium": {"requests": 1000, "window": 60},
            "enterprise": {"requests": 10000, "window": 60}
        }
        self.user_usage: dict[str, list[datetime]] = {}

    async def check(self, user_id: str, endpoint: str,
                   limit: int) -> 'RateLimitResult':
        """Check if request is within rate limit"""
        now = datetime.now(UTC)
        window_start = now.timestamp() - 60  # 1-minute window

        if user_id not in self.user_usage:
            self.user_usage[user_id] = []

        # Clean old timestamps
        self.user_usage[user_id] = [
            ts for ts in self.user_usage[user_id]
            if ts.timestamp() > window_start
        ]

        # Check limit
        current_usage = len(self.user_usage[user_id])
        if current_usage >= limit:
            return RateLimitResult(
                allowed=False,
                current=current_usage,
                limit=limit,
                reset_at=datetime.fromtimestamp(
                    window_start + 60
                )
            )

        # Record request
        self.user_usage[user_id].append(now)

        return RateLimitResult(
            allowed=True,
            current=current_usage + 1,
            limit=limit,
            remaining=limit - current_usage - 1
        )


@dataclass
class RateLimitResult:
    """Rate limit check result"""
    allowed: bool
    current: int
    limit: int
    remaining: int | None = None
    reset_at: datetime | None = None
    retry_after: int | None = None


class RequestValidator:
    """Validate incoming requests"""

    def __init__(self):
        self.max_message_length = 100000
        self.max_file_size = 100 * 1024 * 1024  # 100MB
        self.allowed_content_types = ["text", "image", "audio", "video", "code"]

    async def validate(self, request: Any) -> list[str]:
        """Validate request and return errors"""
        errors = []

        if isinstance(request, ChatRequest):
            errors.extend(self._validate_chat_request(request))
        elif isinstance(request, CodeExecutionRequest):
            errors.extend(self._validate_code_request(request))

        return errors

    def _validate_chat_request(self, request: ChatRequest) -> list[str]:
        """Validate chat request"""
        errors = []

        if not request.messages:
            errors.append("At least one message is required")

        for msg in request.messages:
            if len(msg.content) > self.max_message_length:
                errors.append(
                    f"Message content exceeds {self.max_message_length} characters"
                )

        if request.temperature < 0 or request.temperature > 2:
            errors.append("Temperature must be between 0 and 2")

        if request.max_tokens < 1 or request.max_tokens > 32000:
            errors.append("max_tokens must be between 1 and 32000")

        return errors

    def _validate_code_request(self, request: CodeExecutionRequest) -> list[str]:
        """Validate code execution request"""
        errors = []

        if not request.code:
            errors.append("Code is required")

        if request.timeout < 1 or request.timeout > 300:
            errors.append("Timeout must be between 1 and 300 seconds")

        allowed_languages = ["python", "javascript", "typescript", "java",
                            "go", "rust", "c", "cpp"]
        if request.language not in allowed_languages:
            errors.append(f"Language must be one of: {allowed_languages}")

        return errors


# =============================================================================
# ERROR HANDLING
# =============================================================================

class APIError(Exception):
    """API error with status code"""

    def __init__(self, status_code: int, error_type: str, message: str,
                 details: dict = None):
        self.status_code = status_code
        self.error_type = error_type
        self.message = message
        self.details = details or {}
        super().__init__(message)

    def to_dict(self) -> dict:
        """Convert to API response dict"""
        return {
            "error": {
                "type": self.error_type,
                "message": self.message,
                "details": self.details
            }
        }


class ErrorMiddleware:
    """Middleware for handling API errors"""

    def __init__(self, app):
        self.app = app

    async def __call__(self, request, call_next):
        try:
            response = await call_next(request)
            return response
        except APIError as e:
            return JSONResponse(
                status_code=e.status_code,
                content=e.to_dict()
            )
        except Exception:
            return JSONResponse(
                status_code=500,
                content={
                    "error": {
                        "type": "internal_error",
                        "message": "An internal error occurred",
                        "details": {}
                    }
                }
            )


# =============================================================================
# API DOCUMENTATION
# =============================================================================

API_OPENAPI_SPEC = """
openapi: 3.1.0
info:
  title: Unified AI System API
  version: 1.0.0
  description: Production API for the Unified AI System

servers:
  - url: https://api.unified-ai.example.com/v1
    description: Production server
  - url: https://api-staging.unified-ai.example.com/v1
    description: Staging server

paths:
  /chat/completions:
    post:
      summary: Create chat completion
      operationId: createChatCompletion
      tags:
        - Chat
      security:
        - BearerAuth: []
        - ApiKeyAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ChatRequest'
      responses:
        '200':
          description: Successful response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ChatResponse'
        '401':
          $ref: '#/components/responses/Unauthorized'
        '429':
          $ref: '#/components/responses/RateLimited'

  /agents/tasks:
    post:
      summary: Create agent task
      operationId: createAgentTask
      tags:
        - Agents
      security:
        - BearerAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/AgentTaskRequest'
      responses:
        '200':
          description: Task created
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/TaskStatus'

  /knowledge/query:
    post:
      summary: Query knowledge system
      operationId: queryKnowledge
      tags:
        - Knowledge
      security:
        - BearerAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/KnowledgeQueryRequest'
      responses:
        '200':
          description: Query results
          content:
            application/json:
              schema:
                type: object
                properties:
                  query:
                    type: string
                  results:
                    type: array
                    items:
                      $ref: '#/components/schemas/KnowledgeResult'
                  confidence:
                    type: number

  /execute/code:
    post:
      summary: Execute code in sandbox
      operationId: executeCode
      tags:
        - Execution
      security:
        - BearerAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CodeExecutionRequest'
      responses:
        '200':
          description: Execution result
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ExecutionResult'

components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
    ApiKeyAuth:
      type: apiKey
      in: header
      name: X-API-Key

  schemas:
    ChatRequest:
      type: object
      required:
        - messages
      properties:
        model:
          type: string
          default: unified-ai-1
        messages:
          type: array
          items:
            $ref: '#/components/schemas/ChatMessage'
        temperature:
          type: number
          minimum: 0
          maximum: 2
          default: 0.7
        max_tokens:
          type: integer
          minimum: 1
          maximum: 32000
          default: 4096
        stream:
          type: boolean
          default: false

    ChatMessage:
      type: object
      required:
        - role
        - content
      properties:
        role:
          type: string
          enum: [user, assistant, system]
        content:
          type: string
        metadata:
          type: object

    ChatResponse:
      type: object
      properties:
        id:
          type: string
        object:
          type: string
        created:
          type: integer
        model:
          type: string
        choices:
          type: array
          items:
            type: object
        usage:
          $ref: '#/components/schemas/Usage'

    AgentTaskRequest:
      type: object
      required:
        - task_type
        - description
      properties:
        task_type:
          type: string
        description:
          type: string
        input_data:
          type: object
        constraints:
          type: object
        priority:
          type: string
          enum: [low, normal, high, critical]

    TaskStatus:
      type: object
      properties:
        task_id:
          type: string
        status:
          type: string
        progress:
          type: number
        result:
          type: object
        error:
          type: string

    KnowledgeQueryRequest:
      type: object
      required:
        - query
      properties:
        query:
          type: string
        top_k:
          type: integer
          default: 10
        filters:
          type: object
        sources:
          type: array
          items:
            type: string

    CodeExecutionRequest:
      type: object
      required:
        - code
      properties:
        code:
          type: string
        language:
          type: string
          default: python
        timeout:
          type: integer
          default: 60
        environment:
          type: string
          default: sandboxed

    ExecutionResult:
      type: object
      properties:
        execution_id:
          type: string
        status:
          type: string
        stdout:
          type: string
        stderr:
          type: string
        execution_time:
          type: number
        memory_usage:
          type: integer

  responses:
    Unauthorized:
      description: Authentication required
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Error'
    RateLimited:
      description: Rate limit exceeded
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Error'

  schemas:
    Error:
      type: object
      properties:
        error:
          type: object
          properties:
            type:
              type: string
            message:
              type: string
            details:
              type: object

    Usage:
      type: object
      properties:
        prompt_tokens:
          type: integer
        completion_tokens:
          type: integer
        total_tokens:
          type: integer

    KnowledgeResult:
      type: object
      properties:
        id:
          type: string
        content:
          type: string
        score:
          type: number
        metadata:
          type: object
"""
