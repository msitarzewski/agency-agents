import pytest

from src.protocols.a2a_acp_adapter import (
    parse_protocol_message,
    task_to_protocol_response,
    to_normalized_task,
    verify_message_auth,
)
from src.protocols.models import AgentActionType, ProtocolMessageType


def test_parse_and_normalize_a2a_message():
    raw = {
        "protocol": "a2a",
        "version": "1.0",
        "message_type": "request",
        "correlation_id": "corr-123",
        "source": {"agent_id": "agent-alpha", "role": "planner"},
        "action": "delegate",
        "payload": {
            "task_id": "task-1",
            "title": "Integrate capability",
            "objective": "Add protocol adapter",
            "constraints": {"risk": "low"},
            "context": {"repo": "unified-ai-system"},
        },
    }

    envelope = parse_protocol_message(raw)
    assert envelope.message_type == ProtocolMessageType.REQUEST
    assert envelope.action == AgentActionType.DELEGATE

    normalized = to_normalized_task(envelope)
    assert normalized.task_id == "task-1"
    assert normalized.source_protocol == "a2a"
    assert normalized.constraints["risk"] == "low"


def test_protocol_response_shape():
    response = task_to_protocol_response(
        task_id="task-2",
        status="completed",
        result={"ok": True},
        protocol="acp",
    )

    assert response["protocol"] == "acp"
    assert response["message_type"] == "response"
    assert response["payload"]["status"] == "completed"
    assert response["payload"]["result"]["ok"] is True


def test_parse_rejects_missing_required_fields():
    with pytest.raises(ValueError, match="Missing required protocol fields"):
        parse_protocol_message({"protocol": "a2a"})


def test_parse_rejects_unsupported_protocol():
    raw = {
        "protocol": "invalid",
        "version": "1.0",
        "message_type": "request",
        "correlation_id": "corr-456",
        "source": {"agent_id": "agent-a", "role": "planner"},
        "action": "delegate",
        "payload": {},
    }
    with pytest.raises(ValueError, match="Unsupported protocol"):
        parse_protocol_message(raw)


def test_normalize_rejects_non_object_constraints():
    raw = {
        "protocol": "a2a",
        "version": "1.0",
        "message_type": "request",
        "correlation_id": "corr-789",
        "source": {"agent_id": "agent-alpha", "role": "planner"},
        "action": "delegate",
        "payload": {
            "task_id": "task-9",
            "constraints": "not-a-dict",
        },
    }
    envelope = parse_protocol_message(raw)
    with pytest.raises(ValueError, match="constraints must be an object"):
        to_normalized_task(envelope)


def test_verify_message_auth_matches_shared_token():
    raw = {"metadata": {"auth_token": "secret-token"}}
    assert verify_message_auth(raw, "secret-token") is True
    assert verify_message_auth(raw, "wrong-token") is False
