import pytest

from src.core.orchestrator import Task, TaskGraph, TaskPriority


def _task(task_id: str) -> Task:
    return Task(
        task_id=task_id,
        task_type="unit",
        description=f"task {task_id}",
        priority=TaskPriority.NORMAL,
    )


def test_add_edge_rejects_unknown_source() -> None:
    graph = TaskGraph("g1")
    graph.add_node(_task("t1"))

    with pytest.raises(ValueError, match="Source node not found"):
        graph.add_edge("missing", "t1")


def test_add_edge_rejects_unknown_target() -> None:
    graph = TaskGraph("g1")
    graph.add_node(_task("t1"))

    with pytest.raises(ValueError, match="Target node not found"):
        graph.add_edge("t1", "missing")


def test_add_edge_rejects_self_loop() -> None:
    graph = TaskGraph("g1")
    graph.add_node(_task("t1"))

    with pytest.raises(ValueError, match="Self-loop"):
        graph.add_edge("t1", "t1")


def test_add_edge_prevents_cycle() -> None:
    graph = TaskGraph("g1")
    graph.add_node(_task("a"))
    graph.add_node(_task("b"))
    graph.add_node(_task("c"))

    graph.add_edge("a", "b")
    graph.add_edge("b", "c")

    with pytest.raises(ValueError, match="introduces a cycle"):
        graph.add_edge("c", "a")


def test_add_edge_duplicate_is_noop() -> None:
    graph = TaskGraph("g1")
    graph.add_node(_task("a"))
    graph.add_node(_task("b"))

    graph.add_edge("a", "b")
    graph.add_edge("a", "b")

    assert graph.edges["a"] == ["b"]
