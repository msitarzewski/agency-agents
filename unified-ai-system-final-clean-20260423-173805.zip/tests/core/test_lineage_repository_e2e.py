import asyncio
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

from src.api.server import APIServer, TaskRequest, create_app
from src.core.lineage import normalize_lineage
from src.core.lineage_repository import FileLineageRepository
from src.core.orchestrator import ExecutionResult, Orchestrator, Task, TaskPriority, TaskStatus
from src.tools.tool_registry import Tool, ToolCategory, ToolPermission, create_tool_registry


def _tool_impl(params, context):
    return {
        "success": True,
        "echo": params,
        "trace_id": context.get("trace_id"),
    }


def test_lineage_openapi_examples_are_published() -> None:
    app = create_app()
    schema = app.openapi()

    task_response_schema = schema["components"]["schemas"]["TaskResponse"]
    task_response_example = task_response_schema["examples"][0]
    assert task_response_example["metadata"]["lineage"]["request_id"] == "req-demo-001"
    assert task_response_example["metadata"]["lineage"]["trace_id"] == "trace-demo-001"

    search_operation = schema["paths"]["/v1/tasks/search"]["get"]
    search_example = search_operation["responses"]["200"]["content"]["application/json"][
        "examples"
    ]["lineage_lookup"]["value"]
    assert search_example["count"] == 1
    assert search_example["results"][0]["lineage"]["source"] == "chat_completion"

    get_task_operation = schema["paths"]["/v1/tasks/{task_id}"]["get"]
    missing_task_example = get_task_operation["responses"]["404"]["content"]["application/json"][
        "examples"
    ]["task_missing"]["value"]
    assert missing_task_example["detail"] == "Task not found"

    unavailable_task_response = get_task_operation["responses"]["503"]["description"]
    assert unavailable_task_response == "Service unavailable"

    list_agents_operation = schema["paths"]["/v1/agents"]["get"]
    list_agents_503_example = list_agents_operation["responses"]["503"]["content"][
        "application/json"
    ]["examples"]["orchestrator_unavailable"]["value"]
    assert list_agents_503_example["detail"] == "Orchestrator not available"

    list_tools_operation = schema["paths"]["/v1/tools"]["get"]
    list_tools_503_example = list_tools_operation["responses"]["503"]["content"][
        "application/json"
    ]["examples"]["tool_registry_unavailable"]["value"]
    assert list_tools_503_example["detail"] == "Tool registry not available"

    cancel_task_operation = schema["paths"]["/v1/tasks/{task_id}"]["delete"]
    cancel_task_404_example = cancel_task_operation["responses"]["404"]["content"][
        "application/json"
    ]["examples"]["task_missing"]["value"]
    assert cancel_task_404_example["detail"] == "Task not found"

    cancel_task_503_example = cancel_task_operation["responses"]["503"]["content"][
        "application/json"
    ]["examples"]["orchestrator_unavailable"]["value"]
    assert cancel_task_503_example["detail"] == "Orchestrator not available"


def test_api_ingress_orchestrator_tool_and_storage_share_one_lineage_chain() -> None:
    with TemporaryDirectory() as temp_dir:
        repository = FileLineageRepository(Path(temp_dir) / "lineage")

        class StubOrchestrator(Orchestrator):
            async def submit_task(
                self,
                task_type: str,
                description: str,
                inputs: dict[str, Any],
                constraints: dict[str, Any] | None = None,
                priority: TaskPriority = TaskPriority.NORMAL,
            ) -> str:
                await asyncio.sleep(0)
                task_id = f"task_{self._task_counter + 1:06d}"
                task = Task(
                    task_id=task_id,
                    task_type=task_type,
                    description=description,
                    priority=priority,
                    status=TaskStatus.RUNNING,
                    inputs=dict(inputs),
                    constraints=constraints or {},
                )
                task.inputs["_lineage"] = normalize_lineage(
                    raw_lineage=task.inputs.get("_lineage"),
                    trace_id=task.trace_id,
                    session_id=task.inputs.get("session_id"),
                    parent_task_id=task.parent_task_id,
                    source=task.inputs.get("_lineage", {}).get("source", "submit_task"),
                    source_message_id=task.inputs.get("source_message_id"),
                    input_payload=task.inputs,
                )
                self._task_counter += 1
                self.active_tasks[task_id] = task
                self._persist_task_snapshot(task)
                return task_id

            async def get_task_status(self, task_id: str):
                await asyncio.sleep(0)
                task = self.active_tasks[task_id]
                return {
                    "task_id": task.task_id,
                    "status": "completed",
                    "outputs": {"response": "accepted"},
                    "trace_id": task.trace_id,
                    "lineage": dict(task.inputs.get("_lineage") or {}),
                    "reasoning_confidence": None,
                    "reasoning_mode": None,
                    "reasoning_deferred": False,
                }

        orchestrator = StubOrchestrator(lineage_repository=repository)
        tool_registry = create_tool_registry(lineage_repository=repository)
        tool_registry.register_tool(
            Tool(
                tool_id="lineage_echo",
                tool_name="lineage_echo",
                category=ToolCategory.CUSTOM,
                description="Echo lineage",
                implementation_type="function",
                implementation=_tool_impl,
                input_schema={
                    "type": "object",
                    "required": ["message"],
                    "properties": {"message": {"type": "string"}},
                },
                output_schema={
                    "type": "object",
                    "required": ["success", "echo", "trace_id"],
                    "properties": {
                        "success": {"type": "boolean"},
                        "echo": {"type": "object"},
                        "trace_id": {"type": "string"},
                    },
                },
                permissions=[ToolPermission(role="*", tier="*")],
            )
        )

        server = APIServer(orchestrator=orchestrator, tool_registry=tool_registry)

        response = asyncio.run(
            server._handle_task(
                TaskRequest(
                    task_type="analysis",
                    description="Trace a request",
                    inputs={
                        "session_id": "session-e2e",
                        "source_message_id": "message-e2e",
                        "_lineage": {
                            "request_id": "req-e2e-001",
                            "trace_id": "trace-e2e-001",
                            "source": "chat_completion",
                            "tool_invocation_ids": [],
                            "memory_refs": [],
                        },
                    },
                )
            )
        )

        task_id = response.task_id
        task_lineage = response.metadata["lineage"]

        tool_invocation = asyncio.run(
            tool_registry.execute_tool(
                tool_id="lineage_echo",
                params={"message": "hello"},
                execution_context={
                    "user_role": "*",
                    "user_tier": "*",
                    "task_id": task_id,
                    "session_id": "session-e2e",
                    "trace_id": task_lineage["trace_id"],
                    "_lineage": task_lineage,
                },
            )
        )

        asyncio.run(
            orchestrator.handle_task_result(
                task_id,
                ExecutionResult(
                    success=True,
                    output={
                        "response": "completed",
                        "tool_invocation_id": tool_invocation.invocation_id,
                    },
                ),
            )
        )

        search_response = asyncio.run(
            server._search_tasks(
                trace_id=task_lineage["trace_id"],
                request_id=None,
                source_message_id=None,
            )
        )
        assert search_response.count == 1
        assert search_response.results[0]["task_id"] == task_id
        assert search_response.results[0]["lineage"]["request_id"] == "req-e2e-001"

        task_snapshot_path = Path(temp_dir) / "lineage" / "tasks.jsonl"
        tool_snapshot_path = Path(temp_dir) / "lineage" / "tool_invocations.jsonl"
        assert task_snapshot_path.exists()
        assert tool_snapshot_path.exists()

        task_entries = [
            json.loads(line)
            for line in task_snapshot_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        tool_entries = [
            json.loads(line)
            for line in tool_snapshot_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]

        matching_task_entries = [entry for entry in task_entries if entry["task_id"] == task_id]
        assert len(matching_task_entries) >= 2
        assert all(
            entry["lineage"]["trace_id"] == "trace-e2e-001" for entry in matching_task_entries
        )
        assert matching_task_entries[-1]["lineage"]["output_ref"] is not None
        assert matching_task_entries[-1]["status"] == "completed"

        assert len(tool_entries) == 1
        assert tool_entries[0]["task_id"] == task_id
        assert tool_entries[0]["lineage"]["trace_id"] == "trace-e2e-001"
        assert tool_invocation.invocation_id in tool_entries[0]["lineage"]["tool_invocation_ids"]
