import asyncio
from datetime import UTC, datetime
from unittest.mock import patch

import httpx
import pytest

from src.tools.tool_registry import (
    CodeExecutionTool,
    ExecutionMode,
    Tool,
    ToolCategory,
    ToolPermission,
    ToolRegistry,
    ToolStatus,
    WebSearchTool,
    create_tool_registry,
)


def _sync_dict_impl(params, _context):
    return {"ok": True, "echo": params}


async def _async_dict_impl(params, _context):
    await asyncio.sleep(0)
    return {"ok": True, "echo": params}


def _non_dict_impl(_params, _context):
    return "not-a-dict"


def _build_tool(
    tool_id: str = "t1",
    *,
    implementation=_sync_dict_impl,
    implementation_type: str = "function",
    status: ToolStatus = ToolStatus.ACTIVE,
    tags: list[str] | None = None,
    input_schema: dict | None = None,
    output_schema: dict | None = None,
    security_level: str = "standard",
    rate_limit_rpm: int = 100,
) -> Tool:
    return Tool(
        tool_id=tool_id,
        tool_name=tool_id,
        category=ToolCategory.CUSTOM,
        description="test-tool",
        implementation_type=implementation_type,
        implementation=implementation,
        input_schema=input_schema or {"type": "object", "properties": {}},
        output_schema=output_schema or {"type": "object", "properties": {}},
        permissions=[ToolPermission(role="*", tier="*")],
        status=status,
        tags=tags or [],
        security_level=security_level,
        rate_limit_rpm=rate_limit_rpm,
    )


def _ctx(role: str = "standard", tier: str = "standard") -> dict:
    return {"user_role": role, "user_tier": tier, "task_id": "task-1", "session_id": "sess-1"}


@pytest.mark.asyncio
async def test_execute_tool_not_found_and_permission_and_validation() -> None:
    registry = ToolRegistry()

    missing = await registry.execute_tool("missing", {}, _ctx())
    assert missing.status == "failed"
    assert "Tool not found" in (missing.error or "")

    strict = _build_tool(
        "strict",
        input_schema={
            "type": "object",
            "required": ["query", "email"],
            "properties": {
                "query": {"type": "string"},
                "email": {"type": "string", "format": "email"},
            },
        },
    )
    strict.permissions = [ToolPermission(role="admin", tier="pro")]
    registry.register_tool(strict)

    bad_input = await registry.execute_tool("strict", {"query": 123}, _ctx("admin", "pro"))
    assert bad_input.status == "failed"
    assert "Input validation failed" in (bad_input.error or "")

    denied = await registry.execute_tool("strict", {"query": "x", "email": "a@b.com"}, _ctx())
    assert denied.status == "failed"
    assert denied.error == "Insufficient permissions"


@pytest.mark.asyncio
async def test_execute_tool_rate_limit_and_no_enforced_timeout_path() -> None:
    registry = ToolRegistry()

    limited = _build_tool("limited", rate_limit_rpm=1)
    registry.register_tool(limited)
    key = "limited:standard"
    now = datetime.now(UTC)
    registry.rate_limiters[key] = [now]
    denied = await registry.execute_tool("limited", {}, _ctx())
    assert denied.status == "failed"
    assert denied.error == "Rate limit exceeded"

    async def _slow_impl(_params, _context):
        await asyncio.sleep(0.05)
        return {"ok": True}

    slow = _build_tool("slow", implementation=_slow_impl)
    slow.timeout_seconds = 0.01
    registry.register_tool(slow)
    # Current registry implementation does not wrap execution in asyncio.wait_for,
    # so this remains completed despite timeout_seconds being low.
    timed_out = await registry.execute_tool("slow", {}, _ctx())
    assert timed_out.status == "completed"


@pytest.mark.asyncio
async def test_execute_tool_dry_run_masks_sensitive_values() -> None:
    registry = ToolRegistry()
    tool = _build_tool("dry")
    registry.register_tool(tool)

    invocation = await registry.execute_tool(
        "dry",
        {"token": "secret", "nested": {"password": "p", "safe": "ok"}},
        _ctx(),
        mode=ExecutionMode.DRY_RUN,
    )
    assert invocation.status == "completed"
    assert invocation.result is not None
    assert invocation.result["simulated"] is True
    assert invocation.result["params_preview"]["token"] == "***REDACTED***"
    assert invocation.result["params_preview"]["nested"]["password"] == "***REDACTED***"
    assert invocation.result["params_preview"]["nested"]["safe"] == "ok"


@pytest.mark.asyncio
async def test_execute_tool_blocks_beta_stub_in_live_mode() -> None:
    registry = ToolRegistry()
    stub = _build_tool("stubby", status=ToolStatus.BETA, tags=["stub"])
    registry.register_tool(stub)
    invocation = await registry.execute_tool("stubby", {}, _ctx())
    assert invocation.status == "failed"
    assert "stub" in (invocation.error or "")


@pytest.mark.asyncio
async def test_execute_tool_non_dict_result_fails() -> None:
    registry = ToolRegistry()
    tool = _build_tool("bad-return", implementation=_non_dict_impl)
    registry.register_tool(tool)
    invocation = await registry.execute_tool("bad-return", {}, _ctx())
    assert invocation.status == "failed"
    assert "must return a dict" in (invocation.error or "")


@pytest.mark.asyncio
async def test_execute_tool_async_function_and_success_rate_metrics() -> None:
    registry = ToolRegistry()
    tool = _build_tool("async-ok", implementation=_async_dict_impl)
    registry.register_tool(tool)

    first = await registry.execute_tool("async-ok", {"a": 1}, _ctx())
    second = await registry.execute_tool("async-ok", {"b": 2}, _ctx())
    assert first.status == "completed"
    assert second.status == "completed"
    assert tool.usage_count == 2
    assert tool.success_rate == pytest.approx(1.0)
    assert tool.avg_execution_time_ms >= 0


class _DummyResponse:
    def __init__(self, payload, status_code: int = 200, content_type: str = "application/json"):
        self._payload = payload
        self.status_code = status_code
        self.headers = {"content-type": content_type}
        self.text = payload if isinstance(payload, str) else "{}"

    def json(self):
        if isinstance(self._payload, str):
            raise ValueError("not-json")
        return self._payload


class _DummyClient:
    def __init__(self, response: _DummyResponse | None = None, raises: Exception | None = None):
        self._response = response
        self._raises = raises

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def request(self, *_args, **_kwargs):
        if self._raises:
            raise self._raises
        return self._response


@pytest.mark.asyncio
async def test_api_tool_success_text_and_http_exception_paths() -> None:
    registry = ToolRegistry()
    api_tool = _build_tool("api", implementation_type="api")
    api_tool.implementation_url = "https://example.com/search"
    registry.register_tool(api_tool)

    with patch(
        "src.tools.tool_registry.httpx.AsyncClient",
        return_value=_DummyClient(_DummyResponse("plain", 200, "text/plain")),
    ):
        ok = await registry.execute_tool("api", {"method": "GET"}, _ctx())
    assert ok.status == "completed"
    assert ok.result is not None
    assert ok.result["status"] == "success"

    with patch(
        "src.tools.tool_registry.httpx.AsyncClient",
        return_value=_DummyClient(raises=httpx.HTTPError("network down")),
    ):
        failed = await registry.execute_tool("api", {"method": "GET"}, _ctx())
    assert failed.status == "failed"
    assert "HTTP request failed" in (failed.error or "")


@pytest.mark.asyncio
async def test_docker_tool_command_arg_validation_and_subprocess_result() -> None:
    registry = ToolRegistry()
    docker_tool = _build_tool("docker", implementation_type="docker")
    docker_tool.implementation_url = "ubuntu:latest"
    registry.register_tool(docker_tool)

    bad_cmd = await registry.execute_tool("docker", {"command": 123}, _ctx())
    assert bad_cmd.status == "failed"
    assert "must be a string" in (bad_cmd.error or "")

    bad_args = await registry.execute_tool("docker", {"command": "echo", "args": "oops"}, _ctx())
    assert bad_args.status == "failed"
    assert "list of strings" in (bad_args.error or "")

    class _RunResult:
        returncode = 0
        stdout = '{"ok": true}'
        stderr = ""

    with patch("src.tools.tool_registry.subprocess.run", return_value=_RunResult()):
        ok = await registry.execute_tool("docker", {"command": "echo", "args": ["hi"]}, _ctx())
    assert ok.status == "completed"
    assert ok.result is not None
    assert ok.result["status"] == "success"
    assert ok.result["data"]["ok"] is True


def test_tool_lookup_search_and_agent_filtering() -> None:
    registry = ToolRegistry()
    t_active = _build_tool("active-tool")
    t_active.capabilities = ["search", "transform"]
    t_active.tags = ["alpha", "beta"]
    t_inactive = _build_tool("inactive-tool")
    t_inactive.status = ToolStatus.INACTIVE
    t_inactive.capabilities = ["search"]
    registry.register_tool(t_active)
    registry.register_tool(t_inactive)

    assert registry.get_tool("active-tool") is not None
    assert registry.get_tool_by_name("active-tool") is not None
    assert registry.get_tool_by_name("missing") is None

    by_query = registry.search_tools(query="active")
    assert len(by_query) == 2

    by_category = registry.search_tools(category=ToolCategory.CUSTOM)
    assert len(by_category) == 2

    by_tags = registry.search_tools(tags=["alpha"])
    assert [tool.tool_id for tool in by_tags] == ["active-tool"]

    by_caps = registry.search_tools(capabilities=["transform"])
    assert [tool.tool_id for tool in by_caps] == ["active-tool"]

    agent_tools = registry.get_tools_for_agent(["search"])
    assert [tool.tool_id for tool in agent_tools] == ["active-tool"]


def test_validation_helpers_and_output_validation() -> None:
    registry = ToolRegistry()
    ok, errors = registry._validate_input_schema(
        {"name": "x", "age": 20, "active": True, "items": [1], "meta": {"k": 1}},
        {
            "type": "object",
            "required": ["name", "email", "site"],
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "number"},
                "active": {"type": "boolean"},
                "items": {"type": "array"},
                "meta": {"type": "object"},
                "email": {"type": "string", "format": "email"},
                "site": {"type": "string", "format": "uri"},
            },
        },
    )
    assert ok is False
    assert any("Missing required parameter" in err for err in errors)

    out_ok, out_errors = registry._validate_output_schema(None, {"type": "null"})
    assert out_ok is True
    assert out_errors == []

    out_bad, out_bad_errors = registry._validate_output_schema({"a": 1}, {"required": ["a", "b"]})
    assert out_bad is False
    assert any("Missing required output field: b" in err for err in out_bad_errors)


def test_security_and_utility_helpers() -> None:
    registry = ToolRegistry()

    assert ToolRegistry._is_safe_http_url("https://example.com") is True
    assert ToolRegistry._is_safe_http_url("http://127.0.0.1") is False
    assert ToolRegistry._is_safe_http_url("https://localhost") is False
    assert ToolRegistry._is_safe_http_url("notaurl") is False

    assert ToolRegistry._is_safe_container_image("ubuntu:22.04") is True
    assert ToolRegistry._is_safe_container_image("ubuntu latest") is False

    assert ToolRegistry._is_valid_email("a@b.com") is True
    assert ToolRegistry._is_valid_email("bad") is False
    assert ToolRegistry._is_valid_uri("https://example.com") is True
    assert ToolRegistry._is_valid_uri("ftp://example.com") is False

    flattened = ToolRegistry._flatten_param_values({"a": [1, True, None], "b": {"c": "x"}})
    assert "1" in flattened
    assert "True" in flattened
    assert "x" in flattened

    findings = ToolRegistry._detect_injection_findings(
        "<script>alert(1)</script>", [("xss", r"<script")]
    )
    assert len(findings) == 1
    assert findings[0]["type"] == "xss"

    scan = registry._scan_params_recursive({"text": "hello"})
    assert scan["passed"] is True


@pytest.mark.asyncio
async def test_run_security_scan_external_scanner_paths() -> None:
    registry = ToolRegistry()
    tool = _build_tool("scanner-tool", security_level="elevated")

    async def _allow(_params, _tool):
        return {"passed": True, "risk_level": "low"}

    async def _deny(_params, _tool):
        return {"passed": False, "risk_level": "high", "reason": "blocked externally"}

    registry.security_scanner = _allow
    allowed = await registry._run_security_scan({"q": "safe"}, tool)
    assert allowed["passed"] is True

    registry.security_scanner = _deny
    denied = await registry._run_security_scan({"q": "safe"}, tool)
    assert denied["passed"] is False
    assert denied["reason"] == "blocked externally"


def test_metrics_confidence_and_rate_limit_helpers() -> None:
    registry = ToolRegistry()
    tool = _build_tool("metrics-tool")
    registry.register_tool(tool)

    # Build history via sync invocations.
    inv1 = asyncio.run(registry.execute_tool("metrics-tool", {}, _ctx()))
    inv2 = asyncio.run(registry.execute_tool("metrics-tool", {}, _ctx()))
    assert inv1.status == "completed"
    assert inv2.status == "completed"

    # Force confidence penalties.
    tool.avg_execution_time_ms = 1
    inv2.execution_time_ms = 3
    inv2.validation_errors = ["x"]
    inv2.risk_level = "high"
    assert registry._calculate_confidence(inv2) == pytest.approx(0.4)

    # Helper rate limiter path for unknown tool.
    assert registry._check_rate_limit("unknown-tool", "standard") is True

    metrics = registry.get_metrics()
    assert metrics["total_tools"] >= 1
    assert metrics["active_tools"] >= 1
    assert metrics["total_invocations"] >= 2
    assert 0 <= metrics["success_rate"] <= 1


def test_default_registry_and_tool_implementations() -> None:
    registry = create_tool_registry()
    assert set(registry.tools.keys()) == {
        "web_search",
        "code_execution",
        "database_query",
        "document_analysis",
        "image_analysis",
    }

    web = WebSearchTool()
    assert web.execute({}, {})["success"] is False
    success_web = web.execute({"query": "ai", "max_results": 10}, {})
    assert success_web["success"] is True
    assert success_web["count"] <= 5

    code = CodeExecutionTool()
    assert code.execute({}, {})["success"] is False
    success_code = code.execute({"code": "print(1)", "language": "python"}, {})
    assert success_code["success"] is True
