import asyncio
from datetime import UTC, datetime
from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

from src.core.lineage_repository import FileLineageRepository
from src.core.orchestrator import ExecutionResult, Orchestrator, Task, TaskPriority, TaskStatus


def _sample_protocol_message(auth_token: str = "top-secret"):
    return {
        "protocol": "a2a",
        "version": "1.0",
        "message_type": "request",
        "correlation_id": "proto-corr-1",
        "source": {"agent_id": "ext-agent", "role": "planner"},
        "action": "delegate",
        "metadata": {"auth_token": auth_token},
        "payload": {
            "task_id": "proto-task-1",
            "title": "External Task",
            "objective": "Run protocol ingress",
            "constraints": {"action_risk_levels": ["low"]},
            "context": {"session_id": "s-1"},
        },
    }


def test_submit_protocol_task_success_with_shared_token():
    orchestrator = Orchestrator()

    task_id = asyncio.run(
        orchestrator.submit_protocol_task(
            raw_message=_sample_protocol_message(),
            shared_token="top-secret",
            priority=TaskPriority.NORMAL,
        )
    )

    assert task_id.startswith("task_")
    assert orchestrator.task_queue.qsize() == 1
    _, queued_task = orchestrator.task_queue.get_nowait()
    lineage = queued_task.inputs.get("_lineage")
    assert lineage is not None
    assert lineage["source"] == "protocol_ingress"
    assert lineage["source_message_id"] == "proto-corr-1"
    assert queued_task.inputs["source_protocol"] == "a2a"


def test_submit_protocol_task_rejects_invalid_auth():
    orchestrator = Orchestrator()

    with pytest.raises(ValueError, match="authentication failed"):
        asyncio.run(
            orchestrator.submit_protocol_task(
                raw_message=_sample_protocol_message(auth_token="wrong"),
                shared_token="top-secret",
                priority=TaskPriority.NORMAL,
            )
        )


def test_handle_task_result_sets_output_ref_in_lineage():
    orchestrator = Orchestrator()
    task = Task(
        task_id="task_123",
        task_type="analysis",
        description="Analyze",
        priority=TaskPriority.NORMAL,
        status=TaskStatus.RUNNING,
        started_at=datetime.now(UTC).replace(tzinfo=None),
        inputs={
            "session_id": "s-1",
            "_lineage": {
                "request_id": "req-1",
                "trace_id": "trace-1",
                "source": "task_api",
                "tool_invocation_ids": [],
                "memory_refs": [],
                "output_ref": None,
            },
        },
    )
    orchestrator.active_tasks[task.task_id] = task

    asyncio.run(
        orchestrator.handle_task_result(
            task.task_id,
            ExecutionResult(success=True, output={"answer": "ok"}),
        )
    )

    assert task.status == TaskStatus.COMPLETED
    assert task.inputs["_lineage"]["output_ref"] is not None


def test_handle_task_result_records_retry_count_in_lineage():
    orchestrator = Orchestrator()
    orchestrator.retry_delay_seconds = 0
    task = Task(
        task_id="task_456",
        task_type="analysis",
        description="Retry me",
        priority=TaskPriority.NORMAL,
        status=TaskStatus.RUNNING,
        started_at=datetime.now(UTC).replace(tzinfo=None),
        inputs={
            "session_id": "s-2",
            "_lineage": {
                "request_id": "req-2",
                "trace_id": "trace-2",
                "source": "task_api",
                "tool_invocation_ids": [],
                "memory_refs": [],
                "output_ref": None,
            },
        },
    )
    orchestrator.active_tasks[task.task_id] = task

    asyncio.run(
        orchestrator.handle_task_result(
            task.task_id,
            ExecutionResult(success=False, error="transient"),
        )
    )

    assert task.retry_count == 1
    assert task.inputs["_lineage"]["retry_count"] == 1


def test_search_tasks_by_trace_id_across_task_states():
    orchestrator = Orchestrator()

    active_task = Task(
        task_id="task_active",
        task_type="analysis",
        description="Active",
        priority=TaskPriority.NORMAL,
        status=TaskStatus.RUNNING,
        inputs={
            "_lineage": {
                "request_id": "req-1",
                "trace_id": "trace-shared",
                "source": "task_api",
                "tool_invocation_ids": [],
                "memory_refs": [],
            }
        },
    )
    completed_task = Task(
        task_id="task_completed",
        task_type="analysis",
        description="Completed",
        priority=TaskPriority.NORMAL,
        status=TaskStatus.COMPLETED,
        inputs={
            "_lineage": {
                "request_id": "req-2",
                "trace_id": "trace-shared",
                "source": "task_api",
                "tool_invocation_ids": [],
                "memory_refs": [],
            }
        },
    )
    failed_task = Task(
        task_id="task_failed",
        task_type="analysis",
        description="Failed",
        priority=TaskPriority.NORMAL,
        status=TaskStatus.FAILED,
        inputs={
            "_lineage": {
                "request_id": "req-3",
                "trace_id": "trace-other",
                "source": "task_api",
                "tool_invocation_ids": [],
                "memory_refs": [],
            }
        },
    )

    orchestrator.active_tasks[active_task.task_id] = active_task
    orchestrator.completed_tasks[completed_task.task_id] = completed_task
    orchestrator.failed_tasks[failed_task.task_id] = failed_task

    results = asyncio.run(orchestrator.search_tasks(trace_id="trace-shared"))

    assert [result["task_id"] for result in results] == ["task_active", "task_completed"]
    assert all(result["lineage"]["trace_id"] == "trace-shared" for result in results)


def test_search_tasks_by_request_id_returns_lineage_summary():
    orchestrator = Orchestrator()
    task = Task(
        task_id="task_789",
        task_type="analysis",
        description="Lookup me",
        priority=TaskPriority.NORMAL,
        status=TaskStatus.COMPLETED,
        inputs={
            "_lineage": {
                "request_id": "req-search",
                "trace_id": "trace-search",
                "source": "protocol_ingress",
                "source_message_id": "corr-1",
                "tool_invocation_ids": [],
                "memory_refs": [],
            }
        },
    )
    orchestrator.completed_tasks[task.task_id] = task

    results = asyncio.run(orchestrator.search_tasks(request_id="req-search"))

    assert len(results) == 1
    assert results[0]["task_id"] == "task_789"
    assert results[0]["trace_id"] == "trace-search"
    assert results[0]["lineage"]["source_message_id"] == "corr-1"


def test_get_task_status_falls_back_to_persisted_snapshot() -> None:
    with TemporaryDirectory() as temp_dir:
        repository = FileLineageRepository(Path(temp_dir) / "lineage")
        repository.persist_task_snapshot(
            task_id="task_persisted_status",
            status="completed",
            task_type="analysis",
            description="Persisted status",
            trace_id="trace-persisted-status",
            lineage={
                "request_id": "req-persisted-status",
                "trace_id": "trace-persisted-status",
                "source": "task_api",
                "tool_invocation_ids": ["tool-1"],
                "memory_refs": ["memory-1"],
                "output_ref": "output-1",
            },
            outputs={"response": "restored"},
            error=None,
        )
        orchestrator = Orchestrator(lineage_repository=repository)

        result = asyncio.run(orchestrator.get_task_status("task_persisted_status"))

        assert result is not None
        assert result["task_id"] == "task_persisted_status"
        assert result["status"] == "completed"
        assert result["outputs"]["response"] == "restored"
        assert result["lineage"]["request_id"] == "req-persisted-status"


def test_search_tasks_includes_latest_persisted_snapshot_when_memory_empty() -> None:
    with TemporaryDirectory() as temp_dir:
        repository = FileLineageRepository(Path(temp_dir) / "lineage")
        repository.persist_task_snapshot(
            task_id="task_persisted_search",
            status="running",
            task_type="analysis",
            description="Initial persisted snapshot",
            trace_id="trace-persisted-search",
            lineage={
                "request_id": "req-persisted-search",
                "trace_id": "trace-persisted-search",
                "source": "task_api",
                "tool_invocation_ids": [],
                "memory_refs": [],
            },
            outputs={},
            error=None,
        )
        repository.persist_task_snapshot(
            task_id="task_persisted_search",
            status="completed",
            task_type="analysis",
            description="Latest persisted snapshot",
            trace_id="trace-persisted-search",
            lineage={
                "request_id": "req-persisted-search",
                "trace_id": "trace-persisted-search",
                "source": "task_api",
                "tool_invocation_ids": ["tool-9"],
                "memory_refs": ["memory-9"],
                "output_ref": "output-9",
            },
            outputs={"response": "done"},
            error=None,
        )
        orchestrator = Orchestrator(lineage_repository=repository)

        results = asyncio.run(orchestrator.search_tasks(trace_id="trace-persisted-search"))

        assert len(results) == 1
        assert results[0]["task_id"] == "task_persisted_search"
        assert results[0]["status"] == "completed"
        assert results[0]["description"] == "Latest persisted snapshot"
        assert results[0]["lineage"]["output_ref"] == "output-9"


def test_persist_task_snapshot_failure_is_non_fatal(monkeypatch) -> None:
    orchestrator = Orchestrator()
    task = Task(
        task_id="task_non_fatal_persist",
        task_type="analysis",
        description="Persistence failure should not raise",
        priority=TaskPriority.NORMAL,
        inputs={"_lineage": {"request_id": "req-non-fatal", "trace_id": "trace-non-fatal"}},
    )

    def raise_on_persist(**kwargs):
        raise OSError("disk full")

    monkeypatch.setattr(orchestrator.lineage_repository, "persist_task_snapshot", raise_on_persist)

    # Should not raise even if repository persistence fails.
    orchestrator._persist_task_snapshot(task)
