"""
AI-OS API Server
FastAPI-based REST API with WebSocket support
Production-Grade API for AI Operating System
"""

import asyncio
import json
import logging
import os
import time
import uuid
from datetime import UTC, datetime
from typing import Any, cast

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from src.config.settings import config
from src.core.aios_bridge import AIOSBridge
from src.core.lineage import normalize_lineage

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

ORCHESTRATOR_UNAVAILABLE = "Orchestrator not available"
TASK_NOT_FOUND = "Task not found"

# =============================================================================
# REQUEST/RESPONSE MODELS
# =============================================================================


class ChatMessage(BaseModel):
    """Chat message format"""

    role: str = Field(..., description="Message role: user, assistant, system")
    content: str = Field(..., description="Message content")
    metadata: dict[str, Any] | None = Field(default_factory=dict)


class ChatRequest(BaseModel):
    """Chat completion request"""

    session_id: str | None = Field(None, description="Session ID for conversation continuity")
    messages: list[ChatMessage] = Field(..., description="Message history")
    model: str | None = Field("default", description="Model to use")
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    max_tokens: int | None = Field(4000, ge=1, le=128000)
    stream: bool = Field(False, description="Enable streaming response")
    tools: list[str] | None = Field(default_factory=list, description="Allowed tools")
    priority: str = Field("normal", description="Request priority")
    metadata: dict[str, Any] | None = Field(default_factory=dict)


class ChatResponse(BaseModel):
    """Chat completion response"""

    session_id: str
    message_id: str
    content: str
    model: str
    usage: dict[str, int] = Field(description="Token usage stats")
    finish_reason: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class TaskRequest(BaseModel):
    """Task execution request"""

    task_type: str = Field(..., description="Task type")
    description: str = Field(..., description="Task description")
    inputs: dict[str, Any] = Field(default_factory=dict)
    constraints: dict[str, Any] | None = Field(default_factory=dict)
    priority: str = Field("normal")
    deadline: datetime | None = None
    reasoning_override: str | None = Field(
        default=None,
        description="Optional override: normal, cautious, or defer",
    )


class TaskResponse(BaseModel):
    """Task execution response"""

    task_id: str
    status: str
    result: dict[str, Any] | None = None
    error: str | None = None
    execution_time_ms: int = 0
    reasoning_confidence: float | None = None
    reasoning_mode: str | None = None
    reasoning_deferred: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "task_id": "task_000123",
                    "status": "completed",
                    "result": {"response": "Completed lineage-aware task"},
                    "error": None,
                    "execution_time_ms": 142,
                    "reasoning_confidence": 0.94,
                    "reasoning_mode": "normal",
                    "reasoning_deferred": False,
                    "metadata": {
                        "trace_id": "trace-demo-001",
                        "lineage": {
                            "request_id": "req-demo-001",
                            "trace_id": "trace-demo-001",
                            "session_id": "session-demo-001",
                            "source": "task_api",
                            "source_message_id": "message-demo-001",
                            "tool_invocation_ids": ["tool-demo-001"],
                            "memory_refs": ["memory-demo-001"],
                            "output_ref": "f2ef3f1a0a5e9f0d6c5f18ca5d9457be8ef2c4fe2f16595f4df8d7d3b8f85b6b",
                            "retry_count": 0,
                        },
                    },
                }
            ]
        }
    }


class TaskSearchResponse(BaseModel):
    """Task search response payload."""

    count: int
    results: list[dict[str, Any]] = Field(default_factory=list)

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "count": 1,
                    "results": [
                        {
                            "task_id": "task_000123",
                            "status": "completed",
                            "task_type": "analysis",
                            "description": "Trace one lineage chain",
                            "trace_id": "trace-demo-001",
                            "lineage": {
                                "request_id": "req-demo-001",
                                "trace_id": "trace-demo-001",
                                "session_id": "session-demo-001",
                                "source": "chat_completion",
                                "source_message_id": "message-demo-001",
                                "tool_invocation_ids": ["tool-demo-001"],
                                "memory_refs": ["memory-demo-001"],
                                "output_ref": "f2ef3f1a0a5e9f0d6c5f18ca5d9457be8ef2c4fe2f16595f4df8d7d3b8f85b6b",
                                "retry_count": 0,
                            },
                        }
                    ],
                }
            ]
        }
    }


class ProtocolTaskRequest(BaseModel):
    """External protocol task ingress request."""

    message: dict[str, Any] = Field(..., description="Raw protocol envelope")
    priority: str = Field("normal", description="Task priority")
    shared_token: str | None = Field(
        default=None, description="Optional shared token for message auth"
    )


class AIOSTaskForwardRequest(BaseModel):
    """Task payload forwarded to AIOS bridge endpoint."""

    task_type: str = Field(..., description="Task type")
    description: str = Field(..., description="Task description")
    inputs: dict[str, Any] = Field(default_factory=dict)
    constraints: dict[str, Any] = Field(default_factory=dict)
    priority: str = Field("normal", description="Task priority")


class AgentMessageModel(BaseModel):
    """Agent communication message"""

    agent_id: str
    content: str | None = None
    task_id: str | None = None
    agent: str | None = None
    intent: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)
    inputs: dict[str, Any] = Field(default_factory=dict)
    memory_refs: list[str] = Field(default_factory=list)
    tools_allowed: list[str] = Field(default_factory=list)
    priority: int = 2
    deadline: datetime | None = None
    trace_id: str = Field(default_factory=lambda: str(uuid.uuid4()))


# =============================================================================
# API SERVER
# =============================================================================


class APIServer:
    """FastAPI-based API server with WebSocket support"""

    def __init__(
        self,
        orchestrator=None,
        tool_registry=None,
        memory_manager=None,
        aios_bridge: AIOSBridge | None = None,
    ):
        self.app = FastAPI(title="AI-OS API", version="1.0.0")
        self.orchestrator = orchestrator
        self.tool_registry = tool_registry
        self.memory_manager = memory_manager
        self.aios_bridge = aios_bridge

        if self.aios_bridge is None and config.aios_bridge.enabled:
            self.aios_bridge = AIOSBridge(
                base_url=config.aios_bridge.base_url,
                timeout_seconds=config.aios_bridge.timeout_seconds,
                health_path=config.aios_bridge.health_path,
                task_path=config.aios_bridge.task_path,
                api_key=config.aios_bridge.api_key,
            )

        # WebSocket connections
        self.active_connections: dict[str, list[WebSocket]] = {}

        # Request tracking
        self.request_counts: dict[str, int] = {}
        self.rate_limit_window = 60  # seconds
        self.task_wait_timeout_seconds = 30

        self._setup_middleware()
        self._setup_routes()

    def _setup_middleware(self):
        """Setup CORS and other middleware"""
        raw_origins = os.getenv("CORS_ALLOW_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000")
        allow_origins = [origin.strip() for origin in raw_origins.split(",") if origin.strip()]
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=allow_origins,
            allow_credentials=True,
            allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            allow_headers=["Authorization", "Content-Type", "X-Requested-With"],
        )

    @staticmethod
    def _parse_priority(priority: str) -> int:
        priority_map = {
            "critical": 0,
            "high": 1,
            "normal": 2,
            "low": 3,
        }
        normalized = priority.lower().strip()
        if normalized not in priority_map:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid priority '{priority}'. Must be one of: {sorted(priority_map.keys())}",
            )
        return priority_map[normalized]

    def _setup_routes(self):  # noqa: C901
        """Setup API routes"""

        @self.app.get("/health")
        async def health_check():
            return {
                "status": "healthy",
                "timestamp": datetime.now(UTC).isoformat(),
                "version": "1.0.0",
            }

        @self.app.get("/v1/reasoning/status")
        async def reasoning_status():
            return {
                "enabled": config.mythos.enabled,
                "cautious_threshold": config.mythos.cautious_threshold,
                "defer_threshold": config.mythos.defer_threshold,
                "kill_switch_active": not config.mythos.enabled,
            }

        @self.app.get("/v1/integrations/aios/health")
        async def aios_health():
            return await self._get_aios_health()

        @self.app.post("/v1/integrations/aios/tasks/forward")
        async def aios_forward_task(request: AIOSTaskForwardRequest):
            return await self._forward_task_to_aios(request)

        # Chat endpoints
        @self.app.post("/v1/chat", response_model=ChatResponse)
        async def chat(request: ChatRequest):
            return await self._handle_chat(request)

        @self.app.post("/v1/chat/completions", response_model=ChatResponse)
        async def chat_completions(request: ChatRequest):
            return await self._handle_chat(request)

        @self.app.websocket("/v1/ws/{session_id}")
        async def websocket_endpoint(websocket: WebSocket, session_id: str):
            await self._handle_websocket(websocket, session_id)

        # Task endpoints
        @self.app.post("/v1/tasks", response_model=TaskResponse)
        async def create_task(request: TaskRequest):
            return await self._handle_task(request)

        @self.app.post("/v1/protocol/tasks", response_model=TaskResponse)
        async def create_protocol_task(request: ProtocolTaskRequest):
            return await self._handle_protocol_task(request)

        @self.app.get(
            "/v1/tasks/search",
            response_model=TaskSearchResponse,
            responses={
                200: {
                    "description": "Tasks matched by lineage identifiers.",
                    "content": {
                        "application/json": {
                            "examples": {
                                "lineage_lookup": {
                                    "summary": "Lookup tasks by trace_id",
                                    "value": {
                                        "count": 1,
                                        "results": [
                                            {
                                                "task_id": "task_000123",
                                                "status": "completed",
                                                "task_type": "analysis",
                                                "description": "Trace one lineage chain",
                                                "trace_id": "trace-demo-001",
                                                "lineage": {
                                                    "request_id": "req-demo-001",
                                                    "trace_id": "trace-demo-001",
                                                    "session_id": "session-demo-001",
                                                    "source": "chat_completion",
                                                    "source_message_id": "message-demo-001",
                                                    "tool_invocation_ids": ["tool-demo-001"],
                                                    "memory_refs": ["memory-demo-001"],
                                                    "output_ref": "f2ef3f1a0a5e9f0d6c5f18ca5d9457be8ef2c4fe2f16595f4df8d7d3b8f85b6b",
                                                    "retry_count": 0,
                                                },
                                            }
                                        ],
                                    },
                                }
                            }
                        }
                    },
                }
            },
        )
        async def search_tasks(
            trace_id: str | None = None,
            request_id: str | None = None,
            source_message_id: str | None = None,
        ):
            return await self._search_tasks(
                trace_id=trace_id,
                request_id=request_id,
                source_message_id=source_message_id,
            )

        @self.app.get(
            "/v1/tasks/{task_id}",
            responses={
                404: {
                    "description": "Task not found",
                    "content": {
                        "application/json": {
                            "examples": {
                                "task_missing": {
                                    "summary": "Task lookup miss",
                                    "value": {"detail": TASK_NOT_FOUND},
                                }
                            }
                        }
                    },
                },
                503: {
                    "description": "Service unavailable",
                    "content": {
                        "application/json": {
                            "examples": {
                                "orchestrator_unavailable": {
                                    "summary": "Orchestrator unavailable",
                                    "value": {"detail": ORCHESTRATOR_UNAVAILABLE},
                                }
                            }
                        }
                    },
                },
            },
        )
        async def get_task(task_id: str):
            return await self._get_task_status(task_id)

        @self.app.delete(
            "/v1/tasks/{task_id}",
            responses={
                404: {
                    "description": "Task not found",
                    "content": {
                        "application/json": {
                            "examples": {
                                "task_missing": {
                                    "summary": "Task lookup miss",
                                    "value": {"detail": TASK_NOT_FOUND},
                                }
                            }
                        }
                    },
                },
                503: {
                    "description": "Service unavailable",
                    "content": {
                        "application/json": {
                            "examples": {
                                "orchestrator_unavailable": {
                                    "summary": "Orchestrator unavailable",
                                    "value": {"detail": ORCHESTRATOR_UNAVAILABLE},
                                }
                            }
                        }
                    },
                },
            },
        )
        async def cancel_task(task_id: str):
            return await self._cancel_task(task_id)

        # Agent endpoints
        @self.app.get(
            "/v1/agents",
            responses={
                503: {
                    "description": "Service unavailable",
                    "content": {
                        "application/json": {
                            "examples": {
                                "orchestrator_unavailable": {
                                    "summary": "Orchestrator unavailable",
                                    "value": {"detail": ORCHESTRATOR_UNAVAILABLE},
                                }
                            }
                        }
                    },
                }
            },
        )
        async def list_agents():
            return await self._list_agents()

        @self.app.post("/v1/agents/communicate")
        async def agent_communicate(message: AgentMessageModel):
            return await self._agent_communicate(message)

        # Tool endpoints
        @self.app.get(
            "/v1/tools",
            responses={
                503: {
                    "description": "Service unavailable",
                    "content": {
                        "application/json": {
                            "examples": {
                                "tool_registry_unavailable": {
                                    "summary": "Tool registry unavailable",
                                    "value": {"detail": "Tool registry not available"},
                                }
                            }
                        }
                    },
                }
            },
        )
        async def list_tools():
            return await self._list_tools()

        @self.app.post("/v1/tools/{tool_id}/execute")
        async def execute_tool(tool_id: str, params: dict[str, Any]):
            return await self._execute_tool(tool_id, params)

        # Memory endpoints
        @self.app.post("/v1/memory/store")
        async def store_memory(
            content: str, memory_type: str = "working", metadata: dict | None = None
        ):
            return await self._store_memory(content, memory_type, metadata or {})

        @self.app.post("/v1/memory/retrieve")
        async def retrieve_memory(query: str, session_id: str, top_k: int = 10):
            return await self._retrieve_memory(query, session_id, top_k)

        # Session endpoints
        @self.app.post("/v1/sessions")
        async def create_session(user_id: str):
            return await self._create_session(user_id)

        @self.app.get("/v1/sessions/{session_id}")
        async def get_session(session_id: str):
            return await self._get_session(session_id)

        # System status
        @self.app.get("/v1/status")
        async def get_status():
            return await self._get_system_status()

    async def _handle_chat(self, request: ChatRequest) -> ChatResponse:
        """Handle chat completion request"""
        try:
            if not self.orchestrator:
                raise HTTPException(status_code=503, detail=ORCHESTRATOR_UNAVAILABLE)
            # Get or create session
            session_id = request.session_id or str(uuid.uuid4())
            request_lineage = normalize_lineage(
                raw_lineage=request.metadata.get("_lineage") if request.metadata else None,
                session_id=session_id,
                source="chat_completion",
                input_payload={
                    "messages": [m.dict() for m in request.messages],
                    "metadata": request.metadata,
                },
            )

            if not request.messages:
                raise HTTPException(status_code=400, detail="Messages required")

            # Add to session memory
            if self.memory_manager:
                for msg in request.messages:
                    self.memory_manager.session_memory.add_message(
                        session_id, msg.role, msg.content
                    )

            # Build context from memory
            context: dict[str, Any] = {}
            if self.memory_manager:
                last_message = request.messages[-1].content
                memory_context = await self.memory_manager.retrieve(
                    query=last_message, session_id=session_id, top_k=5
                )
                context["memories"] = [
                    {"content": e.content, "importance": e.importance_score}
                    for e in memory_context.entries
                ]
                context["total_tokens"] = memory_context.total_tokens
            context["session_id"] = session_id

            # Generate response (simplified - would call actual model)
            response_content, response_lineage = await self._generate_response(
                messages=request.messages,
                context=context,
                temperature=request.temperature,
                request_lineage=request_lineage,
            )

            # Calculate token usage (simulated)
            prompt_tokens = sum(len(m.content.split()) for m in request.messages) * 2
            completion_tokens = len(response_content.split()) * 2
            usage = {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens,
            }

            return ChatResponse(
                session_id=session_id,
                message_id=str(uuid.uuid4()),
                content=response_content,
                model=request.model or "default",
                usage=usage,
                finish_reason="stop",
                metadata={
                    "temperature": request.temperature,
                    "tools_used": request.tools,
                    "lineage": response_lineage,
                },
            )

        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Chat completion error: {e}")
            raise HTTPException(status_code=500, detail=str(e)) from e

    async def _generate_response(
        self,
        messages: list[ChatMessage],
        context: dict,
        temperature: float,
        request_lineage: dict[str, Any],
    ) -> tuple[str, dict[str, Any]]:
        """Generate response using orchestrator"""
        if self.orchestrator:
            # Use orchestrator for generation
            last_message = messages[-1].content

            task_id = await self.orchestrator.submit_task(
                task_type="generation",
                description=f"Generate response for: {last_message[:100]}",
                inputs={
                    "messages": [m.dict() for m in messages],
                    "context": context,
                    "_lineage": normalize_lineage(
                        raw_lineage=request_lineage,
                        session_id=context.get("session_id"),
                        source="chat_completion",
                        input_payload={
                            "messages": [m.dict() for m in messages],
                            "context": context,
                        },
                    ),
                },
                constraints={"temperature": temperature, "tools_allowed": []},
            )

            # Wait for completion (simplified)
            await asyncio.sleep(0.5)
            result = await self.orchestrator.get_task_status(task_id)

            if result and result.get("status") == "completed":
                response_value = result.get("outputs", {}).get("response", "No response generated")
                return str(response_value), dict(result.get("lineage") or request_lineage)

        # Fallback response
        return (
            f"Generated response based on {len(messages)} messages. Context tokens: {context.get('total_tokens', 0)}",
            dict(request_lineage),
        )

    async def _handle_websocket(self, websocket: WebSocket, session_id: str):
        """Handle WebSocket connection"""
        await websocket.accept()

        if session_id not in self.active_connections:
            self.active_connections[session_id] = []
        self.active_connections[session_id].append(websocket)

        try:
            while True:
                # Receive message
                data = await websocket.receive_text()
                message = ChatMessage.parse_raw(data)

                # Process message
                response = await self._handle_chat(
                    ChatRequest(session_id=session_id, messages=[message], stream=False)
                )

                # Send response
                await websocket.send_json(response.dict())

        except WebSocketDisconnect:
            logger.info(f"WebSocket disconnected: {session_id}")
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
        finally:
            if session_id in self.active_connections:
                self.active_connections[session_id].remove(websocket)

    async def _handle_task(self, request: TaskRequest) -> TaskResponse:
        """Handle task execution request"""
        start_time = time.time()

        try:
            if not self.orchestrator:
                raise HTTPException(status_code=503, detail=ORCHESTRATOR_UNAVAILABLE)

            constraints = dict(request.constraints or {})
            task_inputs = dict(request.inputs)
            task_inputs["_lineage"] = normalize_lineage(
                raw_lineage=task_inputs.get("_lineage"),
                session_id=cast(str | None, task_inputs.get("session_id")),
                parent_task_id=cast(str | None, task_inputs.get("parent_task_id")),
                source="task_api",
                source_message_id=cast(str | None, task_inputs.get("source_message_id")),
                input_payload=task_inputs,
            )
            if request.reasoning_override:
                override = request.reasoning_override.lower().strip()
                valid_overrides = {"normal", "cautious", "defer"}
                if override not in valid_overrides:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Invalid reasoning_override. Must be one of: {sorted(valid_overrides)}",
                    )

                user_role = str(request.inputs.get("user_role", "")).lower().strip()
                if user_role not in {"admin", "system"}:
                    raise HTTPException(
                        status_code=403,
                        detail="Insufficient permissions to override reasoning mode",
                    )

                logger.warning(
                    "Reasoning override requested for task_type=%s override=%s role=%s",
                    request.task_type,
                    override,
                    user_role,
                )
                constraints["reasoning_override"] = override

            # Submit task
            task_id = await self.orchestrator.submit_task(
                task_type=request.task_type,
                description=request.description,
                inputs=task_inputs,
                constraints=constraints,
            )

            # Wait for completion (with timeout)
            timeout = self.task_wait_timeout_seconds
            elapsed = 0.0
            while elapsed < timeout:
                result = await self.orchestrator.get_task_status(task_id)
                terminal_response = self._build_terminal_task_response(task_id, start_time, result)
                if terminal_response is not None:
                    return terminal_response

                handoff_response = await self._try_deferred_aios_handoff(
                    task_id=task_id,
                    start_time=start_time,
                    task_result=result,
                    request=request,
                    task_inputs=task_inputs,
                    constraints=constraints,
                )
                if handoff_response is not None:
                    return handoff_response
                await asyncio.sleep(0.5)
                elapsed += 0.5

            execution_time = int((time.time() - start_time) * 1000)
            return TaskResponse(
                task_id=task_id,
                status="timeout",
                error="Task execution timeout",
                execution_time_ms=execution_time,
            )

        except Exception as e:
            return TaskResponse(task_id="", status="failed", error=str(e))

    def _build_terminal_task_response(
        self,
        task_id: str,
        start_time: float,
        result: dict[str, Any] | None,
    ) -> TaskResponse | None:
        """Build response when orchestrator task reaches terminal state."""
        if not result or result.get("status") not in ["completed", "failed"]:
            return None

        execution_time = int((time.time() - start_time) * 1000)
        return TaskResponse(
            task_id=task_id,
            status=result["status"],
            result=result.get("outputs"),
            error=result.get("error"),
            execution_time_ms=execution_time,
            reasoning_confidence=result.get("reasoning_confidence"),
            reasoning_mode=result.get("reasoning_mode"),
            reasoning_deferred=bool(result.get("reasoning_deferred", False)),
            metadata={
                "trace_id": result.get("trace_id"),
                "lineage": result.get("lineage"),
            },
        )

    async def _try_deferred_aios_handoff(
        self,
        *,
        task_id: str,
        start_time: float,
        task_result: dict[str, Any] | None,
        request: TaskRequest,
        task_inputs: dict[str, Any],
        constraints: dict[str, Any],
    ) -> TaskResponse | None:
        """Forward reasoning-deferred tasks to AIOS and sync local task state."""
        if not (
            task_result
            and task_result.get("status") == "waiting_input"
            and bool(task_result.get("reasoning_deferred", False))
            and self.aios_bridge is not None
        ):
            return None

        forward_payload = {
            "task_type": request.task_type,
            "description": request.description,
            "inputs": task_inputs,
            "constraints": constraints,
            "priority": request.priority,
        }

        try:
            json.dumps(forward_payload)
        except TypeError as serialization_error:
            execution_time = int((time.time() - start_time) * 1000)
            return TaskResponse(
                task_id=task_id,
                status="failed",
                error=f"AIOS handoff payload is not JSON-serializable: {serialization_error}",
                execution_time_ms=execution_time,
                reasoning_confidence=task_result.get("reasoning_confidence"),
                reasoning_mode=task_result.get("reasoning_mode"),
                reasoning_deferred=True,
                metadata={
                    "trace_id": task_result.get("trace_id"),
                    "lineage": task_result.get("lineage"),
                    "forwarded_to_aios": False,
                },
            )

        try:
            upstream_result = await self.aios_bridge.forward_task(forward_payload)
        except Exception as bridge_error:
            execution_time = int((time.time() - start_time) * 1000)
            return TaskResponse(
                task_id=task_id,
                status="failed",
                error=f"AIOS handoff failed: {bridge_error}",
                execution_time_ms=execution_time,
                reasoning_confidence=task_result.get("reasoning_confidence"),
                reasoning_mode=task_result.get("reasoning_mode"),
                reasoning_deferred=True,
                metadata={
                    "trace_id": task_result.get("trace_id"),
                    "lineage": task_result.get("lineage"),
                    "forwarded_to_aios": False,
                },
            )

        self._mark_local_task_forwarded(task_id, upstream_result)

        execution_time = int((time.time() - start_time) * 1000)
        return TaskResponse(
            task_id=task_id,
            status="forwarded",
            result=upstream_result,
            error=None,
            execution_time_ms=execution_time,
            reasoning_confidence=task_result.get("reasoning_confidence"),
            reasoning_mode=task_result.get("reasoning_mode"),
            reasoning_deferred=True,
            metadata={
                "trace_id": task_result.get("trace_id"),
                "lineage": task_result.get("lineage"),
                "forwarded_to_aios": True,
            },
        )

    def _mark_local_task_forwarded(self, task_id: str, upstream_result: dict[str, Any]) -> None:
        """Mark local deferred task as completed with forwarded metadata."""
        if not self.orchestrator:
            return

        local_task = self.orchestrator.active_tasks.get(task_id)
        if local_task is None:
            return

        try:
            from src.core.orchestrator import TaskStatus

            local_task.status = TaskStatus.COMPLETED
            local_task.completed_at = datetime.now(UTC).replace(tzinfo=None)
            local_task.outputs = {"forwarded": True, "upstream": upstream_result}

            self.orchestrator.completed_tasks[task_id] = local_task
            self.orchestrator.active_tasks.pop(task_id, None)

            if hasattr(self.orchestrator, "_update_memory"):
                self.orchestrator._update_memory(local_task, "task_forwarded")
            if hasattr(self.orchestrator, "_persist_task_snapshot"):
                self.orchestrator._persist_task_snapshot(local_task)
        except Exception as error:
            logger.warning("Failed to mark forwarded local task %s: %s", task_id, error)

    async def _handle_protocol_task(self, request: ProtocolTaskRequest) -> TaskResponse:
        """Handle protocol ingress task request."""
        start_time = time.time()

        try:
            if not self.orchestrator:
                raise HTTPException(status_code=503, detail=ORCHESTRATOR_UNAVAILABLE)

            priority_value = self._parse_priority(request.priority)

            from src.core.orchestrator import TaskPriority

            task_id = await self.orchestrator.submit_protocol_task(
                raw_message=request.message,
                shared_token=request.shared_token,
                priority=TaskPriority(priority_value),
            )

            timeout = self.task_wait_timeout_seconds
            elapsed = 0.0
            while elapsed < timeout:
                result = await self.orchestrator.get_task_status(task_id)
                if result and result.get("status") in ["completed", "failed"]:
                    execution_time = int((time.time() - start_time) * 1000)
                    return TaskResponse(
                        task_id=task_id,
                        status=result["status"],
                        result=result.get("outputs"),
                        error=result.get("error"),
                        execution_time_ms=execution_time,
                        reasoning_confidence=result.get("reasoning_confidence"),
                        reasoning_mode=result.get("reasoning_mode"),
                        reasoning_deferred=bool(result.get("reasoning_deferred", False)),
                        metadata={
                            "trace_id": result.get("trace_id"),
                            "lineage": result.get("lineage"),
                        },
                    )
                await asyncio.sleep(0.5)
                elapsed += 0.5

            return TaskResponse(task_id=task_id, status="timeout", error="Task execution timeout")

        except HTTPException:
            raise
        except ValueError as e:
            message = str(e)
            if "authentication failed" in message.lower():
                raise HTTPException(status_code=401, detail=message) from e
            raise HTTPException(status_code=400, detail=message) from e
        except Exception as e:
            logger.error("Protocol task submission failed: %s", e)
            raise HTTPException(status_code=500, detail="Internal server error") from e

    async def _get_task_status(self, task_id: str) -> dict[str, Any]:
        """Get task status"""
        if self.orchestrator:
            result = await self.orchestrator.get_task_status(task_id)
            if result is None:
                raise HTTPException(status_code=404, detail=TASK_NOT_FOUND)
            return cast(dict[str, Any], result)
        raise HTTPException(status_code=503, detail=ORCHESTRATOR_UNAVAILABLE)

    async def _search_tasks(
        self,
        *,
        trace_id: str | None,
        request_id: str | None,
        source_message_id: str | None = None,
    ) -> TaskSearchResponse:
        """Search tasks by lineage identifiers."""
        if not self.orchestrator:
            raise HTTPException(status_code=503, detail=ORCHESTRATOR_UNAVAILABLE)

        results = await self.orchestrator.search_tasks(
            trace_id=trace_id,
            request_id=request_id,
            source_message_id=source_message_id,
        )
        return TaskSearchResponse(count=len(results), results=results)

    async def _cancel_task(self, task_id: str) -> dict[str, Any]:
        """Cancel task"""
        await asyncio.sleep(0)
        if not self.orchestrator:
            raise HTTPException(status_code=503, detail=ORCHESTRATOR_UNAVAILABLE)

        task = self.orchestrator.active_tasks.pop(task_id, None)
        if task is None:
            existing_task = self.orchestrator.completed_tasks.get(
                task_id
            ) or self.orchestrator.failed_tasks.get(task_id)
            if existing_task is not None:
                return {"task_id": task_id, "status": existing_task.status.value}
            raise HTTPException(status_code=404, detail=TASK_NOT_FOUND)

        from src.core.orchestrator import TaskStatus

        task.status = TaskStatus.CANCELLED
        task.completed_at = datetime.now(UTC).replace(tzinfo=None)
        self.orchestrator.failed_tasks[task_id] = task
        self.orchestrator._update_memory(task, "task_cancelled")
        self.orchestrator._persist_task_snapshot(task)

        return {"task_id": task_id, "status": TaskStatus.CANCELLED.value}

    async def _list_agents(self) -> dict[str, Any]:
        """List all agents"""
        await asyncio.sleep(0)
        if self.orchestrator:
            return cast(dict[str, Any], self.orchestrator.get_system_status())
        raise HTTPException(status_code=503, detail=ORCHESTRATOR_UNAVAILABLE)

    async def _agent_communicate(self, message: AgentMessageModel) -> dict:
        """Send message to agent"""
        await asyncio.sleep(0)
        if not message.content or not message.content.strip():
            raise HTTPException(status_code=400, detail="Message content required")
        return {"success": True, "message_id": str(uuid.uuid4()), "trace_id": message.trace_id}

    async def _list_tools(self) -> dict[str, Any]:
        """List available tools"""
        await asyncio.sleep(0)
        if self.tool_registry:
            return cast(dict[str, Any], self.tool_registry.get_metrics())
        raise HTTPException(status_code=503, detail="Tool registry not available")

    async def _execute_tool(self, tool_id: str, params: dict[str, Any]) -> dict[str, Any]:
        """Execute a tool"""
        if not self.tool_registry:
            raise HTTPException(status_code=503, detail="Tool registry not available")

        result = await self.tool_registry.execute_tool(
            tool_id=tool_id,
            params=params,
            execution_context={
                "user_role": "standard",
                "user_tier": "standard",
                "_lineage": normalize_lineage(
                    raw_lineage=params.get("_lineage") if isinstance(params, dict) else None,
                    session_id=params.get("session_id") if isinstance(params, dict) else None,
                    source="tool_api",
                    input_payload=params,
                ),
            },
        )

        if result is None:
            raise HTTPException(status_code=404, detail="Tool not found")

        return {
            "invocation_id": result.invocation_id,
            "success": result.status == "completed",
            "result": result.result,
            "error": result.error,
            "execution_time_ms": result.execution_time_ms,
            "lineage": result.lineage,
        }

    async def _store_memory(self, content: str, memory_type: str, metadata: dict) -> dict[str, Any]:
        """Store memory"""
        if not self.memory_manager:
            raise HTTPException(status_code=503, detail="Memory system not available")

        memory_id = await self.memory_manager.store(
            content=content, memory_type=memory_type, metadata=metadata
        )

        return {"memory_id": memory_id, "success": True}

    async def _retrieve_memory(self, query: str, session_id: str, top_k: int) -> dict[str, Any]:
        """Retrieve memory"""
        if not self.memory_manager:
            raise HTTPException(status_code=503, detail="Memory system not available")

        context = await self.memory_manager.retrieve(
            query=query, session_id=session_id, top_k=top_k
        )

        return {
            "entries": [
                {"memory_id": e.memory_id, "content": e.content, "importance": e.importance_score}
                for e in context.entries
            ],
            "total_tokens": context.total_tokens,
            "coverage_percentage": context.coverage_percentage,
        }

    async def _create_session(self, user_id: str) -> dict[str, Any]:
        """Create new session"""
        await asyncio.sleep(0)
        session_id = str(uuid.uuid4())
        if self.memory_manager:
            self.memory_manager.create_session(session_id, user_id)
            return {"session_id": session_id, "created": True}
        return {"session_id": session_id, "created": True}

    async def _get_session(self, session_id: str) -> dict[str, Any]:
        """Get session details"""
        await asyncio.sleep(0)
        if self.memory_manager:
            session = self.memory_manager.get_session(session_id)
            if session:
                return {
                    "session_id": session_id,
                    "user_id": session["user_id"],
                    "message_count": len(session["messages"]),
                    "last_activity": session["last_activity"].isoformat(),
                }
        raise HTTPException(status_code=404, detail="Session not found")

    async def _get_system_status(self) -> dict[str, Any]:
        """Get system status"""
        await asyncio.sleep(0)
        status: dict[str, Any] = {
            "api_status": "healthy",
            "timestamp": datetime.now(UTC).isoformat(),
        }

        if self.orchestrator:
            status["orchestrator"] = self.orchestrator.get_system_status()

        if self.tool_registry:
            status["tools"] = self.tool_registry.get_metrics()

        if self.memory_manager:
            status["memory"] = {
                "initialized": True,
                "sessions": len(self.memory_manager.session_memory.sessions),
            }

        status["aios_bridge"] = {
            "configured": self.aios_bridge is not None,
            "enabled": config.aios_bridge.enabled,
            "base_url": config.aios_bridge.base_url if config.aios_bridge.enabled else None,
        }

        return status

    async def _get_aios_health(self) -> dict[str, Any]:
        """Proxy health check to configured AIOS bridge target."""
        if not self.aios_bridge:
            raise HTTPException(status_code=503, detail="AIOS bridge not configured")
        try:
            payload = await self.aios_bridge.health()
        except Exception as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        return {"bridge": "aios", "ok": True, "upstream": payload}

    async def _forward_task_to_aios(self, request: AIOSTaskForwardRequest) -> dict[str, Any]:
        """Forward a task request to AIOS through the configured bridge."""
        if not self.aios_bridge:
            raise HTTPException(status_code=503, detail="AIOS bridge not configured")

        payload = {
            "task_type": request.task_type,
            "description": request.description,
            "inputs": dict(request.inputs),
            "constraints": dict(request.constraints),
            "priority": request.priority,
        }

        try:
            upstream = await self.aios_bridge.forward_task(payload)
        except Exception as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc

        return {"bridge": "aios", "forwarded": True, "upstream": upstream}


# =============================================================================
# LIFECYCLE MANAGEMENT
# =============================================================================


def create_app(
    orchestrator=None,
    tool_registry=None,
    memory_manager=None,
    aios_bridge: AIOSBridge | None = None,
) -> FastAPI:
    """Create and configure FastAPI application"""
    server = APIServer(orchestrator, tool_registry, memory_manager, aios_bridge)
    return server.app


# =============================================================================
# MAIN TEST
# =============================================================================


async def main():
    """Test API server"""
    from src.core.orchestrator import Orchestrator
    from src.memory.vector_store import MemoryManager
    from src.tools.tool_registry import create_tool_registry

    # Initialize components
    orchestrator = Orchestrator()
    await orchestrator.initialize()

    tool_registry = create_tool_registry()
    memory_manager = MemoryManager()
    await memory_manager.initialize()

    # Create app
    create_app(orchestrator, tool_registry, memory_manager)

    print("AI-OS API Server created")
    print("Endpoints available at /docs")


if __name__ == "__main__":
    asyncio.run(main())
