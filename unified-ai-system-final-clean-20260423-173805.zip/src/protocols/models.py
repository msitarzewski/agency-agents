from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class ProtocolMessageType(StrEnum):
    REQUEST = "request"
    RESPONSE = "response"
    EVENT = "event"
    ERROR = "error"


class AgentActionType(StrEnum):
    THINK = "think"
    TOOL = "tool"
    DELEGATE = "delegate"
    COMPLETE = "complete"


@dataclass(frozen=True)
class AgentIdentity:
    agent_id: str
    role: str
    tenant_id: str | None = None


@dataclass(frozen=True)
class CapabilityScope:
    allowed_actions: list[AgentActionType] = field(default_factory=list)
    allowed_tools: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class ProtocolEnvelope:
    protocol: str
    version: str
    message_type: ProtocolMessageType
    correlation_id: str
    source: AgentIdentity
    target: AgentIdentity | None
    action: AgentActionType
    payload: dict[str, Any]
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class NormalizedTask:
    task_id: str
    title: str
    objective: str
    constraints: dict[str, Any]
    context: dict[str, Any]
    source_protocol: str
    source_message_id: str
