"""Persistent repository layer for runtime lineage snapshots."""

from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from datetime import UTC, datetime
from pathlib import Path
from threading import Lock
from typing import Any


class FileLineageRepository:
    """Append-only JSONL repository for task and tool lineage snapshots."""

    def __init__(self, base_path: str | Path):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        self._task_file = self.base_path / "tasks.jsonl"
        self._tool_file = self.base_path / "tool_invocations.jsonl"
        self._lock = Lock()

    @staticmethod
    def _serialize(value: Any) -> Any:
        if is_dataclass(value) and not isinstance(value, type):
            dataclass_value: Any = value
            return {
                key: FileLineageRepository._serialize(item)
                for key, item in asdict(dataclass_value).items()
            }
        if isinstance(value, dict):
            return {key: FileLineageRepository._serialize(item) for key, item in value.items()}
        if isinstance(value, list):
            return [FileLineageRepository._serialize(item) for item in value]
        if isinstance(value, tuple):
            return [FileLineageRepository._serialize(item) for item in value]
        if hasattr(value, "value"):
            return value.value
        if isinstance(value, datetime):
            return value.isoformat()
        return value

    def _append(self, file_path: Path, payload: dict[str, Any]) -> None:
        record = dict(payload)
        record.setdefault("persisted_at", datetime.now(UTC).isoformat())
        with self._lock:
            with file_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, sort_keys=True, default=str))
                handle.write("\n")

    def persist_task_snapshot(
        self,
        *,
        task_id: str,
        status: str,
        task_type: str,
        description: str,
        trace_id: str,
        lineage: dict[str, Any],
        outputs: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        self._append(
            self._task_file,
            {
                "task_id": task_id,
                "status": status,
                "task_type": task_type,
                "description": description,
                "trace_id": trace_id,
                "lineage": self._serialize(lineage),
                "outputs": self._serialize(outputs or {}),
                "error": error,
            },
        )

    def persist_tool_invocation(self, invocation: Any) -> None:
        self._append(self._tool_file, self._serialize(invocation))

    def read_task_snapshots(self) -> list[dict[str, Any]]:
        if not self._task_file.exists():
            return []
        with self._lock:
            lines = self._task_file.read_text(encoding="utf-8").splitlines()
        return [json.loads(line) for line in lines if line.strip()]

    def get_latest_task_snapshot(self, task_id: str) -> dict[str, Any] | None:
        snapshots = self.read_task_snapshots()
        for snapshot in reversed(snapshots):
            if snapshot.get("task_id") == task_id:
                return snapshot
        return None

    def search_latest_task_snapshots(
        self,
        *,
        trace_id: str | None = None,
        request_id: str | None = None,
        source_message_id: str | None = None,
    ) -> list[dict[str, Any]]:
        latest_by_task_id: dict[str, dict[str, Any]] = {}
        for snapshot in self.read_task_snapshots():
            task_id = snapshot.get("task_id")
            if not task_id:
                continue
            latest_by_task_id[task_id] = snapshot

        results: list[dict[str, Any]] = []
        for snapshot in latest_by_task_id.values():
            lineage = snapshot.get("lineage") or {}
            if trace_id and lineage.get("trace_id") != trace_id:
                continue
            if request_id and lineage.get("request_id") != request_id:
                continue
            if source_message_id and lineage.get("source_message_id") != source_message_id:
                continue
            results.append(snapshot)

        return results

    def read_tool_invocations(self) -> list[dict[str, Any]]:
        if not self._tool_file.exists():
            return []
        with self._lock:
            lines = self._tool_file.read_text(encoding="utf-8").splitlines()
        return [json.loads(line) for line in lines if line.strip()]
