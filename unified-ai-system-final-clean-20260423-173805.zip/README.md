# AI-OS - Unified AI Operating System

Enterprise-grade AI orchestration platform that unifies multimodal and autonomous AI capabilities with production-ready implementation.

## Features

### Core Architecture

- **Modular Microservices**: Scalable, independent services
- **Unified Orchestration**: Central task coordination with priority queues
- **Real-time Synchronization**: Event-driven architecture

### Cognitive Engine

- **Hybrid Reasoning**: Symbolic + deep learning integration
- **Multi-step Planning**: Hierarchical task decomposition
- **Self-reflection**: Iterative improvement loops

### Multi-Agent Framework

- **Strategic Agents**: High-level planning and coordination
- **Tactical Agents**: Task allocation and optimization
- **Execution Agents**: Direct task execution and tool usage

### Memory System

- **Working Memory**: Session-scoped short-term storage
- **Semantic Memory**: Vector-based long-term storage with ANN indexing
- **Episodic Memory**: Experience and event tracking
- **Procedural Memory**: Learned skills and procedures

### Knowledge System

- **RAG Pipeline**: Retrieval-augmented generation with re-ranking
- **Knowledge Graphs**: Entity relationships with Neo4j
- **Vector Search**: Semantic similarity matching with FAISS

### Security & Control

- **RBAC**: Role-based access control
- **Human-in-the-loop**: Approval workflows
- **Audit Trails**: Complete logging
- **Sandboxed Execution**: Secure code execution with vulnerability scanning

## Quick Start

### Prerequisites

- Python 3.11+
- Docker & Docker Compose (for containerized deployment)
- PostgreSQL 16+ (for persistence)
- Redis 7+ (for caching)

### Installation

```bash
# Clone the repository
git clone https://github.com/aios/unified-ai-system.git
cd unified-ai-system

# Install dependencies
pip install -r requirements.txt

# Or use Poetry
poetry install
```

### Local Development

```bash
# Start all services
docker-compose up -d

# Run API server
uvicorn src.api.server:app --host 0.0.0.0 --port 8000 --reload

# Run worker
python -m src.workers.task_worker
```

### Production Deployment

```bash
# Build Docker images
docker build -t aios/api:latest -f Dockerfile --target production .

# Deploy to Kubernetes
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/
```

## Project Structure

```text
unified-ai-system/
├── src/                          # Source code
│   ├── __init__.py              # Package init
│   ├── api/
│   │   ├── __init__.py
│   │   └── server.py            # FastAPI server with REST + WebSocket
│   ├── config/
│   │   ├── __init__.py
│   │   └── settings.py          # System, model, agent configs
│   ├── core/
│   │   ├── __init__.py
│   │   ├── orchestrator.py      # Task orchestration & agents
│   │   ├── model_router.py       # Model selection & routing
│   │   └── execution_engine.py  # Sandboxed code execution
│   ├── memory/
│   │   ├── __init__.py
│   │   └── vector_store.py      # Multi-tier memory system
│   └── tools/
│       ├── __init__.py
│       └── tool_registry.py      # Tool registry & execution
├── k8s/                          # Kubernetes manifests
│   ├── namespace.yaml            # Deployment, services, HPA
│   ├── ingress-nginx.yaml       # NGINX reverse proxy
│   ├── prometheus.yml           # Prometheus config
│   └── grafana-datasources.yml # Grafana datasources
├── scripts/                      # Deployment scripts
│   ├── deploy.sh                # Deployment automation
│   ├── health_check.sh          # Health checks
│   └── init-db.sql              # Database initialization
├── dashboard/                    # Monitoring dashboard
│   └── index.html               # Real-time dashboard
├── docs/                         # Documentation
│   ├── ARCHITECTURE.md          # Architecture overview
│   └── DATABASE_SCHEMA.md       # Database schema
├── tests/                        # Unit tests
├── docker-compose.yml           # Local development
├── Dockerfile                   # Multi-stage build
├── pyproject.toml              # Poetry config
├── requirements.txt             # pip dependencies
└── README.md
```

## API Documentation

### Chat Completions

```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "messages": [
      {"role": "user", "content": "Hello, how can you help me?"}
    ],
    "model": "gpt-4-turbo",
    "temperature": 0.7
  }'
```

### Task Submission

```bash
curl -X POST http://localhost:8000/v1/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "task_type": "research",
    "description": "Research AI trends",
    "priority": "normal"
  }'
```

### WebSocket Chat

```javascript
const ws = new WebSocket('ws://localhost:8000/v1/ws/session-123');
ws.onmessage = (event) => {
    console.log(JSON.parse(event.data));
};
ws.send(JSON.stringify({role: 'user', content: 'Hello!'}));
```

## Architecture

```text
┌─────────────────────────────────────────────────────────────┐
│                         Client Layer                        │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     API Gateway                             │
│  (FastAPI + WebSocket + Rate Limiting + Auth)               │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   Orchestration Layer                       │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ Planner  │  │ Executor │  │  Critic  │  │Researcher│   │
│  │  Agent   │  │  Agent   │  │  Agent   │  │  Agent   │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
└─────────────────────────────────────────────────────────────┘
                              │
          ┌───────────────────┼───────────────────┐
          ▼                   ▼                   ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│   Tool System   │ │  Memory System  │ │ Knowledge RAG   │
│                 │ │                 │ │                 │
│  - Web Search   │ │  - Working      │ │  - Documents    │
│  - Code Exec    │ │  - Semantic     │ │  - Vector Store │
│  - File I/O     │ │  - Episodic     │ │  - Knowledge Gr │
│  - API Calls    │ │  - Procedural   │ │  - Retrieval    │
└─────────────────┘ └─────────────────┘ └─────────────────┘
          │                   │                   │
          └───────────────────┼───────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Model Router                              │
│  (GPT-4, Claude, Gemini, Local Models)                       │
└─────────────────────────────────────────────────────────────┘
```

## Configuration

### Environment Variables

| Variable | Description | Default |
| -------- | ----------- | ------- |
| `ENVIRONMENT` | Runtime environment | `development` |
| `DATABASE_URL` | PostgreSQL connection | - |
| `REDIS_URL` | Redis connection | - |
| `JWT_SECRET` | JWT signing secret | - |
| `LOG_LEVEL` | Logging level | `INFO` |

### Model Configuration

Models are configured in `src/config/settings.py`:

```python
ModelConfig(
    model_id="gpt-4-turbo",
    provider="openai",
    max_tokens=128000,
    temperature_default=0.7,
    capabilities=["reasoning", "generation", "code", "analysis"]
)
```

## Monitoring

### Prometheus Metrics

- `aios_tasks_total`: Total tasks processed
- `aios_tasks_duration_seconds`: Task execution duration
- `aios_api_requests_total`: API request count
- `aios_model_usage_tokens`: Token usage by model

### Dashboards

- Grafana: `http://localhost:3000`
- Prometheus: `http://localhost:9090`
- Jaeger Tracing: `http://localhost:16686`

## Development

### Running Tests

```powershell
# Run unified-ai-system tests
python -m pytest -q --disable-warnings

# Run full cross-repo validation (unified-ai-system + aios)
./scripts/full_project_check.ps1
```

## Continuous Improvement

- Full 100-step engineering roadmap: `docs/IMPROVEMENT_PLAN_100_STEPS.md`
- Cross-repo validation script: `scripts/full_project_check.ps1`
- BCI and neurotech integration notes: `docs/BCI_NEUROTECH_INTEGRATION.md`
- MNE preprocessing example: `examples/mne_bci_preprocessing_example.py`
- Information lineage contract: `docs/INFORMATION_LINEAGE_CONTRACT.md`

```bash
pytest tests/ -v --cov=src
```

### Code Style

```bash
black src/
isort src/
ruff check src/
```

## Deployment Scripts

```bash
# Local development deployment
./scripts/deploy.sh -t local

# Docker Compose deployment
./scripts/deploy.sh -t docker

# Kubernetes deployment
./scripts/deploy.sh -t kubernetes -n production

# Health check
./scripts/health_check.sh
```

## License

MIT License - See LICENSE file for details

## Contributing

Contributions welcome! Please read our contributing guidelines before submitting PRs.

---

**Author**: MiniMax Agent
**Version**: 1.0.0
