# Database Schema

-- =============================================================================
-- UNIFIED AI OPERATING SYSTEM - DATABASE SCHEMAS
-- Production-Grade PostgreSQL + Vector Extensions
-- Version: 1.0.0
-- =============================================================================

-- =============================================================================
-- SECTION 1: CORE USER & SESSION MANAGEMENT
-- =============================================================================

-- Users table - primary identity store
CREATE TABLE users (
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    avatar_url TEXT,
    user_type VARCHAR(50) DEFAULT 'standard' CHECK (user_type IN ('standard', 'premium', 'enterprise', 'admin')),
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended', 'deleted')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_login_at TIMESTAMP WITH TIME ZONE,
    mfa_enabled BOOLEAN DEFAULT false,
    mfa_secret VARCHAR(255),
    preferences JSONB DEFAULT '{}',
    metadata JSONB DEFAULT '{}',
    -- Indexes
    CONSTRAINT email_format CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_type ON users(user_type);

-- User profiles - extended user information
CREATE TABLE user_profiles (
    profile_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    bio TEXT,
    organization VARCHAR(255),
    job_title VARCHAR(100),
    department VARCHAR(100),
    timezone VARCHAR(50) DEFAULT 'UTC',
    language_preference VARCHAR(10) DEFAULT 'en',
    communication_style VARCHAR(50) DEFAULT 'professional',
    expertise_domains TEXT[], -- Array of expertise areas
    years_experience INTEGER,
    education JSONB DEFAULT '[]',
    certifications JSONB DEFAULT '[]',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);

-- =============================================================================
-- SECTION 2: SESSION MANAGEMENT
-- =============================================================================

-- Sessions table - conversation sessions
CREATE TABLE sessions (
    session_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    session_type VARCHAR(50) DEFAULT 'chat' CHECK (session_type IN ('chat', 'task', 'workflow', 'analysis')),
    title VARCHAR(255),
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'archived', 'deleted')),
    context_window INTEGER DEFAULT 128000,
    priority VARCHAR(20) DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'critical')),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_activity_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    ended_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_status ON sessions(status);
CREATE INDEX idx_sessions_created ON sessions(created_at DESC);

-- Session messages - conversation history
CREATE TABLE session_messages (
    message_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    message_type VARCHAR(30) CHECK (message_type IN ('user', 'assistant', 'system', 'tool', 'function')),
    content TEXT NOT NULL,
    content_type VARCHAR(50) DEFAULT 'text' CHECK (content_type IN ('text', 'markdown', 'json', 'code', 'html')),
    modality VARCHAR(20) DEFAULT 'text' CHECK (modality IN ('text', 'image', 'audio', 'video', 'code', 'mixed')),
    metadata JSONB DEFAULT '{}',
    attachments JSONB DEFAULT '[]',
    references JSONB DEFAULT '[]', -- Citations and references
    parent_message_id UUID REFERENCES session_messages(message_id),
    depth INTEGER DEFAULT 0,
    token_count INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    edited_at TIMESTAMP WITH TIME ZONE,
    version INTEGER DEFAULT 1
);

CREATE INDEX idx_messages_session_id ON session_messages(session_id);
CREATE INDEX idx_messages_created ON session_messages(created_at);
CREATE INDEX idx_messages_type ON session_messages(message_type);

-- Message attachments
CREATE TABLE message_attachments (
    attachment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID NOT NULL REFERENCES session_messages(message_id) ON DELETE CASCADE,
    file_name VARCHAR(255) NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    file_size BIGINT,
    file_url TEXT,
    storage_path TEXT,
    mime_type VARCHAR(100),
    metadata JSONB DEFAULT '{}',
    scan_status VARCHAR(20) DEFAULT 'pending',
    scan_result JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_attachments_message_id ON message_attachments(message_id);

-- =============================================================================
-- SECTION 3: TASK & WORKFLOW MANAGEMENT
-- =============================================================================

-- Tasks table - individual task execution
CREATE TABLE tasks (
    task_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES sessions(session_id) ON DELETE SET NULL,
    task_type VARCHAR(50) NOT NULL,
    task_name VARCHAR(255),
    description TEXT,
    priority INTEGER DEFAULT 2 CHECK (priority BETWEEN 0 AND 3), -- 0=critical, 1=high, 2=normal, 3=low
    status VARCHAR(30) DEFAULT 'pending' CHECK (status IN (
        'pending', 'queued', 'planning', 'in_progress', 'waiting',
        'completed', 'failed', 'cancelled', 'paused'
    )),
    assigned_agent VARCHAR(100),
    created_by VARCHAR(100),
    input_data JSONB NOT NULL DEFAULT '{}',
    output_data JSONB DEFAULT '{}',
    lineage JSONB NOT NULL DEFAULT '{}', -- request/task/tool/output linkage contract
    trace_id UUID,
    source_message_id UUID REFERENCES session_messages(message_id) ON DELETE SET NULL,
    input_hash VARCHAR(64),
    output_ref TEXT,
    constraints JSONB DEFAULT '{}',
    dependencies UUID[] DEFAULT '{}',
    subtasks UUID[] DEFAULT '{}',
    parent_task_id UUID REFERENCES tasks(task_id),
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    error_message TEXT,
    error_trace TEXT,
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    estimated_duration INTEGER, -- seconds
    actual_duration INTEGER, -- seconds
    progress_percentage INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_tasks_session_id ON tasks(session_id);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_type ON tasks(task_type);
CREATE INDEX idx_tasks_assigned ON tasks(assigned_agent);
CREATE INDEX idx_tasks_priority ON tasks(priority);
CREATE INDEX idx_tasks_created ON tasks(created_at DESC);
CREATE INDEX idx_tasks_trace_id ON tasks(trace_id);
CREATE INDEX idx_tasks_source_message_id ON tasks(source_message_id);

-- Task execution logs
CREATE TABLE task_execution_logs (
    log_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID NOT NULL REFERENCES tasks(task_id) ON DELETE CASCADE,
    step_number INTEGER NOT NULL,
    step_name VARCHAR(100),
    step_status VARCHAR(30),
    agent_id VARCHAR(100),
    action_taken TEXT,
    input_summary JSONB,
    output_summary JSONB,
    lineage JSONB NOT NULL DEFAULT '{}',
    tool_invocation_id UUID,
    output_ref TEXT,
    duration_ms INTEGER,
    token_usage JSONB DEFAULT '{}',
    memory_used INTEGER,
    error_details TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_task_logs_task_id ON task_execution_logs(task_id);
CREATE INDEX idx_task_logs_created ON task_execution_logs(created_at);
CREATE INDEX idx_task_logs_tool_invocation_id ON task_execution_logs(tool_invocation_id);

-- Task graphs - workflow definitions
CREATE TABLE task_graphs (
    graph_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    graph_name VARCHAR(255) NOT NULL,
    graph_type VARCHAR(50) DEFAULT 'workflow',
    definition JSONB NOT NULL, -- DAG structure
    version INTEGER DEFAULT 1,
    status VARCHAR(20) DEFAULT 'draft',
    owner_user_id UUID REFERENCES users(user_id),
    variables JSONB DEFAULT '{}',
    constraints JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    published_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_task_graphs_name ON task_graphs(graph_name);
CREATE INDEX idx_task_graphs_type ON task_graphs(graph_type);
CREATE INDEX idx_task_graphs_status ON task_graphs(status);

-- =============================================================================
-- SECTION 4: AGENT SYSTEM
-- =============================================================================

-- Agents registry
CREATE TABLE agents (
    agent_id VARCHAR(100) PRIMARY KEY,
    agent_name VARCHAR(255) NOT NULL,
    agent_type VARCHAR(50) NOT NULL,
    description TEXT,
    capabilities TEXT[] NOT NULL,
    allowed_tools VARCHAR(100)[] DEFAULT '{}',
    memory_scope VARCHAR(50) DEFAULT 'session',
    max_concurrent_tasks INTEGER DEFAULT 5,
    timeout_seconds INTEGER DEFAULT 300,
    priority_level INTEGER DEFAULT 2,
    status VARCHAR(20) DEFAULT 'active',
    config JSONB DEFAULT '{}',
    system_prompt TEXT,
    metadata JSONB DEFAULT '{}',
    version VARCHAR(20) DEFAULT '1.0.0',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_agents_type ON agents(agent_type);
CREATE INDEX idx_agents_status ON agents(status);

-- Agent specializations
CREATE TABLE agent_specializations (
    spec_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id VARCHAR(100) NOT NULL REFERENCES agents(agent_id) ON DELETE CASCADE,
    domain VARCHAR(100) NOT NULL,
    skill_level INTEGER DEFAULT 1 CHECK (skill_level BETWEEN 1 AND 5),
    model_preference VARCHAR(100),
    tools_enabled VARCHAR(100)[] DEFAULT '{}',
    performance_metrics JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_agent_specs_agent_id ON agent_specializations(agent_id);
CREATE INDEX idx_agent_specs_domain ON agent_specializations(domain);

-- Agent communication logs
CREATE TABLE agent_communications (
    comm_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sender_agent VARCHAR(100) NOT NULL,
    recipient_agents VARCHAR(100)[] NOT NULL,
    communication_type VARCHAR(30) CHECK (communication_type IN (
        'task_dispatch', 'task_result', 'coordination_sync',
        'heartbeat', 'escalation', 'resolution'
    )),
    message_content JSONB NOT NULL,
    correlation_id UUID,
    reply_to_message_id UUID,
    delivery_status VARCHAR(20) DEFAULT 'pending',
    delivery_attempts INTEGER DEFAULT 0,
    delivered_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_agent_comm_sender ON agent_communications(sender_agent);
CREATE INDEX idx_agent_comm_type ON agent_communications(communication_type);
CREATE INDEX idx_agent_comm_created ON agent_communications(created_at);

-- Agent performance metrics
CREATE TABLE agent_metrics (
    metric_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id VARCHAR(100) NOT NULL REFERENCES agents(agent_id) ON DELETE CASCADE,
    metric_type VARCHAR(50) NOT NULL,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(10, 4) NOT NULL,
    unit VARCHAR(20),
    sample_size INTEGER DEFAULT 1,
    percentile_50 DECIMAL(10, 4),
    percentile_95 DECIMAL(10, 4),
    percentile_99 DECIMAL(10, 4),
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'
);

CREATE INDEX idx_agent_metrics_agent ON agent_metrics(agent_id);
CREATE INDEX idx_agent_metrics_type ON agent_metrics(metric_type);
CREATE INDEX idx_agent_metrics_recorded ON agent_metrics(recorded_at DESC);

-- =============================================================================
-- SECTION 5: TOOL SYSTEM
-- =============================================================================

-- Tools registry
CREATE TABLE tools (
    tool_id VARCHAR(100) PRIMARY KEY,
    tool_name VARCHAR(255) NOT NULL,
    tool_category VARCHAR(50) NOT NULL,
    description TEXT,
    version VARCHAR(20) DEFAULT '1.0.0',
    input_schema JSONB NOT NULL, -- JSON Schema for input validation
    output_schema JSONB NOT NULL, -- JSON Schema for output validation
    permissions_required VARCHAR(50)[] DEFAULT '{}',
    rate_limit_rpm INTEGER DEFAULT 100,
    timeout_seconds INTEGER DEFAULT 60,
    cost_per_invocation DECIMAL(10, 6) DEFAULT 0,
    status VARCHAR(20) DEFAULT 'active',
    implementation_type VARCHAR(30) CHECK (implementation_type IN (
        'function', 'api', 'script', 'docker', 'external'
    )),
    implementation_url TEXT,
    security_level VARCHAR(20) DEFAULT 'standard',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_tools_category ON tools(tool_category);
CREATE INDEX idx_tools_status ON tools(status);

-- Tool invocations log
CREATE TABLE tool_invocations (
    invocation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tool_id VARCHAR(100) NOT NULL REFERENCES tools(tool_id),
    task_id UUID REFERENCES tasks(task_id),
    agent_id VARCHAR(100),
    invocation_params JSONB NOT NULL,
    invocation_result JSONB,
    status VARCHAR(20) DEFAULT 'pending',
    error_message TEXT,
    execution_time_ms INTEGER,
    token_usage JSONB DEFAULT '{}',
    cost_incurred DECIMAL(10, 6) DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_tool_invocations_tool ON tool_invocations(tool_id);
CREATE INDEX idx_tool_invocations_task ON tool_invocations(task_id);
CREATE INDEX idx_tool_invocations_status ON tool_invocations(status);
CREATE INDEX idx_tool_invocations_created ON tool_invocations(created_at DESC);

-- =============================================================================
-- SECTION 6: MEMORY SYSTEM
-- =============================================================================

-- Working memory (session-scoped, ephemeral)
CREATE TABLE working_memory (
    memory_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    memory_type VARCHAR(50) NOT NULL,
    content TEXT NOT NULL,
    embedding_id BIGINT, -- Reference to vector index
    importance_score DECIMAL(3, 2) DEFAULT 0.5,
    attention_weight DECIMAL(3, 2) DEFAULT 1.0,
    access_count INTEGER DEFAULT 0,
    last_accessed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_working_memory_session ON working_memory(session_id);
CREATE INDEX idx_working_memory_type ON working_memory(memory_type);
CREATE INDEX idx_working_memory_created ON working_memory(created_at DESC);

-- Episodic memory (past events and experiences)
CREATE TABLE episodic_memory (
    episode_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    session_id UUID REFERENCES sessions(session_id),
    event_type VARCHAR(100) NOT NULL,
    event_description TEXT,
    participants VARCHAR(100)[] DEFAULT '{}',
    location VARCHAR(255),
    duration_seconds INTEGER,
    outcome VARCHAR(50),
    emotional_valence DECIMAL(3, 2), -- -1 to 1
    importance_score DECIMAL(3, 2) DEFAULT 0.5,
    embedding_id BIGINT,
    content_summary TEXT,
    raw_content JSONB,
    tags TEXT[] DEFAULT '{}',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_episodic_user ON episodic_memory(user_id);
CREATE INDEX idx_episodic_session ON episodic_memory(session_id);
CREATE INDEX idx_episodic_type ON episodic_memory(event_type);
CREATE INDEX idx_episodic_created ON episodic_memory(created_at DESC);

-- Semantic memory (facts and knowledge)
CREATE TABLE semantic_memory (
    fact_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(user_id) ON DELETE CASCADE, -- NULL for global knowledge
    fact_type VARCHAR(100) NOT NULL,
    statement TEXT NOT NULL,
    confidence_score DECIMAL(3, 2) DEFAULT 1.0,
    source_ids TEXT[] DEFAULT '{}',
    source_reliability VARCHAR(20) DEFAULT 'medium',
    embedding_id BIGINT,
    related_facts UUID[] DEFAULT '{}',
    validity_period JSONB, -- {start, end} or NULL for permanent
    last_verified_at TIMESTAMP WITH TIME ZONE,
    verification_count INTEGER DEFAULT 0,
    contradiction_ids UUID[] DEFAULT '{}',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_semantic_type ON semantic_memory(fact_type);
CREATE INDEX idx_semantic_user ON semantic_memory(user_id);
CREATE INDEX idx_semantic_confidence ON semantic_memory(confidence_score);

-- Procedural memory (skills and procedures)
CREATE TABLE procedural_memory (
    skill_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
    skill_name VARCHAR(255) NOT NULL,
    skill_category VARCHAR(100),
    procedure_steps JSONB NOT NULL, -- Array of step objects
    procedure_schema JSONB, -- Formal specification
    prerequisites TEXT[] DEFAULT '{}',
    success_rate DECIMAL(5, 2), -- percentage
    average_duration_seconds INTEGER,
    usage_count INTEGER DEFAULT 0,
    last_used_at TIMESTAMP WITH TIME ZONE,
    effectiveness_score DECIMAL(3, 2),
    tags TEXT[] DEFAULT '{}',
    version VARCHAR(20) DEFAULT '1.0',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_procedural_user ON procedural_memory(user_id);
CREATE INDEX idx_procedural_category ON procedural_memory(skill_category);
CREATE INDEX idx_procedural_name ON procedural_memory(skill_name);

-- User preferences memory
CREATE TABLE user_preferences (
    pref_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    preference_type VARCHAR(100) NOT NULL,
    preference_key VARCHAR(255) NOT NULL,
    preference_value JSONB NOT NULL,
    confidence_score DECIMAL(3, 2) DEFAULT 1.0,
    source VARCHAR(50) DEFAULT 'inferred',
    evidence JSONB DEFAULT '[]',
    last_confirmed_at TIMESTAMP WITH TIME ZONE,
    change_frequency VARCHAR(20) DEFAULT 'stable',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, preference_type, preference_key)
);

CREATE INDEX idx_user_prefs_user ON user_preferences(user_id);
CREATE INDEX idx_user_prefs_type ON user_preferences(preference_type);

-- System memory (logs and operational data)
CREATE TABLE system_memory (
    log_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    component VARCHAR(100) NOT NULL,
    log_type VARCHAR(50) NOT NULL,
    severity VARCHAR(20) DEFAULT 'info',
    message TEXT NOT NULL,
    context JSONB DEFAULT '{}',
    lineage JSONB NOT NULL DEFAULT '{}',
    trace_id UUID,
    span_id UUID,
    user_id UUID REFERENCES users(user_id),
    session_id UUID REFERENCES sessions(session_id),
    task_id UUID REFERENCES tasks(task_id),
    agent_id VARCHAR(100),
    duration_ms INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_system_memory_component ON system_memory(component);
CREATE INDEX idx_system_memory_type ON system_memory(log_type);
CREATE INDEX idx_system_memory_severity ON system_memory(severity);
CREATE INDEX idx_system_memory_created ON system_memory(created_at DESC);
CREATE INDEX idx_system_memory_trace_id ON system_memory(trace_id);

-- =============================================================================
-- SECTION 7: KNOWLEDGE SYSTEM
-- =============================================================================

-- Documents store
CREATE TABLE documents (
    doc_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    doc_type VARCHAR(50) NOT NULL,
    title VARCHAR(500) NOT NULL,
    content TEXT NOT NULL,
    content_hash VARCHAR(64),
    file_path TEXT,
    file_size BIGINT,
    mime_type VARCHAR(100),
    language VARCHAR(20),
    summary TEXT,
    embedding_id BIGINT,
    metadata JSONB DEFAULT '{}',
    tags TEXT[] DEFAULT '{}',
    category VARCHAR(100),
    source_type VARCHAR(50),
    source_url TEXT,
    author VARCHAR(255),
    published_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    indexed_at TIMESTAMP WITH TIME ZONE,
    last_accessed_at TIMESTAMP WITH TIME ZONE,
    access_count INTEGER DEFAULT 0,
    version INTEGER DEFAULT 1
);

CREATE INDEX idx_documents_type ON documents(doc_type);
CREATE INDEX idx_documents_category ON documents(category);
CREATE INDEX idx_documents_tags ON documents USING GIN(tags);
CREATE INDEX idx_documents_created ON documents(created_at DESC);

-- Knowledge graph nodes
CREATE TABLE knowledge_nodes (
    node_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_type VARCHAR(100) NOT NULL,
    entity_name VARCHAR(500) NOT NULL,
    description TEXT,
    properties JSONB DEFAULT '{}',
    embedding_id BIGINT,
    confidence_score DECIMAL(3, 2) DEFAULT 1.0,
    source_document_ids UUID[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(entity_type, entity_name)
);

CREATE INDEX idx_kg_nodes_type ON knowledge_nodes(entity_type);
CREATE INDEX idx_kg_nodes_name ON knowledge_nodes(entity_name);

-- Knowledge graph edges
CREATE TABLE knowledge_edges (
    edge_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_node_id UUID NOT NULL REFERENCES knowledge_nodes(node_id) ON DELETE CASCADE,
    target_node_id UUID NOT NULL REFERENCES knowledge_nodes(node_id) ON DELETE CASCADE,
    relationship_type VARCHAR(100) NOT NULL,
    relationship_properties JSONB DEFAULT '{}',
    confidence_score DECIMAL(3, 2) DEFAULT 1.0,
    bidirectional BOOLEAN DEFAULT false,
    source_document_ids UUID[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(source_node_id, target_node_id, relationship_type)
);

CREATE INDEX idx_kg_edges_source ON knowledge_edges(source_node_id);
CREATE INDEX idx_kg_edges_target ON knowledge_edges(target_node_id);
CREATE INDEX idx_kg_edges_type ON knowledge_edges(relationship_type);

-- RAG retrieval history
CREATE TABLE rag_retrievals (
    retrieval_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES sessions(session_id),
    query TEXT NOT NULL,
    query_embedding_id BIGINT,
    retrieved_doc_ids UUID[] DEFAULT '{}',
    retrieval_scores JSONB DEFAULT '[]',
    fusion_method VARCHAR(50) DEFAULT 'rrf',
    top_k INTEGER DEFAULT 10,
    latency_ms INTEGER,
    results_count INTEGER,
    reranking_applied BOOLEAN DEFAULT false,
    final_scores JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_rag_retrievals_session ON rag_retrievals(session_id);
CREATE INDEX idx_rag_retrievals_created ON rag_retrievals(created_at DESC);

-- =============================================================================
-- SECTION 8: EXECUTION & ACTIONS
-- =============================================================================

-- Execution jobs
CREATE TABLE execution_jobs (
    job_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID REFERENCES tasks(task_id),
    job_type VARCHAR(50) NOT NULL,
    execution_mode VARCHAR(20) DEFAULT 'live' CHECK (execution_mode IN ('live', 'dry_run', 'simulation')),
    status VARCHAR(20) DEFAULT 'pending',
    planned_actions JSONB NOT NULL DEFAULT '[]',
    executed_actions JSONB DEFAULT '[]',
    action_results JSONB DEFAULT '[]',
    current_action_index INTEGER DEFAULT 0,
    rollback_actions JSONB DEFAULT '[]',
    risk_level VARCHAR(20) DEFAULT 'low',
    requires_approval BOOLEAN DEFAULT false,
    approval_status VARCHAR(20) DEFAULT 'not_required',
    approved_by UUID REFERENCES users(user_id),
    approved_at TIMESTAMP WITH TIME ZONE,
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    error_message TEXT,
    final_state JSONB,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_execution_jobs_status ON execution_jobs(status);
CREATE INDEX idx_execution_jobs_type ON execution_jobs(job_type);
CREATE INDEX idx_execution_jobs_task ON execution_jobs(task_id);

-- Sandbox executions
CREATE TABLE sandbox_executions (
    execution_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id UUID REFERENCES execution_jobs(job_id),
    sandbox_type VARCHAR(30) DEFAULT 'docker',
    language VARCHAR(30),
    code TEXT NOT NULL,
    code_hash VARCHAR(64),
    execution_timeout_ms INTEGER DEFAULT 30000,
    resource_limits JSONB DEFAULT '{}',
    environment_vars JSONB DEFAULT '{}',
    network_access BOOLEAN DEFAULT false,
    allowed_endpoints TEXT[] DEFAULT '{}',
    stdout TEXT,
    stderr TEXT,
    exit_code INTEGER,
    execution_time_ms INTEGER,
    memory_used_bytes BIGINT,
    cpu_time_ms INTEGER,
    status VARCHAR(20) DEFAULT 'pending',
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_sandbox_jobs ON sandbox_executions(job_id);
CREATE INDEX idx_sandbox_status ON sandbox_executions(status);

-- API calls
CREATE TABLE api_calls (
    call_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id UUID REFERENCES execution_jobs(job_id),
    tool_id VARCHAR(100) REFERENCES tools(tool_id),
    endpoint_url TEXT NOT NULL,
    http_method VARCHAR(10) NOT NULL,
    request_headers JSONB DEFAULT '{}',
    request_body JSONB,
    request_body_hash VARCHAR(64),
    response_status_code INTEGER,
    response_headers JSONB DEFAULT '{}',
    response_body JSONB,
    response_body_hash VARCHAR(64),
    latency_ms INTEGER,
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_api_calls_job ON api_calls(job_id);
CREATE INDEX idx_api_calls_status ON api_calls(response_status_code);

-- =============================================================================
-- SECTION 9: SECURITY & COMPLIANCE
-- =============================================================================

-- Audit logs (immutable)
CREATE TABLE audit_logs (
    audit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(user_id),
    session_id UUID REFERENCES sessions(session_id),
    task_id UUID REFERENCES tasks(task_id),
    action_type VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50),
    resource_id VARCHAR(255),
    action_details JSONB DEFAULT '{}',
    ip_address INET,
    user_agent TEXT,
    auth_method VARCHAR(50),
    risk_level VARCHAR(20) DEFAULT 'low',
    policy_violations JSONB DEFAULT '[]',
    outcome VARCHAR(20) DEFAULT 'success',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_action ON audit_logs(action_type);
CREATE INDEX idx_audit_created ON audit_logs(created_at DESC);

-- Policy violations
CREATE TABLE policy_violations (
    violation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    audit_id UUID REFERENCES audit_logs(audit_id),
    policy_name VARCHAR(100) NOT NULL,
    policy_type VARCHAR(50),
    severity VARCHAR(20) NOT NULL,
    violation_details JSONB NOT NULL,
    recommended_actions JSONB DEFAULT '[]',
    resolved BOOLEAN DEFAULT false,
    resolved_by UUID REFERENCES users(user_id),
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolution_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_violations_severity ON policy_violations(severity);
CREATE INDEX idx_violations_resolved ON policy_violations(resolved);

-- API keys and tokens
CREATE TABLE api_keys (
    key_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    key_hash VARCHAR(64) NOT NULL UNIQUE,
    key_prefix VARCHAR(20) NOT NULL,
    key_name VARCHAR(100),
    permissions JSONB DEFAULT '[]',
    rate_limit_rpm INTEGER DEFAULT 1000,
    expires_at TIMESTAMP WITH TIME ZONE,
    last_used_at TIMESTAMP WITH TIME ZONE,
    use_count INTEGER DEFAULT 0,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_api_keys_user ON api_keys(user_id);
CREATE INDEX idx_api_keys_status ON api_keys(status);

-- =============================================================================
-- SECTION 10: VECTOR STORAGE (PostgreSQL Extension)
-- =============================================================================

-- Enable vector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Document embeddings
CREATE TABLE document_embeddings (
    embedding_id BIGINT PRIMARY KEY DEFAULT nextval('embedding_seq'),
    document_id UUID NOT NULL,
    chunk_index INTEGER DEFAULT 0,
    content_chunk TEXT NOT NULL,
    embedding vector(1536), -- 1536 dimensions, adjustable based on model
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_embeddings_document ON document_embeddings(document_id);
CREATE INDEX idx_embeddings_vector ON document_embeddings USING ivfflat(embedding vector_cosine_ops);

-- Memory embeddings
CREATE TABLE memory_embeddings (
    embedding_id BIGINT PRIMARY KEY DEFAULT nextval('embedding_seq'),
    memory_type VARCHAR(50) NOT NULL,
    memory_id UUID NOT NULL,
    content TEXT NOT NULL,
    embedding vector(1536),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_memory_embeddings_type ON memory_embeddings(memory_type);
CREATE INDEX idx_memory_embeddings_vector ON memory_embeddings USING ivfflat(embedding vector_cosine_ops);

-- Knowledge embeddings
CREATE TABLE knowledge_embeddings (
    embedding_id BIGINT PRIMARY KEY DEFAULT nextval('embedding_seq'),
    entity_id UUID NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    content TEXT NOT NULL,
    embedding vector(1536),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_knowledge_embeddings_type ON knowledge_embeddings(entity_type);
CREATE INDEX idx_knowledge_embeddings_vector ON knowledge_embeddings USING ivfflat(embedding vector_cosine_ops);

-- =============================================================================
-- SECTION 11: ANALYTICS & METRICS
-- =============================================================================

-- Request metrics
CREATE TABLE request_metrics (
    metric_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(user_id),
    session_id UUID REFERENCES sessions(session_id),
    request_type VARCHAR(50) NOT NULL,
    model_used VARCHAR(100),
    token_count_input INTEGER,
    token_count_output INTEGER,
    token_count_total INTEGER,
    latency_ms INTEGER,
    first_token_latency_ms INTEGER,
    status VARCHAR(20),
    error_code VARCHAR(20),
    cost_usd DECIMAL(10, 6),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_request_metrics_user ON request_metrics(user_id);
CREATE INDEX idx_request_metrics_created ON request_metrics(created_at DESC);

-- System health metrics
CREATE TABLE system_health_metrics (
    metric_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    component VARCHAR(100) NOT NULL,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(10, 4) NOT NULL,
    unit VARCHAR(20),
    percentile VARCHAR(10),
    sample_count INTEGER DEFAULT 1,
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_health_metrics_component ON system_health_metrics(component);
CREATE INDEX idx_health_metrics_recorded ON system_health_metrics(recorded_at DESC);

-- User feedback
CREATE TABLE user_feedback (
    feedback_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES sessions(session_id),
    message_id UUID REFERENCES session_messages(message_id),
    feedback_type VARCHAR(50) NOT NULL,
    rating INTEGER CHECK (rating BETWEEN 1 AND 5),
    feedback_text TEXT,
    feedback_categories VARCHAR(50)[] DEFAULT '{}',
    helpful BOOLEAN,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_feedback_session ON user_feedback(session_id);
CREATE INDEX idx_feedback_type ON user_feedback(feedback_type);

-- =============================================================================
-- SECTION 12: CACHING LAYER
-- =============================================================================

-- Response cache
CREATE TABLE response_cache (
    cache_key VARCHAR(255) PRIMARY KEY,
    request_hash VARCHAR(64) NOT NULL,
    request_params JSONB NOT NULL,
    response_data JSONB NOT NULL,
    model_used VARCHAR(100),
    token_count INTEGER,
    hit_count INTEGER DEFAULT 1,
    first_hit_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_hit_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_cache_hits ON response_cache(hit_count DESC);
CREATE INDEX idx_cache_expires ON response_cache(expires_at);

-- =============================================================================
-- SECTION 13: WORKFLOW DEFINITIONS
-- =============================================================================

-- Workflow templates
CREATE TABLE workflow_templates (
    template_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    template_name VARCHAR(255) NOT NULL,
    template_category VARCHAR(100),
    description TEXT,
    workflow_definition JSONB NOT NULL,
    variables JSONB DEFAULT '{}',
    input_schema JSONB,
    output_schema JSONB,
    version VARCHAR(20) DEFAULT '1.0.0',
    status VARCHAR(20) DEFAULT 'active',
    usage_count INTEGER DEFAULT 0,
    avg_duration_seconds INTEGER,
    success_rate DECIMAL(5, 2),
    tags TEXT[] DEFAULT '{}',
    created_by UUID REFERENCES users(user_id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_workflow_templates_category ON workflow_templates(template_category);
CREATE INDEX idx_workflow_templates_status ON workflow_templates(status);

-- Workflow executions
CREATE TABLE workflow_executions (
    execution_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    template_id UUID REFERENCES workflow_templates(template_id),
    user_id UUID REFERENCES users(user_id),
    execution_name VARCHAR(255),
    input_params JSONB DEFAULT '{}',
    current_step INTEGER DEFAULT 0,
    total_steps INTEGER,
    status VARCHAR(20) DEFAULT 'pending',
    step_results JSONB DEFAULT '[]',
    outputs JSONB,
    error_message TEXT,
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    duration_seconds INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_workflow_executions_template ON workflow_executions(template_id);
CREATE INDEX idx_workflow_executions_status ON workflow_executions(status);

-- =============================================================================
-- FUNCTION: Auto-update timestamp
-- =============================================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_sessions_updated_at BEFORE UPDATE ON sessions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON tasks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_agents_updated_at BEFORE UPDATE ON agents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_tools_updated_at BEFORE UPDATE ON tools
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_semantic_memory_updated_at BEFORE UPDATE ON semantic_memory
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_user_preferences_updated_at BEFORE UPDATE ON user_preferences
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =============================================================================
-- VIEW: Active sessions with message count
-- =============================================================================

CREATE VIEW active_sessions AS
SELECT
    s.session_id,
    s.user_id,
    s.session_type,
    s.title,
    s.status,
    s.created_at,
    s.last_activity_at,
    COUNT(m.message_id) AS message_count,
    SUM(m.token_count) AS total_tokens
FROM sessions s
LEFT JOIN session_messages m ON s.session_id = m.session_id
WHERE s.status = 'active'
GROUP BY s.session_id, s.user_id, s.session_type, s.title, s.status, s.created_at, s.last_activity_at;

-- =============================================================================
-- VIEW: Task completion metrics
-- =============================================================================

CREATE VIEW task_metrics_summary AS
SELECT
    DATE(created_at) AS date,
    COUNT(*) AS total_tasks,
    COUNT(*) FILTER (WHERE status = 'completed') AS completed_tasks,
    COUNT(*) FILTER (WHERE status = 'failed') AS failed_tasks,
    AVG(EXTRACT(EPOCH FROM (completed_at - started_at))) FILTER (WHERE completed_at IS NOT NULL) AS avg_duration_seconds,
    COUNT(*) FILTER (WHERE retry_count > 0) AS retried_tasks
FROM tasks
WHERE created_at >= NOW() - INTERVAL '30 days'
GROUP BY DATE(created_at)
ORDER BY date DESC;

-- =============================================================================
-- END OF DATABASE SCHEMA
-- =============================================================================
