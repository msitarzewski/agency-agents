from __future__ import annotations

from pathlib import Path

import mne


def preprocess_raw(
    raw: mne.io.BaseRaw,
    *,
    low_cut_hz: float = 1.0,
    high_cut_hz: float = 40.0,
    line_freq_hz: float = 50.0,
) -> mne.io.BaseRaw:
    """Apply a baseline EEG preprocessing chain for BCI workflows.

    Steps:
    1. Notch filter powerline noise.
    2. Band-pass filter for common EEG analysis.

    This example is intentionally conservative and should be adapted per protocol,
    hardware characteristics, and artifact profile.
    """
    cleaned = raw.copy()

    eeg_picks = mne.pick_types(cleaned.info, eeg=True, meg=False, exclude="bads")
    if len(eeg_picks) == 0:
        raise ValueError("No EEG channels found in the raw recording")

    cleaned.notch_filter(freqs=[line_freq_hz], picks=eeg_picks)
    cleaned.filter(l_freq=low_cut_hz, h_freq=high_cut_hz, picks=eeg_picks)
    return cleaned
def load_and_preprocess_fif(
    input_path: Path,
    output_path: Path,
    *,
    overwrite: bool = False,
    preload: bool = True,
) -> None:
    """Load a FIF recording, apply baseline preprocessing, and save the result.

    Set ``preload=False`` for very large files when memory pressure is a concern.
    """
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    if output_path.exists() and not overwrite:
        raise FileExistsError(
            f"Output file already exists: {output_path}. "
            "Set overwrite=True to replace it."
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        raw = mne.io.read_raw_fif(input_path, preload=preload)
        cleaned = preprocess_raw(raw)
        cleaned.save(output_path, overwrite=overwrite)
    except Exception as error:
        raise RuntimeError(f"Preprocessing failed for {input_path}: {error}") from error


if __name__ == "__main__":
    # Replace these placeholders with your actual recording paths.
    source = Path("session_raw.fif")
    destination = Path("session_cleaned.fif")
    load_and_preprocess_fif(source, destination)
